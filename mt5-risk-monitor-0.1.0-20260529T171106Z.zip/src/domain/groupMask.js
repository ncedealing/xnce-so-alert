'use strict';

function escapeRegex(value) {
  return String(value).replace(/[|\\{}()[\]^$+?.]/g, '\\$&');
}

function maskToRegex(mask) {
  const source = String(mask)
    .split('*')
    .map((part) => part.split('?').map(escapeRegex).join('.'))
    .join('.*');
  return new RegExp(`^${source}$`, 'i');
}

function matchesGroupMask(group, masks) {
  if (!Array.isArray(masks) || masks.length === 0) return true;
  return masks.some((mask) => maskToRegex(mask).test(String(group || '')));
}

function filterAccountsByGroup(accounts, masks) {
  return accounts.filter((account) => matchesGroupMask(account.group, masks));
}

module.exports = {
  escapeRegex,
  maskToRegex,
  matchesGroupMask,
  filterAccountsByGroup
};
