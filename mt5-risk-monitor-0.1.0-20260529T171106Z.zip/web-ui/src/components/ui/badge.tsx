import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const badgeVariants = cva(
  'inline-flex items-center rounded-md border px-1.5 py-0.5 text-[10px] font-semibold tabular-nums transition-colors',
  {
    variants: {
      variant: {
        default: 'border-zinc-700 bg-zinc-800 text-zinc-200',
        success: 'border-emerald-800/60 bg-emerald-950/50 text-emerald-400',
        warning: 'border-amber-800/60 bg-amber-950/50 text-amber-400',
        destructive: 'border-red-800/60 bg-red-950/50 text-red-400 font-bold',
        outline: 'border-zinc-600 text-zinc-300',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  },
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

export function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}
