import { TopBar } from '@/components/TopBar';
import { Dashboard } from '@/components/Dashboard';
import { Configuration } from '@/components/Configuration';
import type { AppConfig, Mt5ConnectionStatus, Mt5ServerConfig, RiskResult, SystemStatus } from '@/types/api';

type View = 'dashboard' | 'configuration';

interface AppShellProps {
  view: View;
  onViewChange: (view: View) => void;
  status: SystemStatus | null;
  risk: RiskResult | null;
  config: AppConfig | null;
  streamConnected: boolean;
  saving: boolean;
  onToggleMonitor: () => void;
  onSaveConfig: (config: AppConfig) => Promise<unknown>;
  onTestMt5Connection: (server: Mt5ServerConfig) => Promise<Mt5ConnectionStatus>;
}

export function AppShell({
  view,
  onViewChange,
  status,
  risk,
  config,
  streamConnected,
  saving,
  onToggleMonitor,
  onSaveConfig,
  onTestMt5Connection,
}: AppShellProps) {
  return (
    <div className="flex h-screen w-screen flex-col overflow-hidden bg-zinc-950 text-zinc-300">
      <TopBar
        view={view}
        status={status}
        streamConnected={streamConnected}
        onToggleMonitor={onToggleMonitor}
        onViewChange={onViewChange}
      />

      <main className="flex-1 min-h-0 min-w-0 overflow-hidden">
        {view === 'dashboard' ? (
          <Dashboard status={status} risk={risk} config={config} saving={saving} onSaveConfig={onSaveConfig} />
        ) : (
          <Configuration
            config={config}
            risk={risk}
            saving={saving}
            onSave={onSaveConfig}
            onTestMt5Connection={onTestMt5Connection}
          />
        )}
      </main>
    </div>
  );
}
