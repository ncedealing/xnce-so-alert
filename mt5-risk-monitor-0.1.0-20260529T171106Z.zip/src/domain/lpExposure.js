'use strict';

const { toNumber, normalizeAction } = require('./margin');

function invertAction(action) {
  return normalizeAction(action) === 'BUY' ? 'SELL' : 'BUY';
}

function buildExplicitLpSnapshot(lpConfig) {
  const account = {
    login: lpConfig.name || 'LP',
    group: 'LP',
    currency: lpConfig.currency || 'USD',
    balance: toNumber(lpConfig.balance),
    equityAdjustment: toNumber(lpConfig.equityAdjustment),
    credit: toNumber(lpConfig.credit),
    leverage: toNumber(lpConfig.leverage, 1)
  };
  const positions = (lpConfig.explicitPositions || []).map((position, index) => ({
    ...position,
    login: account.login,
    ticket: position.ticket || `LP-${index + 1}`
  }));
  return { account, positions };
}

function buildAggregateLpSnapshot(lpConfig, clientPositions) {
  const explicit = buildExplicitLpSnapshot(lpConfig);
  const directionSign = lpConfig.hedgeDirection === 'opposite' ? -1 : 1;
  const bySymbol = new Map();

  for (const position of clientPositions || []) {
    const action = normalizeAction(position.action);
    const signedVolume = (action === 'BUY' ? 1 : -1) * directionSign * Math.abs(toNumber(position.volumeLots));
    if (Math.abs(signedVolume) < 1e-12) continue;

    const current = bySymbol.get(position.symbol) || {
      symbol: position.symbol,
      signedVolume: 0,
      signedOpenNotional: 0,
      contractSize: position.contractSize
    };
    current.signedVolume += signedVolume;
    current.signedOpenNotional += signedVolume * toNumber(position.openPrice);
    current.contractSize = current.contractSize || position.contractSize;
    bySymbol.set(position.symbol, current);
  }

  const positions = [];
  let index = 1;
  for (const item of bySymbol.values()) {
    if (Math.abs(item.signedVolume) < 1e-9) continue;
    const action = item.signedVolume > 0 ? 'BUY' : 'SELL';
    const volumeLots = Math.abs(item.signedVolume);
    const openPrice = item.signedOpenNotional / item.signedVolume;
    positions.push({
      login: explicit.account.login,
      ticket: `LP-${index}`,
      symbol: item.symbol,
      action: lpConfig.hedgeDirection === 'opposite' ? normalizeAction(action) : action,
      volumeLots,
      openPrice,
      contractSize: item.contractSize
    });
    index += 1;
  }

  return {
    account: explicit.account,
    positions
  };
}

function buildLpSnapshot(lpConfig, clientPositions) {
  if (!lpConfig || !lpConfig.enabled) return null;
  if (lpConfig.mode === 'explicitPositions') return buildExplicitLpSnapshot(lpConfig);
  return buildAggregateLpSnapshot(lpConfig, clientPositions);
}

module.exports = {
  invertAction,
  buildLpSnapshot,
  buildAggregateLpSnapshot,
  buildExplicitLpSnapshot
};
