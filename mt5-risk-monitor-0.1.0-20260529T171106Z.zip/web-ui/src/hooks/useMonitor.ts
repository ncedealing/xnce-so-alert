import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '@/lib/api';
import type { AppConfig, Mt5ServerConfig, RiskResult, SystemStatus } from '@/types/api';

export function useMonitor(active = true) {
  const [status, setStatus] = useState<SystemStatus | null>(null);
  const [risk, setRisk] = useState<RiskResult | null>(null);
  const [config, setConfig] = useState<AppConfig | null>(null);
  const [checking, setChecking] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [streamConnected, setStreamConnected] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const autoConnectKeyRef = useRef('');

  const refreshStatus = useCallback(async () => {
    const s = await api.getStatus();
    setStatus(s);
    return s;
  }, []);

  const refreshRisk = useCallback(async () => {
    const r = await api.getRisk();
    setRisk(r);
    return r;
  }, []);

  const refreshConfig = useCallback(async () => {
    const c = await api.getConfig();
    setConfig(c);
    return c;
  }, []);

  const init = useCallback(async () => {
    try {
      setError(null);
      await Promise.all([refreshStatus(), refreshRisk(), refreshConfig()]);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load');
    }
  }, [refreshStatus, refreshRisk, refreshConfig]);

  useEffect(() => {
    if (!active) return;
    init();
  }, [active, init]);

  useEffect(() => {
    if (!active) return;
    if (!config || !status) return;
    if (!['mt5WebApi', 'managerApi'].includes(config.provider?.type)) return;
    const server = config.mt5?.servers?.[0];
    if (!server?.host || !server?.port) return;
    if (status.mt5Connection?.status === 'testing') return;

    const key = [
      config.provider.type,
      server.host,
      server.port,
      server.login,
      config.provider?.mt5WebApi?.crypt || '',
    ].join(':');
    if (autoConnectKeyRef.current === key) return;
    autoConnectKeyRef.current = key;

    api
      .testMt5Connection({
        ...server,
        providerType: config.provider.type,
        deepAuth: false,
        tcpTimeoutMs: 3000,
      })
      .then((result) => setStatus((current) => (current ? { ...current, mt5Connection: result } : current)))
      .catch(() => {});
  }, [active, config, status]);

  useEffect(() => {
    if (!active) return undefined;
    if (typeof EventSource === 'undefined') return undefined;
    const source = new EventSource(api.eventSourceUrl());
    const readPayload = <T,>(event: MessageEvent<string>): T => {
      const parsed = JSON.parse(event.data);
      return (parsed && typeof parsed === 'object' && 'payload' in parsed ? parsed.payload : parsed) as T;
    };

    source.onopen = () => setStreamConnected(true);
    source.onerror = () => setStreamConnected(false);
    source.addEventListener('status', (event) => {
      setStatus(readPayload<SystemStatus>(event as MessageEvent<string>));
    });
    source.addEventListener('risk', (event) => {
      setRisk(readPayload<RiskResult | null>(event as MessageEvent<string>));
    });
    source.addEventListener('config', (event) => {
      setConfig(readPayload<AppConfig>(event as MessageEvent<string>));
    });
    source.addEventListener('error', (event) => {
      const payload = readPayload<{ message?: string }>(event as MessageEvent<string>);
      setError(payload.message || 'Monitor stream error');
    });

    return () => {
      source.close();
      setStreamConnected(false);
    };
  }, [active]);

  // Poll status only as a fallback when the SSE stream is not connected.
  useEffect(() => {
    if (!active) return undefined;
    if (streamConnected) return undefined;
    const id = setInterval(() => {
      refreshStatus().catch(() => {});
    }, 1000);
    return () => clearInterval(id);
  }, [active, refreshStatus, streamConnected]);

  // Poll risk only as a fallback. With SSE connected, risk updates are pushed by the backend.
  useEffect(() => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
    if (!active) return undefined;
    if (!status?.running || streamConnected) return;

    const intervalMs = Math.max(100, Number(status.pollIntervalSeconds || 1) * 1000);
    pollRef.current = setInterval(() => {
      refreshRisk().catch(() => {});
    }, intervalMs);

    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [active, status?.running, status?.pollIntervalSeconds, streamConnected, refreshRisk, refreshStatus]);

  const checkNow = useCallback(async () => {
    setChecking(true);
    try {
      setError(null);
      const result = await api.checkNow();
      setRisk(result);
      await refreshStatus();
      return result;
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Check failed';
      setError(msg);
      throw e;
    } finally {
      setChecking(false);
    }
  }, [refreshStatus]);

  const toggleMonitor = useCallback(async () => {
    try {
      setError(null);
      const s = status?.running
        ? await api.stopMonitor()
        : await api.startMonitor();
      setStatus(s);
      if (!status?.running) {
        await refreshRisk();
      }
      return s;
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Monitor toggle failed';
      setError(msg);
      throw e;
    }
  }, [status?.running, refreshRisk]);

  const saveConfig = useCallback(async (next: AppConfig) => {
    setSaving(true);
    try {
      setError(null);
      const res = await api.saveConfig(next);
      setConfig(res.config);
      await refreshStatus();
      return res;
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Save failed';
      setError(msg);
      throw e;
    } finally {
      setSaving(false);
    }
  }, [refreshStatus]);

  const testMt5Connection = useCallback(async (server: Mt5ServerConfig) => {
    try {
      setError(null);
      const result = await api.testMt5Connection(server);
      await refreshStatus();
      return result;
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'MT5 connection test failed';
      setError(msg);
      throw e;
    }
  }, [refreshStatus]);

  return {
    status,
    risk,
    config,
    checking,
    saving,
    error,
    checkNow,
    toggleMonitor,
    saveConfig,
    testMt5Connection,
    refreshConfig,
    refreshStatus,
    refreshRisk,
    streamConnected,
    reload: init,
  };
}
