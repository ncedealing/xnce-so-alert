'use strict';

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function valueAtPath(context, path) {
  return String(path)
    .trim()
    .split('.')
    .reduce((value, key) => (value == null ? undefined : value[key]), context);
}

function renderTemplate(template, context) {
  return String(template).replace(/\{\{\s*([a-zA-Z0-9_.]+)\s*\}\}/g, (_match, key) => {
    if (key.endsWith('Html')) return String(valueAtPath(context, key) ?? '');
    return escapeHtml(valueAtPath(context, key) ?? '');
  });
}

module.exports = {
  escapeHtml,
  valueAtPath,
  renderTemplate
};
