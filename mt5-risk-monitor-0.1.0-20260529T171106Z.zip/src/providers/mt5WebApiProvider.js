'use strict';

const { Mt5WebApiClient } = require('../../scripts/mt5_webapi_probe');
const { matchesGroupMask } = require('../domain/groupMask');
const { mappingForSymbol } = require('../domain/symbolMapping');
const { resolveSecret } = require('../domain/secrets');

class Mt5WebApiProvider {
  constructor(config, ClientClass = Mt5WebApiClient) {
    this.config = config;
    this.options = (config.provider && config.provider.mt5WebApi) || {};
    this.ClientClass = ClientClass;
    this.client = null;
    this.clientKey = '';
    this.connecting = null;
  }

  async getSnapshot({ groupMasks, symbolMasks, accountLogins } = {}) {
    return this.withClient(async (client) => {
      const serverTime = await readServerTime(client);
      const logins = await resolveLogins(client, {
        groupMasks: groupMasks || this.config.mt5.groupMasks || [],
        accountLogins: accountLogins || this.config.mt5.accountLogins || []
      });
      const accounts = [];
      const positions = [];

      for (const login of logins) {
        const user = await readJsonCommand(client, 'USER_GET', { LOGIN: String(login) });
        const account = await readJsonCommand(client, 'USER_ACCOUNT_GET', { LOGIN: String(login) });
        accounts.push(normalizeAccount(user, account, this.config.mt5.baseCurrency || 'USD'));

        const total = await readTotal(client, 'POSITION_GET_TOTAL', { LOGIN: String(login) });
        if (total <= 0) continue;
        const page = await readJsonCommand(client, 'POSITION_GET_PAGE', {
          LOGIN: String(login),
          OFFSET: '0',
          TOTAL: String(Math.min(total, Number(this.options.maxPositionsPerAccount || 5000)))
        });
        for (const position of asArray(page)) positions.push(normalizePosition(position));
      }

      const symbolNames = symbolNamesForSnapshot(positions, symbolMasks || this.config.mt5.symbolMasks || [], this.config.risk);
      const symbols = [];
      const quotes = [];
      for (const symbol of symbolNames) {
        const symbolSpec = await readOptionalJsonCommand(client, 'SYMBOL_GET', { SYMBOL: symbol });
        if (symbolSpec) symbols.push(normalizeSymbol(symbolSpec, symbol));
        const ticks = await readOptionalJsonCommand(client, 'TICK_LAST', { SYMBOL: symbol });
        const tick = asArray(ticks)[0];
        if (tick) quotes.push(normalizeQuote(tick, symbol));
      }

      return {
        serverTime,
        accounts,
        positions,
        symbols,
        quotes
      };
    });
  }

  async getSymbols({ symbolMasks } = {}) {
    return this.withClient(async (client) => {
      const masks = symbolMasks || ['*'];
      const total = await readTotal(client, 'SYMBOL_TOTAL');
      const maxSymbols = Math.min(total, Number(this.options.maxSymbols || 10000));
      const symbols = [];
      for (let index = 0; index < maxSymbols; index += 1) {
        const symbolSpec = await readOptionalJsonCommand(client, 'SYMBOL_NEXT', { INDEX: String(index) });
        if (!symbolSpec) continue;
        const normalized = normalizeSymbol(symbolSpec);
        if (!masks.length || matchesGroupMask(normalized.symbol, masks)) symbols.push(normalized);
      }
      return symbols;
    });
  }

  async withClient(fn, serverOverride = {}) {
    const server = {
      ...(((this.config.mt5 || {}).servers && this.config.mt5.servers[0]) || {}),
      ...(serverOverride || {})
    };
    const secret = resolveSecret(server, 'password', 'passwordEnv');
    const password = secret.value;
    if (!password) {
      const envName = secret.envName || server.passwordEnv || 'MT5_MANAGER_PASSWORD';
      throw new Error(`MT5 manager password is missing: set ${envName} or configure a saved password`);
    }

    const clientOptions = {
      server: server.host,
      port: Number(server.port || 1950),
      login: String(server.login || ''),
      password,
      timeoutMs: Number(server.timeoutMs || this.options.timeoutMs || 30000),
      crypt: this.options.crypt || server.crypt || 'aes',
      agent: this.options.agent || 'MT5-RISK-MONITOR'
    };

    const canReuse = this.options.keepAlive !== false && Object.keys(serverOverride || {}).length === 0;
    if (canReuse) {
      const client = await this.reusableClient(clientOptions);
      try {
        return await fn(client);
      } catch (error) {
        this.close();
        throw error;
      }
    }

    const client = new this.ClientClass(clientOptions);
    try {
      await client.connect();
      await client.authenticate();
      return await fn(client);
    } finally {
      client.close();
    }
  }

  async reusableClient(options) {
    const key = clientKey(options);
    if (this.client && this.clientKey === key && !clientClosed(this.client)) return this.client;
    if (this.connecting && this.clientKey === key) return this.connecting;

    this.close();
    this.clientKey = key;
    this.connecting = (async () => {
      const client = new this.ClientClass(options);
      await client.connect();
      await client.authenticate();
      this.client = client;
      return client;
    })();

    try {
      return await this.connecting;
    } finally {
      this.connecting = null;
    }
  }

  close() {
    if (this.client && typeof this.client.close === 'function') this.client.close();
    this.client = null;
    this.clientKey = '';
    this.connecting = null;
  }
}

function clientKey(options) {
  return [
    options.server,
    options.port,
    options.login,
    options.crypt,
    options.agent
  ].join('|');
}

function clientClosed(client) {
  return !client || !client.socket || client.socket.destroyed;
}

async function testMt5WebApiConnection(config, serverOverride = {}) {
  const started = Date.now();
  const provider = new Mt5WebApiProvider(config);
  return provider.withClient(async (client) => {
    const time = await client.command('TIME_SERVER');
    ensureOk(time, 'TIME_SERVER');
    return {
      ok: true,
      latencyMs: Date.now() - started,
      serverTime: serverTimeFromResponse(time),
      auth: true
    };
  }, serverOverride);
}

async function resolveLogins(client, { groupMasks = [], accountLogins = [] }) {
  const explicit = normalizeLoginList(accountLogins);
  if (explicit.length > 0) return explicit;
  const groups = await resolveGroups(client, groupMasks);
  const logins = new Set();
  for (const group of groups) {
    const json = await readOptionalJsonCommand(client, 'USER_LOGINS', { GROUP: group });
    for (const login of asArray(json)) logins.add(String(login));
  }
  return [...logins];
}

async function resolveGroups(client, groupMasks = []) {
  if (!groupMasks || groupMasks.length === 0) return [];
  const exactGroups = groupMasks.filter((mask) => !String(mask).includes('*') && !String(mask).includes('?'));
  if (exactGroups.length === groupMasks.length) return exactGroups;

  const total = await readTotal(client, 'GROUP_TOTAL');
  const groups = [];
  for (let index = 0; index < total; index += 1) {
    const group = await readOptionalJsonCommand(client, 'GROUP_NEXT', { INDEX: String(index) });
    const name = stringValue(group, ['Group', 'group']);
    if (name && matchesGroupMask(name, groupMasks)) groups.push(name);
  }
  return groups;
}

async function readServerTime(client) {
  const response = await client.command('TIME_SERVER');
  ensureOk(response, 'TIME_SERVER');
  return serverTimeFromResponse(response);
}

function serverTimeFromResponse(response) {
  const timeText = response.params && response.params.TIME;
  const unixSeconds = Number.parseInt(String(timeText || '').split(' ')[0], 10);
  if (!Number.isFinite(unixSeconds) || unixSeconds <= 0) return null;
  return formatServerLocalTimestamp(unixSeconds * 1000);
}

function formatServerLocalTimestamp(milliseconds) {
  const date = new Date(milliseconds);
  const yyyy = String(date.getUTCFullYear()).padStart(4, '0');
  const mm = String(date.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(date.getUTCDate()).padStart(2, '0');
  const hh = String(date.getUTCHours()).padStart(2, '0');
  const mi = String(date.getUTCMinutes()).padStart(2, '0');
  const ss = String(date.getUTCSeconds()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd} ${hh}:${mi}:${ss}`;
}

async function readTotal(client, command, params = {}) {
  const response = await client.command(command, params);
  ensureOk(response, command);
  const total = Number(response.params && response.params.TOTAL);
  return Number.isFinite(total) ? total : 0;
}

async function readJsonCommand(client, command, params = {}) {
  const response = await client.command(command, params);
  ensureOk(response, command);
  return response.json;
}

async function readOptionalJsonCommand(client, command, params = {}) {
  const response = await client.command(command, params);
  if (response.retcode && response.retcode.code !== 0) return null;
  return response.json;
}

function ensureOk(response, command) {
  if (response.retcode && response.retcode.code !== 0) {
    throw new Error(`${command} failed: ${response.params.RETCODE || response.retcode.raw || 'unknown retcode'}`);
  }
}

function normalizeLoginList(values) {
  if (!values) return [];
  if (Array.isArray(values)) return values.map((value) => String(value).trim()).filter(Boolean);
  return String(values)
    .split(',')
    .map((value) => value.trim())
    .filter(Boolean);
}

function symbolNamesForSnapshot(positions, symbolMasks = [], riskConfig = {}) {
  const symbols = new Set();
  for (const position of positions) {
    if (position.symbol) symbols.add(position.symbol);
    const mapped = mappingForSymbol(position.symbol, riskConfig);
    if (mapped && mapped.mapping) {
      if (mapped.mapping.baseSymbol) symbols.add(mapped.mapping.baseSymbol);
      if (mapped.mapping.fxSymbol) symbols.add(mapped.mapping.fxSymbol);
      if (mapped.mapping.quoteSymbol) symbols.add(mapped.mapping.quoteSymbol);
    }
  }
  for (const mask of symbolMasks || []) {
    const value = String(mask || '').trim();
    if (value && !value.includes('*') && !value.includes('?')) symbols.add(value);
  }
  return [...symbols];
}

function normalizeAccount(user = {}, account = {}, baseCurrency = 'USD') {
  const login = value(user, account, ['Login', 'login']);
  const balance = numberValue(account, ['Balance', 'balance'], numberValue(user, ['Balance', 'balance'], 0));
  const credit = numberValue(account, ['Credit', 'credit'], numberValue(user, ['Credit', 'credit'], 0));
  const profit = numberValue(account, ['Profit', 'profit', 'Floating', 'floating'], 0);
  const marginLevel = normalizeMt5MarginLevel(account);
  const staticLeverage = positiveNumberValue(user, ['Leverage', 'leverage', 'UserLeverage', 'userLeverage'], NaN);
  const realtimeLeverage = positiveNumberValue(
    account,
    ['MarginLeverage', 'marginLeverage', 'AccountMarginLeverage', 'accountMarginLeverage'],
    NaN
  );
  const leverage = Number.isFinite(realtimeLeverage)
    ? realtimeLeverage
    : Number.isFinite(staticLeverage)
      ? staticLeverage
      : 1;
  return {
    login,
    group: stringValue(user, ['Group', 'group']),
    currency: stringValue(user, ['Currency', 'currency'], baseCurrency),
    balance,
    credit,
    leverage,
    marginLeverage: Number.isFinite(realtimeLeverage) ? realtimeLeverage : undefined,
    staticLeverage: Number.isFinite(staticLeverage) ? staticLeverage : undefined,
    leverageSource: Number.isFinite(realtimeLeverage)
      ? 'USER_ACCOUNT_GET.MarginLeverage'
      : Number.isFinite(staticLeverage)
        ? 'USER_GET.Leverage'
        : 'default',
    equity: numberValue(account, ['Equity', 'equity'], balance + credit + profit),
    margin: numberValue(account, ['Margin', 'margin'], 0),
    marginFree: numberValue(account, ['MarginFree', 'marginFree'], undefined),
    marginLevel
  };
}

function normalizeMt5MarginLevel(account = {}) {
  const value = numberValue(account, ['MarginLevel', 'marginLevel'], NaN);
  if (!Number.isFinite(value) || value <= 0) return undefined;
  return value / 100;
}

function normalizePosition(position = {}) {
  const symbol = stringValue(position, ['Symbol', 'symbol']);
  const volumeLots = normalizeVolumeLots(position);
  const currentPrice = numberValue(position, ['PriceCurrent', 'priceCurrent'], 0);
  return {
    login: value(position, null, ['Login', 'login']),
    ticket: value(position, null, ['Position', 'position', 'Ticket', 'ticket']),
    symbol,
    action: normalizePositionAction(value(position, null, ['Action', 'action'])),
    volumeLots,
    openPrice: numberValue(position, ['PriceOpen', 'priceOpen', 'OpenPrice', 'openPrice'], 0),
    currentPrice,
    priceCurrent: currentPrice,
    openTime: timestampIso(position, ['TimeCreate', 'timeCreate', 'TimeOpen', 'timeOpen']),
    updateTime: timestampIso(position, ['TimeUpdate', 'timeUpdate', 'Time', 'time']),
    contractSize: numberValue(position, ['ContractSize', 'contractSize'], undefined),
    swap: numberValue(position, ['Storage', 'storage', 'Swap', 'swap'], 0),
    commission: numberValue(position, ['Commission', 'commission'], 0),
    profit: numberValue(position, ['Profit', 'profit'], undefined),
    profitCurrencyRateToAccount: numberValue(position, ['RateProfit', 'rateProfit'], 1),
    marginCurrencyRateToAccount: numberValue(position, ['RateMargin', 'rateMargin'], 1)
  };
}

function timestampIso(source = {}, keys = []) {
  const value = numberValue(source, keys, NaN);
  if (!Number.isFinite(value) || value <= 0) return '';
  const milliseconds = value > 10_000_000_000 ? value : value * 1000;
  return new Date(milliseconds).toISOString();
}

function normalizeVolumeLots(position = {}) {
  const volumeReal = numberValue(position, ['VolumeReal', 'volumeReal'], NaN);
  if (Number.isFinite(volumeReal) && volumeReal > 0) return volumeReal;

  const volumeLots = numberValue(position, ['VolumeLots', 'volumeLots'], NaN);
  if (Number.isFinite(volumeLots) && volumeLots > 0) return volumeLots;

  const volumeExt = numberValue(position, ['VolumeExt', 'volumeExt'], NaN);
  if (Number.isFinite(volumeExt) && volumeExt > 0) return volumeExt / 100000000;

  const volume = numberValue(position, ['Volume', 'volume'], NaN);
  if (Number.isFinite(volume) && volume > 0) {
    if (!Number.isInteger(volume)) return volume;
    return volume >= 1000000 ? volume / 100000000 : volume / 10000;
  }

  return 0;
}

function normalizePositionAction(action) {
  const valueText = String(action ?? '').toUpperCase();
  if (valueText === '0' || valueText === 'BUY' || valueText === 'POSITION_BUY') return 'BUY';
  if (valueText === '1' || valueText === 'SELL' || valueText === 'POSITION_SELL') return 'SELL';
  return valueText || 'BUY';
}

function normalizeSymbol(symbol = {}, fallbackSymbol = '') {
  const digits = numberValue(symbol, ['Digits', 'digits'], 5);
  const calcMode = numberValue(symbol, ['CalcMode', 'calcMode', 'TradeCalcMode', 'tradeCalcMode'], undefined);
  const swapMode = numberValue(symbol, ['SwapMode', 'swapMode'], undefined);
  return {
    symbol: stringValue(symbol, ['Symbol', 'symbol'], fallbackSymbol),
    path: stringValue(symbol, ['Path', 'path'], ''),
    description: stringValue(symbol, ['Description', 'description'], ''),
    digits,
    point: numberValue(symbol, ['Point', 'point'], 10 ** -digits),
    contractSize: numberValue(symbol, ['ContractSize', 'contractSize'], 100000),
    currencyProfit: stringValue(symbol, ['CurrencyProfit', 'currencyProfit'], 'USD'),
    currencyMargin: stringValue(symbol, ['CurrencyMargin', 'currencyMargin'], 'USD'),
    tickValue: numberValue(symbol, ['TickValue', 'tickValue'], 0),
    tickSize: numberValue(symbol, ['TickSize', 'tickSize'], 0),
    marginInitial: numberValue(symbol, ['MarginInitial', 'marginInitial'], 0),
    marginMaintenance: numberValue(symbol, ['MarginMaintenance', 'marginMaintenance'], 0),
    calcMode,
    calcModeName: calcModeName(calcMode),
    tradeCalcMode: calcMode,
    tradeCalcModeName: calcModeName(calcMode),
    swapMode,
    swapModeName: swapModeName(swapMode),
    swapLong: numberValue(symbol, ['SwapLong', 'swapLong'], 0),
    swapShort: numberValue(symbol, ['SwapShort', 'swapShort'], 0),
    swap3Day: numberValue(symbol, ['Swap3Day', 'swap3Day'], undefined)
  };
}

function calcModeName(mode) {
  const names = {
    0: 'FOREX',
    1: 'FUTURES',
    2: 'CFD',
    3: 'CFDINDEX',
    4: 'CFDLEVERAGE',
    5: 'FOREX_NO_LEVERAGE',
    32: 'EXCH_STOCKS',
    33: 'EXCH_FUTURES',
    34: 'EXCH_FUTURES_FORTS',
    35: 'EXCH_OPTIONS',
    36: 'EXCH_OPTIONS_MARGIN',
    37: 'EXCH_BONDS',
    38: 'EXCH_STOCKS_MOEX',
    39: 'EXCH_BONDS_MOEX',
    64: 'SERV_COLLATERAL'
  };
  return names[mode] || (mode === undefined ? '' : String(mode));
}

function swapModeName(mode) {
  const names = {
    0: 'DISABLED',
    1: 'POINTS',
    2: 'SYMBOL_CURRENCY',
    3: 'MARGIN_CURRENCY',
    4: 'GROUP_CURRENCY',
    5: 'INTEREST_CURRENT',
    6: 'INTEREST_OPEN',
    7: 'REOPEN_BY_CLOSE_PRICE',
    8: 'REOPEN_BY_BID',
    9: 'PROFIT_CURRENCY'
  };
  return names[mode] || (mode === undefined ? '' : String(mode));
}

function normalizeQuote(tick = {}, fallbackSymbol = '') {
  const unixSeconds = numberValue(tick, ['Datetime', 'datetime'], 0);
  return {
    symbol: stringValue(tick, ['Symbol', 'symbol'], fallbackSymbol),
    bid: numberValue(tick, ['Bid', 'bid'], 0),
    ask: numberValue(tick, ['Ask', 'ask'], 0),
    time: unixSeconds > 0 ? new Date(unixSeconds * 1000).toISOString() : new Date().toISOString()
  };
}

function asArray(value) {
  if (Array.isArray(value)) return value;
  if (value === undefined || value === null) return [];
  return [value];
}

function value(primary = {}, secondary = {}, keys = [], fallback = '') {
  for (const source of [primary, secondary]) {
    if (!source) continue;
    for (const key of keys) {
      if (source[key] !== undefined && source[key] !== null && source[key] !== '') return source[key];
    }
  }
  return fallback;
}

function stringValue(source = {}, keys = [], fallback = '') {
  const found = value(source, null, keys, fallback);
  return found === undefined || found === null ? fallback : String(found);
}

function numberValue(source = {}, keys = [], fallback) {
  const fallbackValue = arguments.length >= 3 ? fallback : 0;
  let found;
  for (const key of keys) {
    if (source && source[key] !== undefined && source[key] !== null && source[key] !== '') {
      found = source[key];
      break;
    }
  }
  const number = Number(found);
  return Number.isFinite(number) ? number : fallbackValue;
}

function positiveNumberValue(source = {}, keys = [], fallback) {
  for (const key of keys) {
    if (source && source[key] !== undefined && source[key] !== null && source[key] !== '') {
      const number = Number(source[key]);
      if (Number.isFinite(number) && number > 0) return number;
    }
  }
  return fallback;
}

module.exports = {
  Mt5WebApiProvider,
  testMt5WebApiConnection,
  normalizeAccount,
  normalizeMt5MarginLevel,
  normalizePosition,
  normalizeVolumeLots,
  normalizeQuote,
  normalizeSymbol,
  serverTimeFromResponse,
  symbolNamesForSnapshot
};
