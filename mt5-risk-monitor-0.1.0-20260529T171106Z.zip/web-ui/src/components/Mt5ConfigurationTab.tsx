import { useEffect, useState, type ReactNode } from 'react';
import { DatabaseZap, Loader2, PlugZap, Save } from 'lucide-react';
import { AlertConditionEditor, SymbolMappingEditor } from '@/components/ConfigEditors';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { api } from '@/lib/api';
import { useI18n } from '@/i18n';
import {
  formatPercentMap,
  formatSymbolDistanceMap,
  joinCommaList,
  parseCommaList,
  parsePercentMap,
  parseSymbolDistanceMap,
  percentToRatio,
  ratioToPercent,
} from '@/lib/utils';
import { toast } from '@/hooks/use-toast';
import type { AppConfig, Mt5ConnectionStatus, Mt5ServerConfig, SnapshotSymbol } from '@/types/api';

interface Mt5ConfigurationTabProps {
  config: AppConfig;
  symbols?: SnapshotSymbol[];
  section?: 'mt5' | 'symbolList' | 'symbolMapping' | 'alertCondition';
  onChange: (config: AppConfig) => void;
  onTestConnection: (server: Mt5ServerConfig) => Promise<Mt5ConnectionStatus>;
}

export function Mt5ConfigurationTab({
  config,
  symbols = [],
  section = 'mt5',
  onChange,
  onTestConnection,
}: Mt5ConfigurationTabProps) {
  const { t } = useI18n();
  const mt5Defaults = {
    groupMasks: [] as string[],
    accountLogins: [] as Array<string | number>,
    symbolMasks: ['*'] as string[],
    baseCurrency: 'USD',
    serverTimeZone: 'GMT+3',
    serverTimeOffsetMinutes: 180,
    disconnectAfterPollMultiples: 5,
    servers: [] as AppConfig['mt5']['servers'],
  };
  const mt5 = Object.assign({}, mt5Defaults, config.mt5 || {});
  const riskDefaults = {
    stopOutLevel: 0.5,
    accountStopOutLevels: {},
    accountOverrides: {},
    alertConditions: null,
    alertDistancePointsDefault: 0,
    warningDistancePointsDefault: 0,
    dangerDistancePointsDefault: 0,
    symbolDistancePoints: {},
    warningSymbolDistancePoints: {},
    dangerSymbolDistancePoints: {},
    symbolMappings: {},
  };
  const risk = Object.assign({}, riskDefaults, config.risk || {});
  const lpDefaults = {
    enabled: false,
    name: 'LP-USD',
    balance: 0,
    equityAdjustment: 0,
    credit: 0,
    leverage: 100,
    currency: 'USD',
    mode: 'aggregateClientExposure',
    hedgeDirection: 'same' as 'same' | 'opposite',
    aggregation: 'net',
    explicitPositions: [],
  };
  const lpAccount = Object.assign({}, lpDefaults, config.lpAccount || {});
  const provider = Object.assign(
    {
      type: 'mock' as AppConfig['provider']['type'],
      mockSnapshotPath: 'examples/mock-snapshot.json',
      mt5WebApi: {
        crypt: 'aes',
        agent: 'MT5-RISK-MONITOR',
        timeoutMs: 30000,
        maxPositionsPerAccount: 5000,
      },
    },
    config.provider || {},
  );
  const server = mt5.servers?.[0] ?? {
    name: 'primary',
    host: '',
    port: 443,
    login: 0,
    passwordEnv: '',
    timeoutMs: 15000,
  };

  const [groupMasksText, setGroupMasksText] = useState(joinCommaList(mt5.groupMasks));
  const [accountLoginsText, setAccountLoginsText] = useState(joinCommaList(mt5.accountLogins));
  const [symbolMasksText, setSymbolMasksText] = useState(joinCommaList(mt5.symbolMasks));
  const [warningSymbolDistanceText, setWarningSymbolDistanceText] = useState(
    formatSymbolDistanceMap(risk.warningSymbolDistancePoints),
  );
  const [dangerSymbolDistanceText, setDangerSymbolDistanceText] = useState(
    formatSymbolDistanceMap(risk.dangerSymbolDistancePoints || risk.symbolDistancePoints),
  );
  const [syncedSymbols, setSyncedSymbols] = useState<SnapshotSymbol[]>(symbols);
  const [syncingSymbols, setSyncingSymbols] = useState(false);
  const [accountStopOutText, setAccountStopOutText] = useState(
    formatPercentMap(risk.accountStopOutLevels),
  );
  const [testingConnection, setTestingConnection] = useState(false);
  const [connectionResult, setConnectionResult] = useState<Mt5ConnectionStatus | null>(null);
  const savedPasswordHidden = server.password === '[redacted]' || server.passwordEnv === '[redacted]';
  const passwordValue = server.password && server.password !== '[redacted]' ? server.password : '';
  const passwordPlaceholder = savedPasswordHidden
    ? '已保存密码，留空不修改'
    : server.passwordEnv
      ? `留空继续使用 ${server.passwordEnv}`
      : '输入 Manager 密码（保存后隐藏）';

  useEffect(() => {
    setGroupMasksText(joinCommaList(mt5.groupMasks));
    setAccountLoginsText(joinCommaList(mt5.accountLogins));
    setSymbolMasksText(joinCommaList(mt5.symbolMasks));
    setWarningSymbolDistanceText(formatSymbolDistanceMap(risk.warningSymbolDistancePoints));
    setDangerSymbolDistanceText(formatSymbolDistanceMap(risk.dangerSymbolDistancePoints || risk.symbolDistancePoints));
    setAccountStopOutText(formatPercentMap(risk.accountStopOutLevels));
  }, [config]);

  useEffect(() => {
    setSyncedSymbols(symbols);
  }, [symbols]);

  const update = (patch: Partial<AppConfig>) => onChange({ ...config, ...patch });

  const updateServerTimeZone = (serverTimeZone: 'GMT+2' | 'GMT+3') => {
    update({
      mt5: {
        ...mt5,
        serverTimeZone,
        serverTimeOffsetMinutes: serverTimeZone === 'GMT+2' ? 120 : 180,
      },
    });
  };

  const testConnection = async () => {
    setTestingConnection(true);
    setConnectionResult(null);
    try {
      const result = await onTestConnection({
        ...server,
        providerType: provider.type,
        deepAuth: true,
        authTimeoutMs: 4000,
      });
      setConnectionResult(result);
    } catch (error) {
      const message = error instanceof Error ? error.message : '连接测试失败';
      setConnectionResult({
        status: 'disconnected',
        ok: false,
        checkedAt: new Date().toISOString(),
        latencyMs: 0,
        error: message,
        checks: [{ key: 'request', status: 'error', message }],
      });
    } finally {
      setTestingConnection(false);
    }
  };

  const refreshSymbols = async () => {
    setSyncingSymbols(true);
    try {
      const result = await api.getSymbols();
      setSyncedSymbols(result.symbols || []);
      toast({ title: t('产品列表已同步', 'Symbol list synced'), description: t(`读取到 ${result.symbols?.length || 0} 个产品。`, `${result.symbols?.length || 0} symbols loaded.`) });
    } catch (error) {
      toast({
        title: t('产品列表同步失败', 'Symbol sync failed'),
        description: error instanceof Error ? error.message : t('未知错误', 'Unknown error'),
        variant: 'destructive',
      });
    } finally {
      setSyncingSymbols(false);
    }
  };

  return (
    <div className="space-y-3 pb-16">
      {section === 'mt5' && (
        <>
          <Card>
            <CardHeader>
              <CardTitle>{t('MT5 管理账号配置', 'MT5 Manager Account Configuration')}</CardTitle>
              <CardDescription>{t('MT5 服务器、Manager 账号与运行参数', 'MT5 server, manager account, and runtime settings')}</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              <div className="space-y-1 sm:col-span-2 lg:col-span-3">
                <Label>{t('接入方式', 'Connection Type')}</Label>
                <div className="flex flex-wrap gap-2">
                  <ProviderButton active={provider.type === 'mt5WebApi'} label="MT5 Web API" description={t('Mac/Linux 直连', 'Mac/Linux Direct')} onClick={() => update({ provider: { ...provider, type: 'mt5WebApi' } })} />
                  <ProviderButton active={provider.type === 'managerApi'} label="Manager API" description={t('Windows DLL', 'Windows DLL')} onClick={() => update({ provider: { ...provider, type: 'managerApi' } })} />
                </div>
              </div>
              <Field label={t('MT5 服务器', 'MT5 Server')}>
                <Input value={server.host} onChange={(e) => update({ mt5: { ...mt5, servers: [{ ...server, host: e.target.value }] } })} />
              </Field>
              <Field label={t('MT5 端口', 'MT5 Port')}>
                <Input type="number" value={server.port} onChange={(e) => update({ mt5: { ...mt5, servers: [{ ...server, port: Number(e.target.value) }] } })} />
              </Field>
              <Field label={t('管理员账号', 'Manager Login')}>
                <Input type="number" value={server.login} onChange={(e) => update({ mt5: { ...mt5, servers: [{ ...server, login: Number(e.target.value) }] } })} />
              </Field>
              <Field label={t('密码', 'Password')}>
                <Input
                  type="password"
                  value={passwordValue}
                  autoComplete="off"
                  placeholder={passwordPlaceholder}
                  onChange={(e) => update({ mt5: { ...mt5, servers: [{ ...server, password: e.target.value }] } })}
                />
              </Field>
              <div className="space-y-1">
                <Label>{t('登录验证', 'Login Verification')}</Label>
                <div className="flex items-center gap-2">
                  <Button type="button" variant="outline" onClick={testConnection} disabled={testingConnection}>
                    {testingConnection ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <PlugZap className="h-3.5 w-3.5" />}
                    {t('登录验证', 'Verify Login')}
                  </Button>
                  {testingConnection && <span className="text-xs text-amber-400">{t('正在验证登录...', 'Verifying login...')}</span>}
                  {!testingConnection && connectionResult && (
                    <span className={connectionResult.ok ? 'text-xs text-emerald-400' : 'text-xs text-red-400'}>
                      {connectionResult.ok ? t(`登录验证通过 ${connectionResult.latencyMs ?? 0}ms`, `Login verified ${connectionResult.latencyMs ?? 0}ms`) : connectionResult.error || t('登录验证失败', 'Login verification failed')}
                    </span>
                  )}
                </div>
                {!testingConnection && connectionResult?.checks && (
                  <div className="mt-2 space-y-1 rounded-md border border-zinc-800 bg-zinc-950/60 p-2">
                    {connectionResult.checks.map((check) => (
                      <div
                        key={check.key}
                        className={check.status === 'ok' ? 'text-[11px] text-emerald-400' : check.status === 'warning' ? 'text-[11px] text-amber-400' : 'text-[11px] text-red-400'}
                      >
                        {check.message}
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <Field label={t('价格同步秒数', 'Price Sync Interval (s)')}>
                <Input type="number" min={0.1} step={0.1} value={config.runtime.pollIntervalSeconds} onChange={(e) => update({ runtime: { ...config.runtime, pollIntervalSeconds: Number(e.target.value) } })} />
              </Field>
              <Field label={t('断联判定倍数', 'Disconnect Multiplier')}>
                <Input
                  type="number"
                  min={1}
                  step={1}
                  value={mt5.disconnectAfterPollMultiples || 5}
                  onChange={(e) => update({ mt5: { ...mt5, disconnectAfterPollMultiples: Number(e.target.value) || 5 } })}
                />
              </Field>
              <div className="flex items-center gap-2 self-end pb-1">
                <Switch checked={config.runtime.autoStart !== false} onCheckedChange={(checked) => update({ runtime: { ...config.runtime, autoStart: checked } })} />
                <Label>{t('启动后自动同步价格', 'Auto-sync prices after startup')}</Label>
              </div>
              <Field label={t('服务器时区', 'Server Time Zone')}>
                <select
                  className="flex h-8 w-full rounded-md border border-zinc-700 bg-zinc-950 px-2 text-xs text-zinc-100"
                  value={mt5.serverTimeZone || ((mt5.serverTimeOffsetMinutes ?? 180) === 120 ? 'GMT+2' : 'GMT+3')}
                  onChange={(e) => updateServerTimeZone(e.target.value as 'GMT+2' | 'GMT+3')}
                >
                  <option value="GMT+3">{t('GMT+3 夏令时', 'GMT+3 Summer Time')}</option>
                  <option value="GMT+2">{t('GMT+2 冬令时', 'GMT+2 Winter Time')}</option>
                </select>
              </Field>
            </CardContent>
          </Card>

          <div className="grid gap-3 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>{t('组与账号过滤', 'Group & Account Filter')}</CardTitle>
                <CardDescription>{t('监测组与账号筛选，逗号分隔，组支持 * 和 ?', 'Monitored groups and accounts, comma-separated. Groups support * and ?.')}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Field label={t('检测组', 'Group Filter')}>
                  <Input value={groupMasksText} placeholder="Real\A*, Real\B*" onChange={(e) => { setGroupMasksText(e.target.value); update({ mt5: { ...mt5, groupMasks: parseCommaList(e.target.value) } }); }} />
                </Field>
                <Field label={t('检测账号', 'Account Filter')}>
                  <Input value={accountLoginsText} placeholder="100002" onChange={(e) => { setAccountLoginsText(e.target.value); update({ mt5: { ...mt5, accountLogins: parseCommaList(e.target.value) } }); }} />
                </Field>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>{t('LP 账号', 'LP Account')}</CardTitle>
                <CardDescription>{t('LP 余额、杠杆与敞口聚合方向', 'LP balance, leverage, and exposure aggregation direction')}</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-3 sm:grid-cols-2">
                <div className="flex items-center gap-2 sm:col-span-2">
                  <Switch checked={lpAccount.enabled} onCheckedChange={(checked) => update({ lpAccount: { ...lpAccount, enabled: checked } })} />
                  <Label>{t('启用 LP 风险监控', 'Enable LP Risk Monitoring')}</Label>
                </div>
                <Field label={t('LP 名称', 'LP Name')}>
                  <Input value={lpAccount.name} onChange={(e) => update({ lpAccount: { ...lpAccount, name: e.target.value } })} />
                </Field>
                <Field label={t('LP 余额', 'LP Balance')}>
                  <Input type="number" step="0.01" value={lpAccount.balance} onChange={(e) => update({ lpAccount: { ...lpAccount, balance: Number(e.target.value) } })} />
                </Field>
                <Field label={t('净值校正', 'Equity Adjustment')}>
                  <Input type="number" step="0.01" value={lpAccount.equityAdjustment || 0} onChange={(e) => update({ lpAccount: { ...lpAccount, equityAdjustment: Number(e.target.value) } })} />
                </Field>
                <Field label={t('LP 杠杆', 'LP Leverage')}>
                  <Input type="number" min={1} value={lpAccount.leverage} onChange={(e) => update({ lpAccount: { ...lpAccount, leverage: Number(e.target.value) } })} />
                </Field>
                <Field label={t('聚合方向', 'Aggregation Direction')}>
                  <select className="flex h-8 w-full rounded-md border border-zinc-700 bg-zinc-950 px-2 text-xs text-zinc-100" value={lpAccount.hedgeDirection} onChange={(e) => update({ lpAccount: { ...lpAccount, hedgeDirection: e.target.value as 'same' | 'opposite' } })}>
                    <option value="same">{t('客户同向', 'Same as clients')}</option>
                    <option value="opposite">{t('客户反向', 'Opposite of clients')}</option>
                  </select>
                </Field>
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {section === 'symbolList' && (
        <>
          <Card>
            <CardHeader>
              <CardTitle>{t('产品过滤', 'Symbol Filter')}</CardTitle>
              <CardDescription>{t('产品列表同步时固定读取全部 MT5 产品；这里的过滤用于风险监控持仓筛选', 'Symbol List always reads all MT5 symbols; this filter is used only for monitored positions.')}</CardDescription>
            </CardHeader>
            <CardContent>
              <Field label={t('产品过滤', 'Symbol Filter')}>
                <Input value={symbolMasksText} placeholder="*" onChange={(e) => { setSymbolMasksText(e.target.value); update({ mt5: { ...mt5, symbolMasks: parseCommaList(e.target.value) } }); }} />
              </Field>
            </CardContent>
          </Card>
          <AutoSymbolSpecPanel symbols={syncedSymbols} syncing={syncingSymbols} onRefresh={refreshSymbols} />
        </>
      )}

      {section === 'symbolMapping' && (
        <Card>
          <CardHeader>
            <CardTitle>{t('产品映射', 'Symbol Mapping')}</CardTitle>
            <CardDescription>{t('把后缀产品或不同符号折算为基准产品，例如 XAUUSD* → XAUUSD，RKGCNH → XAUUSD', 'Map suffix or custom symbols to a canonical product, for example XAUUSD* → XAUUSD and RKGCNH → XAUUSD.')}</CardDescription>
          </CardHeader>
          <CardContent>
            <SymbolMappingEditor value={risk.symbolMappings || {}} onChange={(symbolMappings) => update({ risk: { ...risk, symbolMappings } })} />
          </CardContent>
        </Card>
      )}

      {section === 'alertCondition' && (
        <>
          <Card>
            <CardHeader>
              <CardTitle>{t('告警阈值', 'Alert Thresholds')}</CardTitle>
              <CardDescription>{t('注意阈值用黄色显示，危险阈值用红色显示；账号详情里的设置优先', 'Warning thresholds are yellow and danger thresholds are red; account-level settings take priority.')}</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-2">
              <Field label={t('爆仓比例(%)', 'Stop-out Ratio (%)')}>
                <Input type="number" step="0.01" min={0} value={ratioToPercent(risk.stopOutLevel)} onChange={(e) => update({ risk: { ...risk, stopOutLevel: percentToRatio(e.target.value) } })} />
              </Field>
              <Field label={t('账号爆仓比例覆盖 (LOGIN:百分比)', 'Account Stop-out Override (LOGIN:percent)')}>
                <Input value={accountStopOutText} placeholder="1001:45%, LP-USD:30%" onChange={(e) => { setAccountStopOutText(e.target.value); update({ risk: { ...risk, accountStopOutLevels: parsePercentMap(e.target.value) } }); }} />
              </Field>
              <Field label={t('默认注意点数', 'Default Warning Points')}>
                <Input type="number" min={0} value={risk.warningDistancePointsDefault || ''} onChange={(e) => update({ risk: { ...risk, warningDistancePointsDefault: Number(e.target.value) } })} />
              </Field>
              <Field label={t('默认危险点数', 'Default Danger Points')}>
                <Input type="number" min={0} value={risk.dangerDistancePointsDefault || risk.alertDistancePointsDefault || ''} onChange={(e) => update({ risk: { ...risk, dangerDistancePointsDefault: Number(e.target.value), alertDistancePointsDefault: Number(e.target.value) } })} />
              </Field>
              <Field label={t('按产品注意覆盖 (SYMBOL:点数)', 'Warning Override by Symbol (SYMBOL:points)')}>
                <Input value={warningSymbolDistanceText} placeholder="XAUUSD:2000, EURUSD:800" onChange={(e) => { setWarningSymbolDistanceText(e.target.value); update({ risk: { ...risk, warningSymbolDistancePoints: parseSymbolDistanceMap(e.target.value) } }); }} />
              </Field>
              <Field label={t('按产品危险覆盖 (SYMBOL:点数)', 'Danger Override by Symbol (SYMBOL:points)')}>
                <Input value={dangerSymbolDistanceText} placeholder="XAUUSD:1200, EURUSD:500" onChange={(e) => { setDangerSymbolDistanceText(e.target.value); update({ risk: { ...risk, dangerSymbolDistancePoints: parseSymbolDistanceMap(e.target.value), symbolDistancePoints: parseSymbolDistanceMap(e.target.value) } }); }} />
              </Field>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t('全局告警条件', 'Global Alert Conditions')}</CardTitle>
              <CardDescription>{t('全局预警条件；账号详情里的配置会覆盖这里', 'Global alert conditions; account detail settings override these rules.')}</CardDescription>
            </CardHeader>
            <CardContent>
              <AlertConditionEditor value={risk.alertConditions || defaultAlertConditions()} onChange={(alertConditions) => update({ risk: { ...risk, alertConditions } })} />
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

function defaultAlertConditions() {
  return {
    accountScope: 'all' as const,
    op: 'or' as const,
    rules: [
      { metric: 'distancePoints', operator: 'lte' as const, value: 500 },
      { metric: 'marginLevelPercent', operator: 'lte' as const, value: 80 },
      { metric: 'grossLots', operator: 'gte' as const, value: 5 },
    ],
  };
}

interface ProviderButtonProps {
  active: boolean;
  label: string;
  description: string;
  onClick: () => void;
}

function ProviderButton({ active, label, description, onClick }: ProviderButtonProps) {
  return (
    <Button
      type="button"
      variant={active ? 'default' : 'outline'}
      className="h-auto flex-col items-start gap-0 px-3 py-2 text-left"
      onClick={onClick}
    >
      <span className="text-sm">{label}</span>
      <span className={active ? 'text-[10px] text-white/70' : 'text-[10px] text-zinc-500'}>{description}</span>
    </Button>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-1">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function AutoSymbolSpecPanel({
  symbols,
  syncing,
  onRefresh,
}: {
  symbols: SnapshotSymbol[];
  syncing: boolean;
  onRefresh: () => void;
}) {
  const { t } = useI18n();
  const visibleSymbols = (symbols || []).slice(0, 12);

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between gap-3">
        <div>
          <CardTitle>{t('产品规格', 'Product Specifications')}</CardTitle>
          <CardDescription>{t('产品合约量、最小波动点、计算公式和隔夜利息由 MT5 API 自动读取', 'Contract size, point size, calculation mode, and swap values are read automatically from the MT5 API.')}</CardDescription>
        </div>
        <Button type="button" variant="outline" size="sm" onClick={onRefresh} disabled={syncing}>
          {syncing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <DatabaseZap className="h-3.5 w-3.5" />}
          {t('同步产品', 'Sync Symbols')}
        </Button>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 rounded-md border border-emerald-900/50 bg-emerald-950/20 px-3 py-2 text-xs text-emerald-300">
          <DatabaseZap className="h-4 w-4" />
          <span>
            {symbols.length > 0
              ? t(`已读取 ${symbols.length} 个产品规格`, `${symbols.length} symbol specifications loaded`)
              : t('等待首次同步后显示 MT5 API 返回的产品规格', 'Waiting for the first sync to show product specifications returned by MT5 API')}
          </span>
        </div>

        <div className="overflow-x-auto rounded-md border border-zinc-800">
          <div className="min-w-[1040px]">
            <div className="grid grid-cols-[150px_1fr_100px_110px_120px_110px_110px_100px_100px] border-b border-zinc-800 bg-zinc-950 text-[10px] font-semibold uppercase text-zinc-500">
              <div className="px-2 py-2">{t('产品', 'Symbol')}</div>
              <div className="px-2 py-2">{t('路径/描述', 'Path / Description')}</div>
              <div className="px-2 py-2 text-right">{t('合约量', 'Contract Size')}</div>
              <div className="px-2 py-2 text-right">{t('最小波动点', 'Point')}</div>
              <div className="px-2 py-2">{t('计算公式', 'Calc Mode')}</div>
              <div className="px-2 py-2 text-right">Swap Long</div>
              <div className="px-2 py-2 text-right">Swap Short</div>
              <div className="px-2 py-2">{t('盈亏币种', 'Profit Currency')}</div>
              <div className="px-2 py-2">{t('保证金币种', 'Margin Currency')}</div>
            </div>
            <div className="divide-y divide-zinc-800/70">
              {visibleSymbols.length > 0 ? (
                visibleSymbols.map((symbol) => (
                  <div
                    key={symbol.symbol}
                    className="grid grid-cols-[150px_1fr_100px_110px_120px_110px_110px_100px_100px] items-center bg-zinc-900/40 text-xs"
                  >
                    <div className="px-2 py-2 font-mono text-zinc-100">{symbol.symbol}</div>
                    <div className="truncate px-2 py-2 text-zinc-400">{symbol.path || symbol.description || '-'}</div>
                    <div className="px-2 py-2 text-right font-mono text-zinc-200">{formatSpecNumber(symbol.contractSize)}</div>
                    <div className="px-2 py-2 text-right font-mono text-zinc-200">{formatSpecNumber(symbol.point)}</div>
                    <div className="px-2 py-2 font-mono text-[10px] text-zinc-300">{symbol.calcModeName || symbol.tradeCalcModeName || '-'}</div>
                    <div className="px-2 py-2 text-right font-mono text-zinc-300">{formatSpecNumber(symbol.swapLong)}</div>
                    <div className="px-2 py-2 text-right font-mono text-zinc-300">{formatSpecNumber(symbol.swapShort)}</div>
                    <div className="px-2 py-2 font-mono text-zinc-300">{symbol.currencyProfit || '-'}</div>
                    <div className="px-2 py-2 font-mono text-zinc-300">{symbol.currencyMargin || '-'}</div>
                  </div>
                ))
              ) : (
                <div className="px-3 py-5 text-center text-xs text-zinc-500">
                  {t('暂无产品规格数据', 'No product specification data')}
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function formatSpecNumber(value?: number) {
  if (!Number.isFinite(Number(value))) return '-';
  return Number(value).toLocaleString('en-US', { maximumFractionDigits: 8 });
}

interface SaveBarProps {
  saving: boolean;
  onSave: () => void;
}

export function ConfigSaveBar({ saving, onSave }: SaveBarProps) {
  const { t } = useI18n();
  return (
    <div className="sticky bottom-0 left-0 right-0 border-t border-zinc-800 bg-zinc-950/95 backdrop-blur px-4 py-2 flex justify-end">
      <Button onClick={onSave} disabled={saving}>
        {saving ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin" />
        ) : (
          <Save className="h-3.5 w-3.5" />
        )}
        {saving ? t('保存中...', 'Saving...') : t('保存配置', 'Save Configuration')}
      </Button>
    </div>
  );
}
