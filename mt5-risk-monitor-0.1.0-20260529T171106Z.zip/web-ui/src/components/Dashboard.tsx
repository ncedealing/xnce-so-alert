import { useMemo, useState, type ReactNode } from 'react';
import { Activity, Filter, List, Settings, ShieldAlert, Users, X } from 'lucide-react';
import { AlertConditionEditor, NotificationCooldownEditor } from '@/components/ConfigEditors';
import { RiskTable } from '@/components/RiskTable';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/hooks/use-toast';
import { directionLabel, useI18n } from '@/i18n';
import { cn, formatNumber, percentToRatio, ratioToPercent } from '@/lib/utils';
import type {
  AlertConditionExpression,
  AlertItem,
  AppConfig,
  PositionDetail,
  RiskResult,
  SymbolExposure,
  SystemStatus,
} from '@/types/api';

interface DashboardProps {
  status: SystemStatus | null;
  risk: RiskResult | null;
  config: AppConfig | null;
  saving: boolean;
  onSaveConfig: (config: AppConfig) => Promise<unknown>;
}

export function Dashboard({ status, risk, config, saving, onSaveConfig }: DashboardProps) {
  const [alertsOpen, setAlertsOpen] = useState(false);
  const [positionsOpen, setPositionsOpen] = useState(false);
  const accounts = status?.accounts ?? risk?.snapshot.accounts.length ?? 0;
  const positions = status?.positions ?? risk?.snapshot.positions.length ?? 0;
  const alerts = status?.alerts ?? risk?.alerts.length ?? 0;
  const alertRecords = risk?.alerts || [];
  const lpOverview = useMemo(() => buildLpOverview(risk, config), [risk, config]);

  return (
    <div className="flex h-full min-h-0 flex-col overflow-hidden p-6 animate-in fade-in duration-300">
      <SummaryRow
        accounts={accounts}
        positions={positions}
        alerts={alerts}
        lpOverview={lpOverview}
        onPositionsClick={() => setPositionsOpen(true)}
        onAlertsClick={() => setAlertsOpen(true)}
      />

      <div className="mt-4 flex min-h-0 flex-1 flex-col gap-4">
        <RiskTable
          result={risk}
          config={config}
          saving={saving}
          onSaveConfig={onSaveConfig}
        />
      </div>
      <AlertRecordDrawer
        open={alertsOpen}
        alerts={alertRecords}
        checkedAt={risk?.checkedAt || null}
        onClose={() => setAlertsOpen(false)}
      />
      <GlobalExposureDrawer
        open={positionsOpen}
        result={risk}
        config={config}
        saving={saving}
        onSaveConfig={onSaveConfig}
        onClose={() => setPositionsOpen(false)}
      />
    </div>
  );
}

type LpOverviewData = {
  enabled: boolean;
  login: string;
  balance: number;
  equity: number;
  floating: number;
  margin: number;
  exposures: SymbolExposure[];
};

function buildLpOverview(result: RiskResult | null, config: AppConfig | null): LpOverviewData | null {
  if (!config?.lpAccount?.enabled) return null;
  const lpName = String(config.lpAccount.name || 'LP');
  const report = (result?.reports || []).find((item) => {
    const login = String(item.account?.login ?? '');
    return login === lpName || item.account?.group === 'LP' || login.startsWith('LP');
  });
  if (!report) {
    return {
      enabled: true,
      login: lpName,
      balance: Number(config.lpAccount.balance || 0),
      equity: Number(config.lpAccount.balance || 0) + Number(config.lpAccount.equityAdjustment || 0),
      floating: Number(config.lpAccount.equityAdjustment || 0),
      margin: 0,
      exposures: [],
    };
  }
  const exposures = [...(report.symbolExposures || [])]
    .sort((left, right) => Number(right.grossLots || 0) - Number(left.grossLots || 0))
    .slice(0, 3);
  return {
    enabled: true,
    login: String(report.account?.login ?? lpName),
    balance: Number(report.account?.balance ?? config.lpAccount.balance ?? 0),
    equity: Number(report.equity || 0),
    floating: Number(report.floating || 0),
    margin: Number(report.margin || 0),
    exposures,
  };
}

function SummaryRow({
  accounts,
  positions,
  alerts,
  lpOverview,
  onPositionsClick,
  onAlertsClick,
}: {
  accounts: number;
  positions: number;
  alerts: number;
  lpOverview: LpOverviewData | null;
  onPositionsClick: () => void;
  onAlertsClick: () => void;
}) {
  const { t } = useI18n();
  return (
    <div className="shrink-0 overflow-x-auto scrollbar-thin">
      <div
        className={cn(
          'grid min-w-[980px] gap-3',
          lpOverview?.enabled
            ? 'grid-cols-[repeat(3,minmax(128px,1fr))_minmax(300px,1.45fr)_minmax(172px,1fr)_minmax(172px,1fr)]'
            : 'grid-cols-3',
        )}
      >
        <SummaryMetric label={t('监测账号总数', 'Monitored Accounts')} value={accounts} icon={<Users className="h-4 w-4" />} />
        <SummaryMetric label={t('持仓订单总数', 'Open Positions')} value={positions} icon={<Activity className="h-4 w-4" />} onClick={onPositionsClick} />
        <SummaryMetric
          label={t('高危告警数', 'Critical Alerts')}
          value={alerts}
          icon={<ShieldAlert className="h-4 w-4 text-red-500" />}
          tone={alerts > 0 ? 'danger' : 'default'}
          onClick={onAlertsClick}
        />
        {lpOverview?.enabled && (
          <>
            <LpExposureMetric exposures={lpOverview.exposures} />
            <SummaryMetric
              label={t('LP净值 / 余额', 'LP Equity / Balance')}
              value={`$${formatNumber(lpOverview.equity)}`}
              sub={`${t('余额', 'Balance')} $${formatNumber(lpOverview.balance)}`}
              subTone="primary"
              mono
            />
            <SummaryMetric
              label={t('LP浮动盈亏', 'LP Floating P/L')}
              value={`${lpOverview.floating >= 0 ? '+' : ''}$${formatNumber(lpOverview.floating)}`}
              sub={lpOverview.margin > 0 ? `${t('预付款', 'Margin')} $${formatNumber(lpOverview.margin)}` : undefined}
              tone={lpOverview.floating >= 0 ? 'positive' : 'danger'}
              mono
            />
          </>
        )}
      </div>
    </div>
  );
}

function SummaryMetric({
  label,
  value,
  sub,
  icon,
  tone = 'default',
  mono,
  subTone = 'muted',
  onClick,
}: {
  label: string;
  value: string | number;
  sub?: string;
  icon?: ReactNode;
  tone?: 'default' | 'positive' | 'danger';
  mono?: boolean;
  subTone?: 'muted' | 'primary';
  onClick?: () => void;
}) {
  const Component = onClick ? 'button' : 'div';
  return (
    <Component
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      className={cn(
        'flex min-h-[64px] min-w-0 flex-col justify-between rounded-md border border-zinc-800 bg-zinc-900 px-4 py-2.5 text-left shadow-sm',
        onClick && 'cursor-pointer transition-colors hover:border-emerald-900/70 hover:bg-emerald-950/10',
      )}
    >
      <div className="flex items-center justify-between gap-2 text-zinc-400">
        <p className="truncate text-xs font-medium">{label}</p>
        {icon}
      </div>
      <div
        className={cn(
          'truncate text-lg font-bold leading-none tracking-tight',
          mono && 'font-mono tabular-nums',
          tone === 'positive' ? 'text-emerald-400' : tone === 'danger' ? 'text-red-500' : 'text-zinc-100',
        )}
      >
        {value}
      </div>
      {sub && <div className={cn('truncate text-[10px]', subTone === 'primary' ? 'font-mono text-zinc-100' : 'text-zinc-500')}>{sub}</div>}
    </Component>
  );
}

function LpExposureMetric({ exposures }: { exposures: SymbolExposure[] }) {
  const { language, t } = useI18n();
  return (
    <div className="flex min-h-[64px] min-w-0 flex-col justify-between rounded-md border border-zinc-800 bg-zinc-900 px-4 py-2.5 shadow-sm">
      <div className="truncate text-xs font-medium text-zinc-400">{t('LP主要净头寸', 'LP Main Net Exposure')}</div>
      {exposures.length ? (
        <div className="flex min-w-0 flex-nowrap gap-1.5 overflow-hidden">
          {exposures.map((exposure) => (
            <span
              key={exposure.symbol}
              className={cn(
                'max-w-full shrink-0 truncate rounded border px-2 py-1 font-mono text-[11px] font-bold tabular-nums',
                exposure.netDirection === 'SELL'
                  ? 'border-red-900/60 bg-red-950/20 text-red-300'
                  : exposure.netDirection === 'BUY'
                    ? 'border-emerald-900/60 bg-emerald-950/20 text-emerald-300'
                    : 'border-zinc-800 bg-zinc-950 text-zinc-400',
              )}
            >
              {exposure.symbol} {directionLabel(exposure.netDirection, language)} {formatNumber(Math.abs(Number(exposure.netLots || 0)), 2)}
            </span>
          ))}
        </div>
      ) : (
        <div className="font-mono text-lg font-bold text-zinc-500">—</div>
      )}
    </div>
  );
}

function GlobalExposureDrawer({
  open,
  result,
  config,
  saving,
  onSaveConfig,
  onClose,
}: {
  open: boolean;
  result: RiskResult | null;
  config: AppConfig | null;
  saving: boolean;
  onSaveConfig: (config: AppConfig) => Promise<unknown>;
  onClose: () => void;
}) {
  const { t } = useI18n();
  const [tab, setTab] = useState<'positions' | 'exposure' | 'config'>('positions');
  const positions = useMemo(() => collectPositions(result), [result]);
  const exposures = useMemo(() => collectGlobalExposures(result), [result]);
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <button type="button" className="absolute inset-0 bg-black/70 backdrop-blur-sm" aria-label={t('关闭持仓汇总', 'Close position summary')} onClick={onClose} />
      <aside className="animate-slide-in relative flex h-full w-[min(96vw,1180px)] max-w-full flex-col border-l border-zinc-800 bg-zinc-950 shadow-2xl">
        <div className="flex h-16 shrink-0 items-center justify-between border-b border-zinc-800 bg-zinc-900 px-5">
          <div className="flex items-center gap-3">
            <Activity className="h-5 w-5 text-emerald-400" />
            <div>
              <h2 className="text-base font-semibold text-zinc-100">{t('全局持仓与敞口', 'Global Positions & Exposure')}</h2>
              <p className="text-[11px] text-zinc-500">{t(`${positions.length} 笔持仓，${exposures.length} 个汇总产品`, `${positions.length} positions, ${exposures.length} aggregated symbols`)}</p>
            </div>
          </div>
          <button type="button" onClick={onClose} className="rounded-full p-2 text-zinc-400 transition-colors hover:bg-zinc-800 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="flex shrink-0 gap-4 border-b border-zinc-800 bg-zinc-900/50 px-5">
          <DrawerTab active={tab === 'positions'} onClick={() => setTab('positions')} icon={<List className="h-4 w-4" />}>{t('全部持仓', 'All Positions')}</DrawerTab>
          <DrawerTab active={tab === 'exposure'} onClick={() => setTab('exposure')} icon={<Filter className="h-4 w-4" />}>{t('敞口汇总', 'Exposure Summary')}</DrawerTab>
          <DrawerTab active={tab === 'config'} onClick={() => setTab('config')} icon={<Settings className="h-4 w-4" />}>{t('全局账号配置', 'Global Account Settings')}</DrawerTab>
        </div>
        <div className="flex-1 overflow-y-auto p-5 scrollbar-thin">
          {tab === 'positions' ? (
            <GlobalPositionsTable positions={positions} />
          ) : tab === 'exposure' ? (
            <GlobalExposureTable exposures={exposures} />
          ) : (
            <GlobalAccountConfig config={config} saving={saving} onSaveConfig={onSaveConfig} />
          )}
        </div>
      </aside>
    </div>
  );
}

function collectPositions(result: RiskResult | null): PositionDetail[] {
  return (result?.reports || []).flatMap((report) =>
    (report.positionDetails || report.positions || []).map((position) => ({
      ...position,
      login: position.login ?? report.account?.login ?? '—',
    })),
  );
}

type GlobalExposure = {
  symbol: string;
  accountCount: number;
  positionCount: number;
  buyLots: number;
  sellLots: number;
  grossLots: number;
  netLots: number;
  netDirection: string;
  profit: number;
  swap: number;
  commission: number;
  netProfit: number;
  minDistancePoints: number;
};

function collectGlobalExposures(result: RiskResult | null): GlobalExposure[] {
  const bySymbol = new Map<string, GlobalExposure & { accounts: Set<string> }>();
  for (const report of result?.reports || []) {
    for (const exposure of report.symbolExposures || []) {
      const current = bySymbol.get(exposure.symbol) || {
        symbol: exposure.symbol,
        accountCount: 0,
        accounts: new Set<string>(),
        positionCount: 0,
        buyLots: 0,
        sellLots: 0,
        grossLots: 0,
        netLots: 0,
        netDirection: 'FLAT',
        profit: 0,
        swap: 0,
        commission: 0,
        netProfit: 0,
        minDistancePoints: Number.POSITIVE_INFINITY,
      };
      current.accounts.add(String(report.account?.login ?? '—'));
      current.positionCount += Number(exposure.positionCount || 0);
      current.buyLots += Number(exposure.buyLots || 0);
      current.sellLots += Number(exposure.sellLots || 0);
      current.grossLots += Number(exposure.grossLots || 0);
      current.netLots += signedNetLots(exposure);
      current.profit += Number(exposure.profit || 0);
      current.swap += Number(exposure.swap || 0);
      current.commission += Number(exposure.commission || 0);
      current.netProfit += Number(exposure.netProfit ?? Number(exposure.profit || 0) + Number(exposure.swap || 0) + Number(exposure.commission || 0));
      current.minDistancePoints = Math.min(current.minDistancePoints, Number(exposure.risk?.distancePoints ?? Number.POSITIVE_INFINITY));
      bySymbol.set(exposure.symbol, current);
    }
  }
  return [...bySymbol.values()]
    .map(({ accounts, ...item }) => ({
      ...item,
      accountCount: accounts.size,
      netDirection: item.netLots > 1e-9 ? 'BUY' : item.netLots < -1e-9 ? 'SELL' : 'FLAT',
    }))
    .sort((left, right) => right.grossLots - left.grossLots);
}

function signedNetLots(exposure: SymbolExposure) {
  const lots = Math.abs(Number(exposure.netLots || exposure.absNetLots || 0));
  if (exposure.netDirection === 'BUY') return lots;
  if (exposure.netDirection === 'SELL') return -lots;
  return 0;
}

function GlobalPositionsTable({ positions }: { positions: PositionDetail[] }) {
  const { language, t } = useI18n();
  if (!positions.length) return <EmptyDrawerState text={t('暂无持仓订单', 'No open positions')} />;
  return (
    <table className="w-full whitespace-nowrap rounded-md border border-zinc-800 text-left text-xs text-zinc-400">
      <thead className="bg-zinc-900 text-[10px] uppercase text-zinc-500">
        <tr>
          <th className="px-3 py-2">{t('账号', 'Login')}</th>
          <th className="px-3 py-2">{t('订单号', 'Ticket')}</th>
          <th className="px-3 py-2">{t('产品', 'Symbol')}</th>
          <th className="px-3 py-2 text-center">{t('方向', 'Side')}</th>
          <th className="px-3 py-2 text-right">{t('手数', 'Lots')}</th>
          <th className="px-3 py-2 text-right">{t('开仓/现价', 'Open / Current')}</th>
          <th className="px-3 py-2 text-right">{t('同步', 'Sync')}</th>
          <th className="px-3 py-2 text-right">{t('库存费', 'Swap')}</th>
          <th className="px-3 py-2 text-right">{t('盈亏', 'P/L')}</th>
        </tr>
      </thead>
      <tbody className="divide-y divide-zinc-800/60">
        {positions.map((position, index) => (
          <tr key={`${position.login}:${position.ticket}:${index}`} className="hover:bg-zinc-900">
            <td className="px-3 py-2 font-mono text-zinc-300">{position.login}</td>
            <td className="px-3 py-2 font-mono">{position.ticket}</td>
            <td className="px-3 py-2 font-bold text-zinc-200">{position.symbol}</td>
            <td className={cn('px-3 py-2 text-center font-bold', position.action === 'BUY' ? 'text-emerald-400' : 'text-red-400')}>{directionLabel(position.action, language)}</td>
            <td className="px-3 py-2 text-right font-mono text-zinc-300">{formatNumber(position.volumeLots, 2)}</td>
            <td className="px-3 py-2 text-right font-mono">
              {formatNumber(position.openPrice, 5)} → {formatNumber(position.currentPrice || position.closePrice, 5)}
              <span className="ml-1 text-[10px] text-zinc-600">{position.closePriceSide || ''}</span>
            </td>
            <td className="px-3 py-2 text-right font-mono text-[10px] text-zinc-500">{formatAlertTime(position.updateTime || position.quoteTime)}</td>
            <td className={cn('px-3 py-2 text-right font-mono', Number(position.swap || 0) >= 0 ? 'text-zinc-300' : 'text-red-300')}>
              {Number(position.swap || 0) > 0 ? '+' : ''}
              {formatNumber(Number(position.swap || 0), 2)}
            </td>
            <td className={cn('px-3 py-2 text-right font-bold', Number(position.profit) >= 0 ? 'text-emerald-400' : 'text-red-400')}>
              {formatNumber(position.profit)}
              <div className="text-[10px] font-normal text-zinc-500">
                {position.profitSource === 'MT5_POSITION_PROFIT' ? 'MT5' : t('计算', 'Calculated')}
                {Number(position.netProfit) !== Number(position.profit) ? ` / ${t('净', 'Net')} ${formatNumber(Number(position.netProfit), 2)}` : ''}
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function GlobalExposureTable({ exposures }: { exposures: GlobalExposure[] }) {
  const { language, t } = useI18n();
  if (!exposures.length) return <EmptyDrawerState text={t('暂无敞口汇总', 'No exposure summary')} />;
  return (
    <table className="w-full whitespace-nowrap rounded-md border border-zinc-800 text-left text-xs text-zinc-400">
      <thead className="bg-zinc-900 text-[10px] uppercase text-zinc-500">
        <tr>
          <th className="px-3 py-2">{t('产品', 'Symbol')}</th>
          <th className="px-3 py-2 text-right">{t('账号数', 'Accounts')}</th>
          <th className="px-3 py-2 text-right">{t('订单数', 'Orders')}</th>
          <th className="px-3 py-2 text-center">{t('净方向', 'Net Side')}</th>
          <th className="px-3 py-2 text-right">{t('买/卖手数', 'Buy / Sell Lots')}</th>
          <th className="px-3 py-2 text-right">{t('净手数', 'Net Lots')}</th>
          <th className="px-3 py-2 text-right">{t('最近爆仓(pip)', 'Nearest Liquidation (pip)')}</th>
          <th className="px-3 py-2 text-right">{t('交易盈亏', 'Trading P/L')}</th>
          <th className="px-3 py-2 text-right">{t('库存费', 'Swap')}</th>
          <th className="px-3 py-2 text-right">{t('净盈亏', 'Net P/L')}</th>
        </tr>
      </thead>
      <tbody className="divide-y divide-zinc-800/60">
        {exposures.map((exposure) => (
          <tr key={exposure.symbol} className="hover:bg-zinc-900">
            <td className="px-3 py-2 font-bold text-zinc-200">{exposure.symbol}</td>
            <td className="px-3 py-2 text-right font-mono">{exposure.accountCount}</td>
            <td className="px-3 py-2 text-right font-mono">{exposure.positionCount}</td>
            <td className={cn('px-3 py-2 text-center font-bold', exposure.netDirection === 'BUY' ? 'text-emerald-400' : exposure.netDirection === 'SELL' ? 'text-red-400' : 'text-zinc-500')}>{directionLabel(exposure.netDirection, language)}</td>
            <td className="px-3 py-2 text-right font-mono"><span className="text-emerald-400">{formatNumber(exposure.buyLots, 2)}</span> / <span className="text-red-400">{formatNumber(exposure.sellLots, 2)}</span></td>
            <td className="px-3 py-2 text-right font-mono">{formatNumber(Math.abs(exposure.netLots), 2)}</td>
            <td className="px-3 py-2 text-right font-mono">{Number.isFinite(exposure.minDistancePoints) ? formatNumber(exposure.minDistancePoints, 0) : '—'}</td>
            <td className={cn('px-3 py-2 text-right font-bold', exposure.profit >= 0 ? 'text-emerald-400' : 'text-red-400')}>{formatNumber(exposure.profit)}</td>
            <td className={cn('px-3 py-2 text-right font-mono', exposure.swap >= 0 ? 'text-zinc-300' : 'text-red-300')}>{formatNumber(exposure.swap, 2)}</td>
            <td className={cn('px-3 py-2 text-right font-bold', exposure.netProfit >= 0 ? 'text-emerald-400' : 'text-red-400')}>{formatNumber(exposure.netProfit, 2)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function GlobalAccountConfig({
  config,
  saving,
  onSaveConfig,
}: {
  config: AppConfig | null;
  saving: boolean;
  onSaveConfig: (config: AppConfig) => Promise<unknown>;
}) {
  const { t } = useI18n();
  const [stopOutPercent, setStopOutPercent] = useState(String(ratioToPercent(config?.risk?.stopOutLevel ?? 0.5)));
  const [warningDistancePoints, setWarningDistancePoints] = useState(String(config?.risk?.warningDistancePointsDefault ?? ''));
  const [dangerDistancePoints, setDangerDistancePoints] = useState(String(config?.risk?.dangerDistancePointsDefault ?? config?.risk?.alertDistancePointsDefault ?? ''));
  const [conditions, setConditions] = useState<AlertConditionExpression>(config?.risk?.alertConditions || defaultGlobalConditions());
  const [cooldown, setCooldown] = useState(config?.notifications?.cooldown || defaultCooldown());
  if (!config) return <EmptyDrawerState text={t('配置尚未加载', 'Configuration is not loaded')} />;

  const save = async () => {
    try {
      await onSaveConfig({
        ...config,
        risk: {
          ...config.risk,
          stopOutLevel: percentToRatio(stopOutPercent, 50),
          warningDistancePointsDefault: Number(warningDistancePoints) || 0,
          dangerDistancePointsDefault: Number(dangerDistancePoints) || 0,
          alertDistancePointsDefault: Number(dangerDistancePoints) || 0,
          alertConditions: conditions,
        },
        email: {
          ...config.email,
          cooldownSeconds: cooldown.seconds,
        },
        notifications: {
          ...config.notifications,
          cooldown,
        },
      });
      toast({ title: t('全局账号配置已保存', 'Global account settings saved'), description: t('单账号配置会继续覆盖全局规则。', 'Per-account settings continue to override global rules.') });
    } catch (error) {
      toast({ title: t('保存失败', 'Save failed'), description: error instanceof Error ? error.message : t('未知错误', 'Unknown error'), variant: 'destructive' });
    }
  };

  return (
    <div className="max-w-3xl space-y-4">
      <div className="rounded-md border border-zinc-800 bg-zinc-900 p-4 text-sm text-zinc-400">
        {t('这里是所有账号的默认规则。进入单个账号详情后保存的账号配置，会覆盖这里的全局配置。', 'These are the default rules for all accounts. Per-account settings saved in an account detail drawer override these global settings.')}
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field label={t('全局爆仓比例(%)', 'Global Stop-out Ratio (%)')}><Input value={stopOutPercent} inputMode="decimal" onChange={(event) => setStopOutPercent(event.target.value)} /></Field>
        <Field label={t('默认注意点数', 'Default Warning Points')}><Input value={warningDistancePoints} inputMode="decimal" onChange={(event) => setWarningDistancePoints(event.target.value)} /></Field>
        <Field label={t('默认危险点数', 'Default Danger Points')}><Input value={dangerDistancePoints} inputMode="decimal" onChange={(event) => setDangerDistancePoints(event.target.value)} /></Field>
      </div>
      <Field label={t('全局提醒冷却', 'Global Notification Cooldown')}>
        <NotificationCooldownEditor value={cooldown} onChange={setCooldown} />
      </Field>
      <Field label={t('全局预警条件', 'Global Alert Conditions')}><AlertConditionEditor value={conditions} onChange={setConditions} /></Field>
      <Button onClick={save} disabled={saving}>{saving ? t('保存中...', 'Saving...') : t('保存全局配置', 'Save Global Settings')}</Button>
    </div>
  );
}

function defaultCooldown() {
  return {
    seconds: 0,
    priceMovementPoints: 30,
    mode: 'priceOnly' as const,
  };
}

function DrawerTab({ active, onClick, icon, children }: { active: boolean; onClick: () => void; icon: ReactNode; children: ReactNode }) {
  return (
    <button type="button" onClick={onClick} className={cn('flex items-center gap-2 border-b-2 py-3 text-sm font-medium transition-colors', active ? 'border-emerald-500 text-emerald-400' : 'border-transparent text-zinc-400 hover:text-zinc-200')}>
      {icon}
      {children}
    </button>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return <div className="space-y-1"><Label>{label}</Label>{children}</div>;
}

function EmptyDrawerState({ text }: { text: string }) {
  return <div className="flex h-48 items-center justify-center rounded-md border border-zinc-800 bg-zinc-900 text-sm text-zinc-500">{text}</div>;
}

function defaultGlobalConditions() {
  return {
    accountScope: 'all' as const,
    op: 'or' as const,
    rules: [
      { metric: 'distancePoints', operator: 'lte' as const, value: 500 },
      { metric: 'marginLevelPercent', operator: 'lte' as const, value: 80 },
      { metric: 'grossLots', operator: 'gte' as const, value: 5 },
    ],
  };
}

function AlertRecordDrawer({
  open,
  alerts,
  checkedAt,
  onClose,
}: {
  open: boolean;
  alerts: AlertItem[];
  checkedAt: string | null;
  onClose: () => void;
}) {
  const { t } = useI18n();
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <button
        type="button"
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        aria-label={t('关闭高危告警记录', 'Close critical alert records')}
        onClick={onClose}
      />
      <aside className="animate-slide-in relative flex h-full w-[min(94vw,760px)] max-w-full flex-col border-l border-zinc-800 bg-zinc-950 shadow-2xl">
        <div className="flex h-16 shrink-0 items-center justify-between border-b border-zinc-800 bg-zinc-900 px-5">
          <div className="flex items-center gap-3">
            <ShieldAlert className="h-5 w-5 text-red-400" />
            <div>
              <h2 className="text-base font-semibold text-zinc-100">{t('高危告警记录', 'Critical Alert Records')}</h2>
              <p className="text-[11px] text-zinc-500">
                {alerts.length ? t(`${alerts.length} 条当前触发记录`, `${alerts.length} active records`) : t('当前没有触发记录', 'No active records')}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-2 text-zinc-400 transition-colors hover:bg-zinc-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 scrollbar-thin">
          {!alerts.length ? (
            <div className="flex h-48 items-center justify-center rounded-md border border-zinc-800 bg-zinc-900 text-sm text-zinc-500">
              {t('暂无高危告警', 'No critical alerts')}
            </div>
          ) : (
            <div className="space-y-3">
              {alerts.map((alert) => (
                <AlertRecordCard key={`${alert.key}:${alert.triggeredAt || checkedAt || ''}`} alert={alert} checkedAt={checkedAt} />
              ))}
            </div>
          )}
        </div>
      </aside>
    </div>
  );
}

function AlertRecordCard({ alert, checkedAt }: { alert: AlertItem; checkedAt: string | null }) {
  const { t } = useI18n();
  const risk = alert.risk || {};
  const account = alert.account || {};
  const direction = risk.direction === 'down' ? t('下跌风险', 'Downside Risk') : risk.direction === 'up' ? t('上涨风险', 'Upside Risk') : risk.direction || '—';
  const severity = String(risk.severity || '').toLowerCase();
  const danger = severity === 'danger' || risk.shouldAlert;
  const time = formatAlertTime(alert.triggeredAt || checkedAt);

  return (
    <article className={cn('rounded-md border bg-zinc-900 p-4', danger ? 'border-red-900/60' : 'border-amber-900/50')}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className={cn('text-sm font-bold tabular-nums', danger ? 'text-red-400' : 'text-amber-400')}>
            {account.login || '—'} · {risk.symbol || '—'}
          </div>
          <div className="mt-1 text-[11px] text-zinc-500">{account.group || '—'} · {direction}</div>
        </div>
        <time className="shrink-0 text-right text-[11px] font-mono text-zinc-500">{time}</time>
      </div>
      <div className="mt-4 grid gap-3 sm:grid-cols-4">
        <AlertMetric label={t('触发价', 'Trigger Price')} value={formatMaybeNumber(risk.currentPrice, 5)} />
        <AlertMetric label={t('爆仓价', 'Liquidation Price')} value={formatMaybeNumber(risk.liquidationPrice, 5)} />
        <AlertMetric label={t('距离(pip)', 'Distance (pip)')} value={formatMaybeNumber(risk.distancePoints, 0)} />
        <AlertMetric label={t('净/总手数', 'Net / Gross Lots')} value={`${formatMaybeNumber(risk.netLots, 2)} / ${formatMaybeNumber(risk.grossLots, 2)}`} />
      </div>
      {(alert.reasons || alert.subject) && (
        <div className="mt-3 rounded border border-zinc-800 bg-zinc-950 px-3 py-2 text-[11px] leading-relaxed text-zinc-400">
          {alert.reasons || alert.subject}
        </div>
      )}
    </article>
  );
}

function AlertMetric({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[10px] uppercase text-zinc-600">{label}</div>
      <div className="mt-1 font-mono text-xs tabular-nums text-zinc-200">{value}</div>
    </div>
  );
}

function formatMaybeNumber(value: unknown, digits: number) {
  const number = Number(value);
  return Number.isFinite(number) ? formatNumber(number, digits) : '—';
}

function formatAlertTime(value?: string | null) {
  if (!value) return '—';
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return '—';
  return date.toLocaleString('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
}
