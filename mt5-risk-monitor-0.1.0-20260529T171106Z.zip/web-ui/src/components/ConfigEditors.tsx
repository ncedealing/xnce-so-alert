import { useEffect, useMemo, useState } from 'react';
import { Download, Plus, Trash2, Ungroup, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useI18n } from '@/i18n';
import { cn } from '@/lib/utils';
import type {
  AlertConditionExpression,
  AlertConditionRule,
  SymbolMappingConfig,
} from '@/types/api';

const selectClass =
  'flex h-8 w-full rounded-md border border-zinc-800 bg-zinc-950 px-2 text-xs text-zinc-100 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-emerald-600';

const MAX_MAPPING_COLUMNS = 8;

type MappingSlot = {
  symbol: string;
  sourceSymbol?: string;
  sourceBaseSymbol?: string;
  hidden?: SymbolMappingConfig;
};

type MappingRow = {
  id: string;
  baseSymbol: string;
  mappings: MappingSlot[];
};

const mappingCsvColumns = ['基准产品', ...Array.from({ length: MAX_MAPPING_COLUMNS }, (_item, index) => `映射${index + 1}`)];

export function SymbolMappingEditor({
  value,
  onChange,
}: {
  value: Record<string, SymbolMappingConfig>;
  onChange: (value: Record<string, SymbolMappingConfig>) => void;
}) {
  const { t } = useI18n();
  const [rows, setRows] = useState<MappingRow[]>(() => rowsFromMappings(value));

  useEffect(() => {
    const incoming = JSON.stringify(value || {});
    const current = JSON.stringify(mappingsFromRows(rows));
    if (incoming !== current) setRows(rowsFromMappings(value));
  }, [value]);

  const commit = (nextRows: MappingRow[]) => {
    setRows(nextRows);
    onChange(mappingsFromRows(nextRows));
  };

  const updateRow = (id: string, patch: Partial<MappingRow>) => {
    commit(rows.map((row) => (row.id === id ? { ...row, ...patch } : row)));
  };

  const updateMappingSlot = (id: string, index: number, patch: Partial<MappingSlot>) => {
    commit(rows.map((row) => {
      if (row.id !== id) return row;
      const mappings = normalizeMappingSlots(row.mappings).map((slot, slotIndex) =>
        slotIndex === index ? { ...slot, ...patch } : slot,
      );
      return { ...row, mappings };
    }));
  };

  const addRow = () => setRows([...rows, emptyMappingRow()]);

  const deleteRow = (id: string) => {
    const next = rows.filter((row) => row.id !== id);
    commit(next.length ? next : [emptyMappingRow()]);
  };

  const importCsv = async (file: File | undefined) => {
    if (!file) return;
    const text = await file.text();
    const imported = rowsFromCsv(text, value || {});
    commit(imported.length ? imported : [emptyMappingRow()]);
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="max-w-3xl text-xs leading-relaxed text-zinc-500">
          {t('每行填写一个基准产品，后面最多 8 个映射产品或通配符。手数比例沿用已有规则；新映射默认 1:1。未配置时系统会按前六位自动归类。', 'Enter one base symbol per row, followed by up to 8 mapped symbols or wildcards. Existing lot ratios are preserved; new mappings default to 1:1. When no rule is configured, the system groups by the first six characters.')}
        </p>
        <div className="flex flex-wrap items-center justify-end gap-2">
          <Button type="button" variant="outline" size="sm" onClick={downloadMappingTemplate}>
            <Download className="h-3.5 w-3.5" />
            {t('下载模板', 'Download Template')}
          </Button>
          <label className="inline-flex h-7 cursor-pointer items-center justify-center gap-1.5 rounded-md border border-zinc-700 px-2.5 text-[11px] font-medium text-zinc-200 transition-colors hover:bg-zinc-800">
            <Upload className="h-3.5 w-3.5" />
            {t('上传 CSV', 'Upload CSV')}
            <input
              type="file"
              accept=".csv,text/csv"
              className="hidden"
              onChange={(event) => {
                void importCsv(event.target.files?.[0]);
                event.target.value = '';
              }}
            />
          </label>
          <Button type="button" variant="secondary" size="sm" onClick={addRow}>
            <Plus className="h-3.5 w-3.5" />
            {t('添加行', 'Add Row')}
          </Button>
        </div>
      </div>

      <div className="overflow-x-auto rounded-md border border-zinc-800">
        <div className="min-w-[1260px]">
          <div
            className="grid border-b border-zinc-800 bg-zinc-950 text-[10px] font-semibold uppercase text-zinc-500"
            style={{ gridTemplateColumns: `150px repeat(${MAX_MAPPING_COLUMNS}, minmax(120px, 1fr)) 44px` }}
          >
            <div className="px-2 py-2">{t('基准产品', 'Base Symbol')}</div>
            {Array.from({ length: MAX_MAPPING_COLUMNS }, (_item, index) => (
              <div key={index} className="px-2 py-2">{t(`映射${index + 1}`, `Mapping ${index + 1}`)}</div>
            ))}
            <div className="px-2 py-2" />
          </div>
          <div className="divide-y divide-zinc-800/70">
            {rows.map((row) => (
              <div
                key={row.id}
                className="grid items-center gap-0 bg-zinc-900/40"
                style={{ gridTemplateColumns: `150px repeat(${MAX_MAPPING_COLUMNS}, minmax(120px, 1fr)) 44px` }}
              >
                <CellInput value={row.baseSymbol} onChange={(value) => updateRow(row.id, { baseSymbol: value })} placeholder="XAUUSD" />
                {normalizeMappingSlots(row.mappings).map((slot, index) => (
                  <CellInput
                    key={index}
                    value={slot.symbol}
                    onChange={(value) => updateMappingSlot(row.id, index, { symbol: value })}
                    placeholder={index === 0 ? 'XAUUSD*' : ''}
                  />
                ))}
                <div className="px-1 py-1">
                  <Button type="button" variant="ghost" size="icon" onClick={() => deleteRow(row.id)}>
                    <Trash2 className="h-3.5 w-3.5 text-zinc-500" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function CellInput({
  value,
  onChange,
  placeholder,
  numeric,
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  numeric?: boolean;
}) {
  return (
    <div className="px-1 py-1">
      <Input
        className={cn('h-7 border-zinc-800 bg-zinc-950 text-[11px]', numeric && 'text-right')}
        value={value}
        inputMode={numeric ? 'decimal' : undefined}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
      />
    </div>
  );
}

function emptyMappingRow(): MappingRow {
  return {
    id: `mapping-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    baseSymbol: '',
    mappings: emptyMappingSlots(),
  };
}

function rowsFromMappings(value: Record<string, SymbolMappingConfig> = {}): MappingRow[] {
  const byBase = new Map<string, MappingSlot[]>();
  Object.entries(value || {}).forEach(([symbol, mapping]) => {
    const baseSymbol = mapping.baseSymbol || '';
    if (!baseSymbol) return;
    const slots = byBase.get(baseSymbol) || [];
    slots.push({
      symbol,
      sourceSymbol: symbol,
      sourceBaseSymbol: baseSymbol,
      hidden: mapping,
    });
    byBase.set(baseSymbol, slots);
  });
  const rows = Array.from(byBase.entries()).flatMap(([baseSymbol, slots], baseIndex) => {
    const chunks: MappingRow[] = [];
    for (let index = 0; index < Math.max(1, Math.ceil(slots.length / MAX_MAPPING_COLUMNS)); index += 1) {
      chunks.push({
        id: `mapping-${baseIndex}-${index}-${baseSymbol}`,
        baseSymbol,
        mappings: normalizeMappingSlots(slots.slice(index * MAX_MAPPING_COLUMNS, (index + 1) * MAX_MAPPING_COLUMNS)),
      });
    }
    return chunks;
  });
  return rows.length ? rows : [emptyMappingRow()];
}

function mappingsFromRows(rows: MappingRow[]): Record<string, SymbolMappingConfig> {
  const result: Record<string, SymbolMappingConfig> = {};
  for (const row of rows) {
    const baseSymbol = row.baseSymbol.trim();
    if (!baseSymbol) continue;
    for (const slot of normalizeMappingSlots(row.mappings)) {
      const symbol = slot.symbol.trim();
      if (!symbol) continue;
      const canPreserveHidden = slot.hidden && slot.sourceSymbol === symbol;
      const mapping: SymbolMappingConfig = canPreserveHidden ? { ...slot.hidden, baseSymbol } : { baseSymbol };
      if (mapping.mappedLotsPerBaseLot === undefined) mapping.mappedLotsPerBaseLot = 1;
      result[symbol] = mapping;
    }
  }
  return result;
}

function rowsFromCsv(text: string, existing: Record<string, SymbolMappingConfig> = {}): MappingRow[] {
  const parsed = parseCsv(text);
  if (parsed.length < 2) return [];
  const headers = parsed[0].map((header) => header.trim());
  const normalizedHeaders = headers.map(normalizeCsvHeader);
  const baseIndex = normalizedHeaders.findIndex((header) => ['basesymbol', 'base', '基准产品'].includes(header));
  const oldSymbolIndex = normalizedHeaders.findIndex((header) => ['symbol', '映射产品', 'mappedsymbol'].includes(header));
  const oldRatioIndex = normalizedHeaders.findIndex((header) => ['mappedlotsperbaselot', 'ratio', '手数比例'].includes(header));
  const rowsByBase = new Map<string, MappingSlot[]>();

  for (const record of parsed.slice(1)) {
    if (record.every((cell) => !cell.trim())) continue;
    const baseSymbol = record[baseIndex >= 0 ? baseIndex : 0]?.trim() || '';
    if (!baseSymbol) continue;
    const symbols =
      oldSymbolIndex > -1
        ? [record[oldSymbolIndex]?.trim() || '']
        : record.slice((baseIndex >= 0 ? baseIndex : 0) + 1, (baseIndex >= 0 ? baseIndex : 0) + 1 + MAX_MAPPING_COLUMNS).map((cell) => cell.trim());
    const slots = rowsByBase.get(baseSymbol) || [];
    for (const symbol of symbols) {
      if (!symbol) continue;
      const hidden = existing[symbol] ? { ...existing[symbol] } : undefined;
      if (hidden && oldRatioIndex > -1) {
        hidden.mappedLotsPerBaseLot = optionalNumber(record[oldRatioIndex] || '') ?? hidden.mappedLotsPerBaseLot;
      }
      slots.push({
        symbol,
        sourceSymbol: hidden ? symbol : undefined,
        sourceBaseSymbol: hidden?.baseSymbol,
        hidden,
      });
    }
    rowsByBase.set(baseSymbol, slots);
  }

  return Array.from(rowsByBase.entries()).flatMap(([base, baseSlots], baseRowIndex) => {
    const chunks: MappingRow[] = [];
    for (let chunkIndex = 0; chunkIndex < Math.max(1, Math.ceil(baseSlots.length / MAX_MAPPING_COLUMNS)); chunkIndex += 1) {
      chunks.push({
        id: `csv-${Date.now()}-${baseRowIndex}-${chunkIndex}`,
        baseSymbol: base,
        mappings: normalizeMappingSlots(baseSlots.slice(chunkIndex * MAX_MAPPING_COLUMNS, (chunkIndex + 1) * MAX_MAPPING_COLUMNS)),
      });
    }
    return chunks;
  });
}

function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];
    if (char === '"' && quoted && next === '"') {
      cell += '"';
      index += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === ',' && !quoted) {
      row.push(cell);
      cell = '';
    } else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && next === '\n') index += 1;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = '';
    } else {
      cell += char;
    }
  }
  row.push(cell);
  rows.push(row);
  return rows;
}

function downloadMappingTemplate() {
  const sample = [
    mappingCsvColumns.join(','),
    ['XAUUSD', 'XAUUSD*', 'RKGUSD', 'RKGCNH', 'RKGCNY', 'GAUCNH', 'GAUUSD', '', ''].join(','),
    ['EURUSD', 'EURUSD*', '', '', '', '', '', '', ''].join(','),
  ].join('\n');
  const blob = new Blob([sample], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'symbol-mapping-template.csv';
  link.click();
  URL.revokeObjectURL(url);
}

function optionalNumber(value: string) {
  const text = value.trim();
  if (!text) return undefined;
  const number = Number(text);
  return Number.isFinite(number) ? number : undefined;
}

function emptyMappingSlots() {
  return Array.from({ length: MAX_MAPPING_COLUMNS }, () => ({ symbol: '' }));
}

function normalizeMappingSlots(slots: MappingSlot[] = []): MappingSlot[] {
  return [...slots, ...emptyMappingSlots()].slice(0, MAX_MAPPING_COLUMNS);
}

function normalizeCsvHeader(header: string) {
  return header.trim().replace(/\s+/g, '').toLowerCase();
}

type ConditionNode =
  | {
      id: string;
      kind: 'group';
      op: 'and' | 'or' | 'not';
      accountScope: 'all' | 'clientsOnly' | 'lpOnly';
      children: ConditionNode[];
    }
  | {
      id: string;
      kind: 'rule';
      enabled: boolean;
      metric: string;
      operator: string;
      value: string;
    };

export type CooldownConfig = {
  seconds: number;
  priceMovementPoints: number;
  mode: 'timeOnly' | 'priceOnly' | 'timeOrPrice' | 'timeAndPrice';
};

const metricOptions = [
  { value: 'distancePoints', labelZh: '距离爆仓(pip)', labelEn: 'Distance to Liquidation (pip)' },
  { value: 'marginLevelPercent', labelZh: '预付款比例(%)', labelEn: 'Margin Level (%)' },
  { value: 'grossLots', labelZh: '总手数', labelEn: 'Gross Lots' },
  { value: 'absNetLots', labelZh: '净手数', labelEn: 'Net Lots' },
  { value: 'netLots', labelZh: '净手数(绝对值)', labelEn: 'Net Lots (absolute)' },
  { value: 'lots', labelZh: '手数', labelEn: 'Lots' },
];

const operatorOptions = [
  { value: 'lte', label: '<=' },
  { value: 'lt', label: '<' },
  { value: 'gte', label: '>=' },
  { value: 'gt', label: '>' },
  { value: 'eq', label: '=' },
  { value: 'neq', label: '!=' },
];

export function AlertConditionEditor({
  value,
  onChange,
}: {
  value: AlertConditionExpression | null | undefined;
  onChange: (value: AlertConditionExpression) => void;
}) {
  const tree = useMemo(() => {
    const node = nodeFromExpression(value || defaultExpression(), 'root');
    return node.kind === 'group'
      ? node
      : {
          id: 'root',
          kind: 'group' as const,
          op: 'and' as const,
          accountScope: 'all' as const,
          children: [node],
        };
  }, [value]);

  const commit = (next: ConditionNode) => {
    onChange(expressionFromNode(next, true) as AlertConditionExpression);
  };

  const updateNode = (id: string, patch: Partial<ConditionNode>) => commit(updateTree(tree, id, patch));
  const deleteNode = (id: string) => commit(deleteFromTree(tree, id));
  const ungroupNode = (id: string) => commit(ungroupFromTree(tree, id));
  const addRule = (id: string) => commit(addChild(tree, id, blankRule(`${id}.${Date.now()}`)));
  const addGroup = (id: string) => commit(addChild(tree, id, blankGroup(`${id}.${Date.now()}`)));

  return (
    <div className="space-y-2 overflow-x-auto">
      <ConditionGroup
        node={tree}
        root
        onUpdate={updateNode}
        onDelete={deleteNode}
        onUngroup={ungroupNode}
        onAddRule={addRule}
        onAddGroup={addGroup}
      />
    </div>
  );
}

export function NotificationCooldownEditor({
  value,
  onChange,
}: {
  value: CooldownConfig;
  onChange: (value: CooldownConfig) => void;
}) {
  const { t } = useI18n();
  const cooldown = normalizeCooldown(value);
  return (
    <div className="grid gap-3 rounded-md border border-zinc-800 bg-zinc-950/40 p-3 sm:grid-cols-3">
      <div className="space-y-1">
        <Label>{t('冷却秒数', 'Cooldown Seconds')}</Label>
        <Input
          type="number"
          min={0}
          value={cooldown.seconds}
          onChange={(event) => onChange({ ...cooldown, seconds: Number(event.target.value) || 0 })}
        />
      </div>
      <div className="space-y-1">
        <Label>{t('不利方向变动(pip)', 'Adverse Move (pip)')}</Label>
        <Input
          type="number"
          min={0}
          value={cooldown.priceMovementPoints}
          onChange={(event) => onChange({ ...cooldown, priceMovementPoints: Number(event.target.value) || 0 })}
        />
      </div>
      <div className="space-y-1">
        <Label>{t('冷却模式', 'Cooldown Mode')}</Label>
        <select
          className={selectClass}
          value={cooldown.mode}
          onChange={(event) => onChange({ ...cooldown, mode: event.target.value as CooldownConfig['mode'] })}
        >
          <option value="priceOnly">{t('仅不利方向点位', 'Adverse move only')}</option>
          <option value="timeOnly">{t('仅时间', 'Time only')}</option>
          <option value="timeOrPrice">{t('时间或不利方向点位满足其一', 'Time or adverse move')}</option>
          <option value="timeAndPrice">{t('时间和不利方向点位同时满足', 'Time and adverse move')}</option>
        </select>
      </div>
    </div>
  );
}

function ConditionGroup({
  node,
  root,
  onUpdate,
  onDelete,
  onUngroup,
  onAddRule,
  onAddGroup,
}: {
  node: Extract<ConditionNode, { kind: 'group' }>;
  root?: boolean;
  onUpdate: (id: string, patch: Partial<ConditionNode>) => void;
  onDelete: (id: string) => void;
  onUngroup: (id: string) => void;
  onAddRule: (id: string) => void;
  onAddGroup: (id: string) => void;
}) {
  const { t } = useI18n();
  return (
    <div className={cn('space-y-2 rounded-md border border-zinc-800 bg-zinc-950/40 p-2', root && 'bg-zinc-900')}>
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div className="flex flex-wrap items-end gap-2">
          {root && (
            <div className="w-40 space-y-1">
              <Label>{t('账号范围', 'Account Scope')}</Label>
              <select
                className={selectClass}
                value={node.accountScope}
                onChange={(event) =>
                  onUpdate(node.id, { accountScope: event.target.value as 'all' | 'clientsOnly' | 'lpOnly' })
                }
              >
                <option value="all">{t('全部账号', 'All Accounts')}</option>
                <option value="clientsOnly">{t('仅客户账号', 'Client Accounts Only')}</option>
                <option value="lpOnly">{t('仅 LP 账号', 'LP Accounts Only')}</option>
              </select>
            </div>
          )}
          <div className="w-32 space-y-1">
            <Label>{root ? t('组合', 'Logic') : t('分组组合', 'Group Logic')}</Label>
            <select
              className={selectClass}
              value={node.op}
              onChange={(event) => onUpdate(node.id, { op: event.target.value as 'and' | 'or' | 'not' })}
            >
              <option value="and">AND</option>
              <option value="or">OR</option>
              <option value="not">NOT</option>
            </select>
          </div>
          <Button type="button" variant="secondary" size="sm" onClick={() => onAddRule(node.id)}>
            <Plus className="h-3.5 w-3.5" />
            {node.op === 'not' ? t('替换条件', 'Replace Rule') : t('条件', 'Rule')}
          </Button>
          <Button type="button" variant="outline" size="sm" onClick={() => onAddGroup(node.id)}>
            <Plus className="h-3.5 w-3.5" />
            {node.op === 'not' ? t('替换分组', 'Replace Group') : t('分组', 'Group')}
          </Button>
        </div>
        {!root && (
          <div className="flex items-center gap-1">
            <Button type="button" variant="outline" size="sm" onClick={() => onUngroup(node.id)}>
              <Ungroup className="h-3.5 w-3.5" />
              {t('解除分组', 'Ungroup')}
            </Button>
            <Button type="button" variant="ghost" size="sm" onClick={() => onDelete(node.id)}>
              <Trash2 className="h-3.5 w-3.5 text-zinc-500" />
              {t('删除分组', 'Delete Group')}
            </Button>
          </div>
        )}
      </div>
      {root && <ConditionHelp />}
      {!root && <p className="text-[10px] text-zinc-600">{conditionSummary(node.op, t)}</p>}
      <div className="space-y-1.5">
        {node.children.map((child, index) => {
          const connector = connectorLabel(node.op, index);
          return child.kind === 'group' ? (
            <div key={child.id} className="grid grid-cols-[54px_1fr] gap-2">
              <ConnectorBadge label={connector} />
              <ConditionGroup
                node={child}
                onUpdate={onUpdate}
                onDelete={onDelete}
                onUngroup={onUngroup}
                onAddRule={onAddRule}
                onAddGroup={onAddGroup}
              />
            </div>
          ) : (
            <ConditionRule
              key={child.id}
              node={child}
              connector={connector}
              onUpdate={onUpdate}
              onDelete={onDelete}
            />
          );
        })}
      </div>
    </div>
  );
}

function ConditionRule({
  node,
  connector,
  onUpdate,
  onDelete,
}: {
  node: Extract<ConditionNode, { kind: 'rule' }>;
  connector: string;
  onUpdate: (id: string, patch: Partial<ConditionNode>) => void;
  onDelete: (id: string) => void;
}) {
  const { t } = useI18n();
  return (
    <div className="grid min-w-[620px] grid-cols-[54px_70px_minmax(190px,1fr)_90px_120px_40px] items-end gap-2 rounded-md border border-zinc-800 bg-zinc-950 p-2">
      <ConnectorBadge label={connector} />
      <label className="flex h-8 items-center gap-2 text-xs text-zinc-400">
        <input
          type="checkbox"
          checked={node.enabled}
          onChange={(event) => onUpdate(node.id, { enabled: event.target.checked })}
        />
        {t('启用', 'Enabled')}
      </label>
      <div className="space-y-1">
        <Label>{t('指标', 'Metric')}</Label>
        <select
          className={selectClass}
          value={node.metric}
          onChange={(event) => onUpdate(node.id, { metric: event.target.value })}
        >
          {metricOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {t(option.labelZh, option.labelEn)}
            </option>
          ))}
        </select>
      </div>
      <div className="space-y-1">
        <Label>{t('关系', 'Operator')}</Label>
        <select
          className={selectClass}
          value={node.operator}
          onChange={(event) => onUpdate(node.id, { operator: event.target.value })}
        >
          {operatorOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>
      <div className="space-y-1">
        <Label>{t('数值', 'Value')}</Label>
        <Input
          value={node.value}
          inputMode="decimal"
          onChange={(event) => onUpdate(node.id, { value: event.target.value })}
        />
      </div>
      <Button type="button" variant="ghost" size="icon" onClick={() => onDelete(node.id)}>
        <Trash2 className="h-3.5 w-3.5 text-zinc-500" />
      </Button>
    </div>
  );
}

function ConnectorBadge({ label }: { label: string }) {
  return (
    <div className="flex h-8 items-center justify-center self-end">
      <span
        className={cn(
          'min-w-11 rounded border px-1.5 py-1 text-center text-[10px] font-bold tracking-wide',
          label === 'NOT'
            ? 'border-red-900/60 bg-red-950/30 text-red-300'
            : label === 'OR'
              ? 'border-blue-900/60 bg-blue-950/30 text-blue-300'
              : label === 'AND'
                ? 'border-emerald-900/60 bg-emerald-950/20 text-emerald-300'
                : 'border-zinc-700 bg-zinc-900 text-zinc-400',
        )}
      >
        {label}
      </span>
    </div>
  );
}

function ConditionHelp() {
  const { t } = useI18n();
  return (
    <div className="grid gap-2 rounded-md border border-zinc-800 bg-zinc-950 px-3 py-2 text-[11px] leading-relaxed text-zinc-500 md:grid-cols-4">
      <div>
        <span className="font-semibold text-zinc-300">{t('分组', 'Group')}</span>
        <span>{t(' 是括号，用来把几条条件先合成一个判断。', ' works like parentheses, combining rules into one expression first.')}</span>
      </div>
      <div>
        <span className="font-semibold text-emerald-300">AND</span>
        <span>{t(' 表示组内全部满足才成立。', ' means every item inside the group must be true.')}</span>
      </div>
      <div>
        <span className="font-semibold text-blue-300">OR</span>
        <span>{t(' 表示组内任意一条满足就成立。', ' means any item inside the group can be true.')}</span>
      </div>
      <div>
        <span className="font-semibold text-red-300">NOT</span>
        <span>{t(' 表示对第一条条件或分组取反。', ' negates the first rule or group.')}</span>
      </div>
    </div>
  );
}

function conditionSummary(op: 'and' | 'or' | 'not', t: (zh: string, en: string) => string) {
  if (op === 'and') return t('该分组要求内部条件全部满足。', 'This group requires all internal conditions to match.');
  if (op === 'or') return t('该分组要求内部任意条件满足。', 'This group requires any internal condition to match.');
  return t('该分组只使用第一条条件或分组，并对结果取反。', 'This group uses only the first rule or group, then negates it.');
}

function connectorLabel(op: 'and' | 'or' | 'not', index = 0) {
  if (op === 'not') return 'NOT';
  if (index === 0) return 'IF';
  return op.toUpperCase();
}

function defaultExpression(): AlertConditionExpression {
  return {
    accountScope: 'all',
    op: 'or',
    rules: [
      { metric: 'distancePoints', operator: 'lte', value: 500 },
      { metric: 'marginLevelPercent', operator: 'lte', value: 80 },
      { metric: 'grossLots', operator: 'gte', value: 5 },
    ],
  };
}

function blankGroup(id: string): Extract<ConditionNode, { kind: 'group' }> {
  return {
    id,
    kind: 'group',
    op: 'and',
    accountScope: 'all',
    children: [blankRule(`${id}.0`)],
  };
}

function blankRule(id: string): Extract<ConditionNode, { kind: 'rule' }> {
  return {
    id,
    kind: 'rule',
    enabled: true,
    metric: 'distancePoints',
    operator: 'lte',
    value: '500',
  };
}

function nodeFromExpression(expression: AlertConditionExpression | AlertConditionRule, id: string): ConditionNode {
  const maybeRule = expression as AlertConditionRule & { type?: string; op?: string; threshold?: number };
  if ('metric' in expression || 'type' in expression) {
    const metric = maybeRule.metric || maybeRule.type || 'distancePoints';
    const value = maybeRule.value ?? maybeRule.threshold ?? 0;
    return {
      id,
      kind: 'rule',
      enabled: maybeRule.enabled !== false,
      metric: metric === 'marginLevel' ? 'marginLevelPercent' : metric,
      operator: maybeRule.operator || maybeRule.op || 'lte',
      value: String(metric === 'marginLevel' ? Number(value) * 100 : value),
    };
  }
  const maybeGroup = expression as AlertConditionExpression & {
    children?: Array<AlertConditionExpression | AlertConditionRule>;
  };
  const children = (maybeGroup.rules || maybeGroup.children || []).map((rule, index) =>
    nodeFromExpression(rule, `${id}.${index}`),
  );
  return {
    id,
    kind: 'group',
    op: String(maybeGroup.op || maybeGroup.logic || 'and').toLowerCase() as 'and' | 'or' | 'not',
    accountScope: maybeGroup.accountScope || 'all',
    children: children.length ? children : [blankRule(`${id}.0`)],
  };
}

function expressionFromNode(node: ConditionNode, root = false): AlertConditionExpression | AlertConditionRule | null {
  if (node.kind === 'rule') {
    if (!node.enabled) return null;
    const value = Number(node.value);
    return {
      metric: node.metric,
      operator: node.operator as AlertConditionRule['operator'],
      value: Number.isFinite(value) ? value : 0,
    } as AlertConditionRule;
  }
  const rules = node.children
    .map((child) => expressionFromNode(child))
    .filter(Boolean) as Array<AlertConditionExpression | AlertConditionRule>;
  const expression: AlertConditionExpression = {
    op: node.op,
    rules: rules.length ? (node.op === 'not' ? rules.slice(0, 1) : rules) : [{ metric: 'distancePoints', operator: 'lte', value: -1 }],
  };
  if (root) expression.accountScope = node.accountScope;
  return expression;
}

function updateTree(root: ConditionNode, id: string, patch: Partial<ConditionNode>): ConditionNode {
  if (root.id === id) return normalizeNodeAfterPatch({ ...root, ...patch } as ConditionNode);
  if (root.kind === 'rule') return root;
  return { ...root, children: root.children.map((child) => updateTree(child, id, patch)) };
}

function normalizeCooldown(value: Partial<CooldownConfig> | undefined): CooldownConfig {
  return {
    seconds: Number(value?.seconds) || 0,
    priceMovementPoints: Number(value?.priceMovementPoints) || 30,
    mode: value?.mode || 'priceOnly',
  };
}

function addChild(root: ConditionNode, id: string, child: ConditionNode): ConditionNode {
  if (root.kind === 'group' && root.id === id) {
    const children = root.op === 'not' ? [child] : [...root.children, child];
    return { ...root, children };
  }
  if (root.kind === 'rule') return root;
  return { ...root, children: root.children.map((item) => addChild(item, id, child)) };
}

function deleteFromTree(root: ConditionNode, id: string): ConditionNode {
  if (root.id === id) return root;
  if (root.kind === 'rule') return root;
  const children = root.children
    .filter((child) => child.id !== id)
    .map((child) => deleteFromTree(child, id));
  return { ...root, children: children.length ? children : [blankRule(`${root.id}.0`)] };
}

function ungroupFromTree(root: ConditionNode, id: string): ConditionNode {
  if (root.kind === 'rule') return root;
  const children = root.children.flatMap((child) => {
    if (child.kind === 'group' && child.id === id) return child.children;
    return [ungroupFromTree(child, id)];
  });
  return normalizeGroupChildren({ ...root, children: children.length ? children : [blankRule(`${root.id}.0`)] });
}

function normalizeNodeAfterPatch(node: ConditionNode): ConditionNode {
  if (node.kind === 'rule') return node;
  return normalizeGroupChildren(node);
}

function normalizeGroupChildren(node: Extract<ConditionNode, { kind: 'group' }>): Extract<ConditionNode, { kind: 'group' }> {
  if (node.op !== 'not') return node;
  return { ...node, children: node.children.slice(0, 1).length ? node.children.slice(0, 1) : [blankRule(`${node.id}.0`)] };
}
