'use strict';

const { MockProvider } = require('./mockProvider');
const { ManagerApiProvider } = require('./managerApiProvider');
const { Mt5WebApiProvider } = require('./mt5WebApiProvider');

function createProvider(config) {
  if (config.provider.type === 'mock') return new MockProvider(config);
  if (config.provider.type === 'managerApi') return new ManagerApiProvider(config);
  if (config.provider.type === 'mt5WebApi') return new Mt5WebApiProvider(config);
  throw new Error(`Unsupported provider.type: ${config.provider.type}`);
}

module.exports = {
  createProvider
};
