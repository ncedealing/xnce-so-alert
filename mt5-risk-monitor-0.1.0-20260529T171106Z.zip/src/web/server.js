'use strict';

const http = require('node:http');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');
const fs = require('node:fs/promises');
const path = require('node:path');
const { URL } = require('node:url');
const { buildAlertContext } = require('../alerts/alertEngine');
const { renderTemplate } = require('../alerts/templateRenderer');
const { createMailer } = require('../mail/smtpMailer');
const {
  defaultMessageTemplate,
  extractChatsFromUpdates,
  getTelegramUpdates,
  normalizeChatIds,
  sendTelegramMessage
} = require('../notifications/telegramNotifier');
const { publicConfig } = require('../webState');
const {
  authEnabled,
  createSession,
  currentSession,
  destroySession,
  hashPassword,
  listPublicUsers,
  passwordPolicyText,
  publicAuthStatus,
  userByUsername,
  validatePassword,
  validateUsername,
  verifyPassword
} = require('./auth');

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml; charset=utf-8'
};

function sendJson(res, statusCode, body) {
  res.writeHead(statusCode, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store'
  });
  res.end(JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (chunk) => {
      raw += chunk;
      if (raw.length > 2_000_000) {
        reject(new Error('Request body too large'));
        req.destroy();
      }
    });
    req.on('end', () => resolve(raw));
    req.on('error', reject);
  });
}

function readBinaryBody(req, limitBytes = 200 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limitBytes) {
        reject(new Error(`Upload too large, limit ${Math.round(limitBytes / 1024 / 1024)} MB`));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function tokenAuthOk(req, config, url = null) {
  const tokenEnv = config.web && config.web.authTokenEnv;
  if (!tokenEnv) return false;
  const expected = process.env[tokenEnv];
  if (!expected) return false;
  const header = req.headers.authorization || '';
  const queryToken = url && url.searchParams ? url.searchParams.get('token') : '';
  return header === `Bearer ${expected}` || queryToken === expected;
}

function authOk(req, config, sessions, url = null) {
  if (tokenAuthOk(req, config, url)) return true;
  if (config.web && config.web.authTokenEnv && !authEnabled(config)) return false;
  if (!authEnabled(config)) return true;
  return Boolean(currentSession(req, config, sessions));
}

function serializeResult(result) {
  if (!result) return null;
  return {
    checkedAt: result.checkedAt,
    snapshot: result.snapshot,
    reports: result.reports,
    alerts: result.alerts.map((alert) => ({
      key: alert.key,
      subject: alert.subject,
      triggeredAt: alert.context.generatedAt || result.checkedAt,
      reasons: alert.context.alert && alert.context.alert.conditions ? alert.context.alert.conditions : '',
      account: alert.context.account,
      risk: serializeAlertRisk(alert)
    }))
  };
}

function serializePublicConfig(config) {
  const clone = publicConfig(config);
  if (clone.web && clone.web.auth && Array.isArray(clone.web.auth.users)) {
    clone.web.auth.users = listPublicUsers(config);
  }
  return clone;
}

function serializeAlertRisk(alert) {
  const symbolRisk = alert.symbolRisk;
  if (!symbolRisk) return alert.context.risk;
  return {
    symbol: symbolRisk.symbol,
    direction: symbolRisk.direction,
    currentPrice: symbolRisk.currentPrice,
    liquidationPrice: symbolRisk.liquidationPrice,
    distancePoints: symbolRisk.distancePoints,
    alertDistancePoints: symbolRisk.alertDistancePoints,
    warningDistancePoints: symbolRisk.warningDistancePoints,
    dangerDistancePoints: symbolRisk.dangerDistancePoints,
    severity: symbolRisk.severity,
    shouldAlert: symbolRisk.shouldAlert,
    grossLots: symbolRisk.grossLots,
    netLots: symbolRisk.netLots,
    absNetLots: symbolRisk.absNetLots,
    netDirection: symbolRisk.netDirection,
    quote: symbolRisk.quote
  };
}

async function serveStatic(req, res, publicDir) {
  const url = new URL(req.url, 'http://localhost');
  const pathname = decodeURIComponent(url.pathname);
  const safePath = pathname === '/' ? '/index.html' : pathname;
  const resolved = path.resolve(publicDir, `.${safePath}`);
  if (!resolved.startsWith(publicDir)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }
  try {
    const body = await fs.readFile(resolved);
    const type = MIME_TYPES[path.extname(resolved)] || 'application/octet-stream';
    res.writeHead(200, { 'content-type': type });
    res.end(body);
  } catch (error) {
    if (error.code === 'ENOENT') {
      res.writeHead(404);
      res.end('Not found');
      return;
    }
    throw error;
  }
}

function sendSse(res, event, data) {
  res.write(`event: ${event}\n`);
  res.write(`data: ${JSON.stringify(data)}\n\n`);
}

function ssePayload(event, payload) {
  if (event === 'risk') return serializeResult(payload);
  return payload;
}

function handleEvents(req, res, state) {
  res.writeHead(200, {
    'content-type': 'text/event-stream; charset=utf-8',
    'cache-control': 'no-store, no-transform',
    connection: 'keep-alive',
    'x-accel-buffering': 'no'
  });
  res.write(': connected\n\n');
  sendSse(res, 'status', state.status());
  if (state.lastResult) sendSse(res, 'risk', serializeResult(state.lastResult));

  const unsubscribe = state.subscribe(({ event, payload, emittedAt }) => {
    sendSse(res, event, {
      emittedAt,
      payload: ssePayload(event, payload)
    });
  });
  req.on('close', unsubscribe);
}

async function handleAuthApi(req, res, state, sessions, url) {
  if (req.method === 'GET' && url.pathname === '/api/auth/status') {
    sendJson(res, 200, publicAuthStatus(req, state.config, sessions));
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/auth/login') {
    const body = JSON.parse(await readBody(req));
    if (!authEnabled(state.config)) {
      sendJson(res, 200, { ok: true, ...publicAuthStatus(req, state.config, sessions) });
      return true;
    }
    const user = userByUsername(state.config, body.username);
    const verified = user && await verifyPassword(body.password || '', user.passwordHash);
    if (!verified) {
      sendJson(res, 401, { error: '用户名或密码错误' });
      return true;
    }
    createSession(req, res, state.config, sessions, user);
    sendJson(res, 200, {
      ok: true,
      enabled: true,
      authenticated: true,
      user: { username: user.username, role: user.role || 'admin' }
    });
    return true;
  }

  if (!authOk(req, state.config, sessions, url)) {
    sendJson(res, 401, { error: 'Unauthorized' });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/auth/logout') {
    destroySession(req, res, state.config, sessions);
    sendJson(res, 200, { ok: true });
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/api/auth/users') {
    sendJson(res, 200, { users: listPublicUsers(state.config) });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/auth/users') {
    const body = JSON.parse(await readBody(req));
    const username = String(body.username || '').trim();
    const password = String(body.password || '');
    if (!validateUsername(username)) {
      sendJson(res, 400, { error: '用户名需以字母开头，长度 8-32，只能包含字母、数字、下划线和中划线' });
      return true;
    }
    if (!validatePassword(password)) {
      sendJson(res, 400, { error: passwordPolicyText() });
      return true;
    }
    const users = [...(((state.config.web || {}).auth || {}).users || [])];
    if (users.some((user) => user.username === username)) {
      sendJson(res, 409, { error: '用户已存在' });
      return true;
    }
    users.push({
      username,
      role: 'admin',
      passwordHash: await hashPassword(password),
      createdAt: new Date().toISOString()
    });
    await saveAuthUsers(state, users);
    sendJson(res, 200, { ok: true, users: listPublicUsers(state.config) });
    return true;
  }

  const userPathMatch = /^\/api\/auth\/users\/([^/]+)$/.exec(url.pathname);
  if (userPathMatch && req.method === 'POST' && url.searchParams.get('action') === 'reset-password') {
    const session = currentSession(req, state.config, sessions);
    const username = decodeURIComponent(userPathMatch[1]);
    const body = JSON.parse(await readBody(req));
    const password = String(body.newPassword || '');
    if (!validatePassword(password)) {
      sendJson(res, 400, { error: passwordPolicyText() });
      return true;
    }
    if (session && session.username === username) {
      sendJson(res, 400, { error: '不能在这里重置当前登录用户密码，请使用“修改密码”。' });
      return true;
    }
    const users = [...(((state.config.web || {}).auth || {}).users || [])];
    const index = users.findIndex((user) => user.username === username);
    if (index < 0) {
      sendJson(res, 404, { error: '用户不存在' });
      return true;
    }
    users[index] = {
      ...users[index],
      passwordHash: await hashPassword(password),
      updatedAt: new Date().toISOString()
    };
    await saveAuthUsers(state, users);
    sendJson(res, 200, { ok: true, users: listPublicUsers(state.config) });
    return true;
  }

  if (userPathMatch && req.method === 'DELETE') {
    const session = currentSession(req, state.config, sessions);
    const username = decodeURIComponent(userPathMatch[1]);
    const users = [...(((state.config.web || {}).auth || {}).users || [])];
    if (users.length <= 1) {
      sendJson(res, 400, { error: '至少需要保留一个管理员用户' });
      return true;
    }
    if (session && session.username === username) {
      sendJson(res, 400, { error: '不能删除当前登录用户，请先使用其他管理员账号登录。' });
      return true;
    }
    const nextUsers = users.filter((user) => user.username !== username);
    if (nextUsers.length === users.length) {
      sendJson(res, 404, { error: '用户不存在' });
      return true;
    }
    await saveAuthUsers(state, nextUsers);
    sendJson(res, 200, { ok: true, users: listPublicUsers(state.config) });
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/auth/change-password') {
    const session = currentSession(req, state.config, sessions);
    const body = JSON.parse(await readBody(req));
    const password = String(body.newPassword || '');
    if (!validatePassword(password)) {
      sendJson(res, 400, { error: passwordPolicyText() });
      return true;
    }
    const users = [...(((state.config.web || {}).auth || {}).users || [])];
    const index = users.findIndex((user) => user.username === session.username);
    if (index < 0) {
      sendJson(res, 404, { error: '当前用户不存在' });
      return true;
    }
    if (!(await verifyPassword(body.currentPassword || '', users[index].passwordHash))) {
      sendJson(res, 401, { error: '当前密码错误' });
      return true;
    }
    users[index] = {
      ...users[index],
      passwordHash: await hashPassword(password),
      updatedAt: new Date().toISOString()
    };
    await saveAuthUsers(state, users);
    sendJson(res, 200, { ok: true });
    return true;
  }

  return false;
}

async function saveAuthUsers(state, users) {
  const currentAuth = ((state.config.web || {}).auth) || {};
  const next = {
    ...state.config,
    web: {
      ...(state.config.web || {}),
      auth: {
        ...currentAuth,
        enabled: currentAuth.enabled === false ? false : true,
        users
      }
    }
  };
  await state.saveConfig(next);
}

async function readEmailTemplate(state) {
  if (state.config.email && state.config.email.templateHtml) {
    return state.config.email.templateHtml;
  }
  const templatePath = state.config.email && state.config.email.templatePath
    ? path.resolve(state.config.__cwd || process.cwd(), state.config.email.templatePath)
    : path.resolve(state.config.__cwd || process.cwd(), 'templates/liquidation-alert.html');
  return fs.readFile(templatePath, 'utf8');
}

function sampleEmailAlertContext(config) {
  const symbolRisk = {
    symbol: 'XAUUSD',
    direction: 'down',
    currentPrice: 4508.08,
    liquidationPrice: 4478.37,
    distancePoints: 3374,
    alertDistancePoints: 300,
    warningDistancePoints: 4000,
    dangerDistancePoints: 300,
    stopOutLevel: 0.5,
    quote: { bid: 4500.0, ask: 4500.15 },
    grossLots: 0.7,
    netLots: 0.3,
    alertReason: '模拟触发：距离爆仓点数进入测试阈值',
    alertReasons: [
      '模拟触发：距离爆仓点数 3374 <= 注意阈值 4000',
      '测试邮件不会影响真实告警冷却'
    ],
    convertedPrices: [
      {
        symbol: 'XAUUSD',
        openPrice: 4508.08,
        currentPrice: 4508.08,
        liquidationPrice: 4478.37,
        distancePoints: 3374,
        point: 0.01
      },
      {
        symbol: 'RKGCNH',
        openPrice: 101.43,
        currentPrice: 101.43,
        liquidationPrice: 100.76,
        distancePoints: 67,
        point: 0.01
      }
    ]
  };
  return buildAlertContext(
    {
      account: {
        login: 100002,
        group: 'real\\Real_sale\\Basic5k',
        balance: 1000,
        currency: (config.mt5 && config.mt5.baseCurrency) || 'USD',
        leverage: 5000
      },
      equity: 1215.88,
      margin: 79.02,
      marginLevel: 15.387,
      stopOutLevel: 0.5,
      positions: [
        { ticket: 900001, symbol: 'XAUUSD', action: 'BUY', volumeLots: 0.5, openPrice: 4508.08 },
        { ticket: 900002, symbol: 'XAUUSD', action: 'SELL', volumeLots: 0.2, openPrice: 4501.25 },
        { ticket: 900003, symbol: 'RKGCNH', action: 'BUY', volumeLots: 0.1, openPrice: 101.43, canonicalSymbol: 'XAUUSD' }
      ]
    },
    symbolRisk
  );
}

async function sendTestEmail(state, body = {}) {
  const template = await readEmailTemplate(state);
  const context = sampleEmailAlertContext(state.config);
  const subject = `[测试] ${renderTemplate(state.config.email.subjectTemplate || 'MT5 Risk Monitor 测试邮件', context)}`;
  const html = renderTemplate(template, context);
  const recipients = Array.isArray(body.to) && body.to.length
    ? body.to.map((item) => String(item).trim()).filter(Boolean)
    : ((state.config.email && state.config.email.smtp && state.config.email.smtp.to) || []);
  const mailer = createMailer(state.config, { force: true });
  await mailer.send({ to: recipients, subject, html });
  return {
    ok: true,
    subject,
    to: recipients,
    transport: state.config.email.transport || 'console',
    generatedAt: context.generatedAt
  };
}

async function sendTestTelegram(state, body = {}) {
  const context = sampleEmailAlertContext(state.config);
  const telegram = state.config.telegram || {};
  const chatIds = normalizeChatIds(body.chatIds && body.chatIds.length ? body.chatIds : telegram.chatIds);
  if (chatIds.length === 0) {
    throw new Error('Telegram Chat ID 未配置：请先给机器人发送 /start，再点击“读取最近聊天”获取 Chat ID。');
  }
  const text = renderTemplate(telegram.messageTemplate || defaultMessageTemplate(), context);
  const sent = [];
  for (const chatId of chatIds) {
    await sendTelegramMessage(telegram, chatId, text);
    sent.push(String(chatId));
  }
  return {
    ok: true,
    chatIds: sent,
    generatedAt: context.generatedAt
  };
}

async function readTelegramChats(state) {
  const updates = await getTelegramUpdates(state.config.telegram || {});
  return {
    ok: true,
    chats: extractChatsFromUpdates(updates),
    updateCount: updates.length
  };
}

function systemUpdateConfig(config = {}) {
  const update = (config.web && config.web.systemUpdate) || {};
  const root = config.__cwd || process.cwd();
  return {
    enabled: update.enabled !== false,
    allowApply: update.allowApply !== false,
    maxUploadMb: Number(update.maxUploadMb || 200),
    updateDir: path.resolve(root, update.updateDir || 'updates')
  };
}

async function readUpdateStatus(state) {
  const settings = systemUpdateConfig(state.config);
  const manifestPath = path.join(settings.updateDir, 'latest.json');
  let latest = null;
  try {
    latest = JSON.parse(await fs.readFile(manifestPath, 'utf8'));
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  return {
    enabled: settings.enabled,
    allowApply: settings.allowApply,
    maxUploadMb: settings.maxUploadMb,
    updateDir: settings.updateDir,
    latest
  };
}

async function handleUpdateUpload(req, state) {
  const settings = systemUpdateConfig(state.config);
  if (!settings.enabled) throw new Error('System update upload is disabled');
  const body = await readBinaryBody(req, settings.maxUploadMb * 1024 * 1024);
  const parsed = parseMultipartFile(body, req.headers['content-type'] || '');
  if (!parsed) throw new Error('No update package found in upload');
  const fileName = safeFileName(parsed.fileName || 'update.zip');
  if (!/\.zip$/i.test(fileName)) throw new Error('Only .zip update packages are allowed');
  if (!isZipBuffer(parsed.data)) throw new Error('Uploaded file is not a valid zip package');

  const packageId = `${new Date().toISOString().replace(/[:.]/g, '-')}-${fileName}`;
  const packagesDir = path.join(settings.updateDir, 'packages');
  await fs.mkdir(packagesDir, { recursive: true });
  const packagePath = path.join(packagesDir, packageId);
  await fs.writeFile(packagePath, parsed.data);

  const manifest = {
    id: packageId,
    fileName,
    path: packagePath,
    sizeBytes: parsed.data.length,
    sha256: crypto.createHash('sha256').update(parsed.data).digest('hex'),
    uploadedAt: new Date().toISOString(),
    appliedAt: null,
    status: 'uploaded'
  };
  await writeUpdateManifest(settings, manifest);
  return manifest;
}

async function applyLatestUpdate(state) {
  const settings = systemUpdateConfig(state.config);
  if (!settings.enabled || !settings.allowApply) throw new Error('System update apply is disabled');
  const status = await readUpdateStatus(state);
  const latest = status.latest;
  if (!latest || !latest.path) throw new Error('No uploaded update package to apply');

  const entries = await listArchiveEntries(latest.path);
  validateArchiveEntries(entries);

  const extractDir = path.join(settings.updateDir, 'staged', latest.id.replace(/[^A-Za-z0-9_.-]/g, '_'));
  const backupDir = path.join(settings.updateDir, 'backups', latest.id.replace(/[^A-Za-z0-9_.-]/g, '_'));
  await fs.rm(extractDir, { recursive: true, force: true });
  await fs.mkdir(extractDir, { recursive: true });
  await runCommand('tar', ['-xf', latest.path, '-C', extractDir]);

  const sourceRoot = await detectUpdateRoot(extractDir);
  const copied = await copyAllowedUpdateFiles(sourceRoot, state.config.__cwd || process.cwd(), backupDir);
  const manifest = {
    ...latest,
    appliedAt: new Date().toISOString(),
    status: 'applied',
    backupDir,
    copied
  };
  await writeUpdateManifest(settings, manifest);
  return manifest;
}

async function writeUpdateManifest(settings, manifest) {
  await fs.mkdir(settings.updateDir, { recursive: true });
  await fs.writeFile(path.join(settings.updateDir, 'latest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
}

function parseMultipartFile(body, contentType) {
  const match = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType);
  if (!match) return null;
  const boundary = Buffer.from(`--${match[1] || match[2]}`);
  let start = body.indexOf(boundary);
  while (start >= 0) {
    const headerStart = start + boundary.length + 2;
    const headerEnd = body.indexOf(Buffer.from('\r\n\r\n'), headerStart);
    if (headerEnd < 0) return null;
    const headers = body.slice(headerStart, headerEnd).toString('utf8');
    const disposition = /content-disposition:[^\r\n]+/i.exec(headers)?.[0] || '';
    const fileName = /filename="([^"]*)"/i.exec(disposition)?.[1] || '';
    const name = /name="([^"]*)"/i.exec(disposition)?.[1] || '';
    const dataStart = headerEnd + 4;
    const next = body.indexOf(Buffer.from(`\r\n--${match[1] || match[2]}`), dataStart);
    if (next < 0) return null;
    if ((name === 'package' || name === 'file' || fileName) && fileName) {
      return { fileName, data: body.slice(dataStart, next) };
    }
    start = body.indexOf(boundary, next);
  }
  return null;
}

function isZipBuffer(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 4) return false;
  return (
    buffer[0] === 0x50 &&
    buffer[1] === 0x4b &&
    [0x03, 0x05, 0x07].includes(buffer[2]) &&
    [0x04, 0x06, 0x08].includes(buffer[3])
  );
}

function safeFileName(name) {
  return path.basename(String(name || 'update.zip')).replace(/[^A-Za-z0-9_.-]/g, '_') || 'update.zip';
}

async function listArchiveEntries(filePath) {
  const output = await runCommand('tar', ['-tf', filePath]);
  return output.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
}

function validateArchiveEntries(entries) {
  for (const entry of entries) {
    const normalized = entry.replace(/\\/g, '/');
    if (!normalized || normalized.startsWith('/') || normalized.includes('../') || normalized === '..') {
      throw new Error(`Unsafe path in update package: ${entry}`);
    }
  }
}

function runCommand(command, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => { stdout += chunk.toString(); });
    child.stderr.on('data', (chunk) => { stderr += chunk.toString(); });
    child.on('error', (error) => reject(new Error(`${command} failed to start: ${error.message}`)));
    child.on('close', (code) => {
      if (code === 0) resolve(stdout);
      else reject(new Error(`${command} exited ${code}: ${stderr || stdout}`));
    });
  });
}

async function detectUpdateRoot(extractDir) {
  const entries = await fs.readdir(extractDir, { withFileTypes: true });
  const visible = entries.filter((entry) => !entry.name.startsWith('__MACOSX') && entry.name !== '.DS_Store');
  if (visible.length === 1 && visible[0].isDirectory()) {
    const candidate = path.join(extractDir, visible[0].name);
    const candidateEntries = await fs.readdir(candidate).catch(() => []);
    if (candidateEntries.some((name) => ['package.json', 'src', 'public', 'web-ui'].includes(name))) return candidate;
  }
  return extractDir;
}

async function copyAllowedUpdateFiles(sourceRoot, appRoot, backupDir) {
  const allowed = new Set([
    'src',
    'public',
    'templates',
    'web-ui',
    'adapters',
    'scripts',
    'package.json',
    'package-lock.json'
  ]);
  const copied = [];
  const entries = await fs.readdir(sourceRoot, { withFileTypes: true });
  await fs.mkdir(backupDir, { recursive: true });
  for (const entry of entries) {
    if (!allowed.has(entry.name)) continue;
    const from = path.join(sourceRoot, entry.name);
    const to = path.join(appRoot, entry.name);
    const backupTo = path.join(backupDir, entry.name);
    try {
      await fs.cp(to, backupTo, { recursive: true, force: true });
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
    await fs.rm(to, { recursive: true, force: true });
    await fs.cp(from, to, { recursive: true, force: true });
    copied.push(entry.name);
  }
  if (!copied.length) throw new Error('No allowed application files found in update package');
  return copied;
}

async function handleApi(req, res, state, sessions = new Map()) {
  const url = new URL(req.url, 'http://localhost');

  if (req.method === 'GET' && url.pathname === '/api/health') {
    sendJson(res, 200, {
      ok: true,
      apiVersion: 13,
      routes: {
        mt5TestConnection: '/api/mt5/test-connection',
        events: '/api/events',
        symbols: '/api/symbols',
        emailTest: '/api/email/test',
        telegramTest: '/api/telegram/test',
        telegramUpdates: '/api/telegram/updates',
        systemUpdateStatus: '/api/system/update/status',
        systemUpdateUpload: '/api/system/update/upload',
        systemUpdateApply: '/api/system/update/apply',
        authStatus: '/api/auth/status'
      },
      providerTypes: ['mock', 'managerApi', 'mt5WebApi']
    });
    return;
  }

  if (url.pathname.startsWith('/api/auth/')) {
    if (await handleAuthApi(req, res, state, sessions, url)) return;
  }

  if (!authOk(req, state.config, sessions, url)) {
    sendJson(res, 401, { error: 'Unauthorized' });
    return;
  }

  if (req.method === 'GET' && url.pathname === '/api/events') {
    handleEvents(req, res, state);
    return;
  }
  if (req.method === 'GET' && url.pathname === '/api/status') {
    sendJson(res, 200, state.status());
    return;
  }
  if (req.method === 'GET' && url.pathname === '/api/config') {
    sendJson(res, 200, serializePublicConfig(state.config));
    return;
  }
  if (req.method === 'GET' && url.pathname === '/api/email-template') {
    sendJson(res, 200, { html: await readEmailTemplate(state) });
    return;
  }
  if (req.method === 'POST' && url.pathname === '/api/email/test') {
    const raw = await readBody(req);
    const body = raw ? JSON.parse(raw) : {};
    sendJson(res, 200, await sendTestEmail(state, body));
    return;
  }
  if (req.method === 'POST' && url.pathname === '/api/telegram/test') {
    const raw = await readBody(req);
    const body = raw ? JSON.parse(raw) : {};
    sendJson(res, 200, await sendTestTelegram(state, body));
    return;
  }
  if (req.method === 'POST' && url.pathname === '/api/telegram/updates') {
    sendJson(res, 200, await readTelegramChats(state));
    return;
  }
  if (req.method === 'GET' && url.pathname === '/api/system/update/status') {
    sendJson(res, 200, await readUpdateStatus(state));
    return;
  }
  if (req.method === 'POST' && url.pathname === '/api/system/update/upload') {
    const manifest = await handleUpdateUpload(req, state);
    const applyNow = url.searchParams.get('apply') === '1';
    sendJson(res, 200, {
      ok: true,
      package: manifest,
      applied: applyNow ? await applyLatestUpdate(state) : null
    });
    return;
  }
  if (req.method === 'POST' && url.pathname === '/api/system/update/apply') {
    sendJson(res, 200, { ok: true, applied: await applyLatestUpdate(state) });
    return;
  }
  if (req.method === 'GET' && url.pathname === '/api/symbols') {
    const symbols = await state.getSymbols();
    sendJson(res, 200, { symbols });
    return;
  }
  if (req.method === 'PUT' && url.pathname === '/api/config') {
    const body = JSON.parse(await readBody(req));
    await state.saveConfig(body);
    sendJson(res, 200, { ok: true, config: serializePublicConfig(state.config) });
    return;
  }
  if (req.method === 'POST' && url.pathname === '/api/check') {
    const result = await state.checkNow();
    sendJson(res, 200, serializeResult(result));
    return;
  }
  if (
    req.method === 'POST'
    && (
      url.pathname === '/api/mt5/test-connection'
      || url.pathname === '/api/mt5/test'
      || url.pathname === '/api/test-connection'
    )
  ) {
    const raw = await readBody(req);
    const body = raw ? JSON.parse(raw) : {};
    const result = await state.testMt5Connection(body.server || body);
    sendJson(res, 200, result);
    return;
  }
  if (req.method === 'POST' && url.pathname === '/api/monitor/start') {
    state.startMonitor();
    sendJson(res, 200, state.status());
    return;
  }
  if (req.method === 'POST' && url.pathname === '/api/monitor/stop') {
    state.stopMonitor();
    sendJson(res, 200, state.status());
    return;
  }
  if (req.method === 'GET' && url.pathname === '/api/risk') {
    sendJson(res, 200, serializeResult(state.lastResult));
    return;
  }

  sendJson(res, 404, { error: 'Unknown API route' });
}

function createWebServer(state) {
  const publicDir = path.resolve(state.config.__cwd, 'public');
  const sessions = new Map();
  return http.createServer(async (req, res) => {
    try {
      if (req.url.startsWith('/api/')) {
        await handleApi(req, res, state, sessions);
      } else {
        await serveStatic(req, res, publicDir);
      }
    } catch (error) {
      sendJson(res, 500, { error: error.message, stack: error.stack });
    }
  });
}

module.exports = {
  createWebServer,
  handleApi,
  authOk,
  sendJson,
  sendSse,
  serializeResult
};
