'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');
const {
  DEFAULT_SERVER_TIME_ZONE,
  offsetMinutesFromServerTimeZone,
  normalizeServerTimeZone
} = require('./domain/serverTime');

const XAU_OUNCE_TO_KG_PRICE_MULTIPLIER = 1000 / 31.1035;
const XAU_LOTS_PER_KG_GOLD_LOT = 3.11035;

function defaultSymbolMappings() {
  return {
    'XAUUSD*': {
      baseSymbol: 'XAUUSD',
      mappedLotsPerBaseLot: 1,
      currency: 'USD'
    },
    RKGUSD: {
      baseSymbol: 'XAUUSD',
      mappedLotsPerBaseLot: XAU_LOTS_PER_KG_GOLD_LOT,
      baseToMappedPriceMultiplier: XAU_OUNCE_TO_KG_PRICE_MULTIPLIER,
      currency: 'USD'
    },
    GAUUSD: {
      baseSymbol: 'XAUUSD',
      mappedLotsPerBaseLot: XAU_LOTS_PER_KG_GOLD_LOT,
      baseToMappedPriceMultiplier: XAU_OUNCE_TO_KG_PRICE_MULTIPLIER,
      currency: 'USD'
    },
    RKGCNH: {
      baseSymbol: 'XAUUSD',
      mappedLotsPerBaseLot: XAU_LOTS_PER_KG_GOLD_LOT,
      fxSymbol: 'USDCNH',
      baseToMappedPriceMultiplier: XAU_OUNCE_TO_KG_PRICE_MULTIPLIER,
      currency: 'CNH'
    },
    GAUCNH: {
      baseSymbol: 'XAUUSD',
      mappedLotsPerBaseLot: XAU_LOTS_PER_KG_GOLD_LOT,
      fxSymbol: 'USDCNH',
      baseToMappedPriceMultiplier: XAU_OUNCE_TO_KG_PRICE_MULTIPLIER,
      currency: 'CNH'
    },
    RKGCNY: {
      baseSymbol: 'XAUUSD',
      mappedLotsPerBaseLot: XAU_LOTS_PER_KG_GOLD_LOT,
      fxSymbol: 'USDCNH',
      baseToMappedPriceMultiplier: XAU_OUNCE_TO_KG_PRICE_MULTIPLIER,
      currency: 'CNH'
    }
  };
}

function parseArgs(argv) {
  const args = {
    configPath: 'config.local.json',
    once: false
  };
  for (let index = 2; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === '--config') {
      args.configPath = argv[index + 1];
      index += 1;
    } else if (arg === '--once') {
      args.once = true;
    } else if (arg === '--port') {
      args.port = Number(argv[index + 1]);
      index += 1;
    } else if (arg === '--host') {
      args.host = argv[index + 1];
      index += 1;
    }
  }
  return args;
}

async function readJson(filePath) {
  const raw = await fs.readFile(filePath, 'utf8');
  return JSON.parse(raw);
}

async function loadEnvFile(cwd, fileName = '.env.local') {
  const envPath = path.resolve(cwd, fileName);
  let raw = '';
  try {
    raw = await fs.readFile(envPath, 'utf8');
  } catch (error) {
    if (error.code === 'ENOENT') return;
    throw error;
  }

  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const equals = trimmed.indexOf('=');
    if (equals <= 0) continue;
    const key = trimmed.slice(0, equals).trim();
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) continue;
    if (process.env[key] !== undefined) continue;
    process.env[key] = unquoteEnvValue(trimmed.slice(equals + 1).trim());
  }
}

function unquoteEnvValue(value) {
  if (
    (value.startsWith('"') && value.endsWith('"')) ||
    (value.startsWith("'") && value.endsWith("'"))
  ) {
    return value.slice(1, -1);
  }
  return value;
}

function deepMerge(base, override) {
  if (!override || typeof override !== 'object' || Array.isArray(override)) return override ?? base;
  const result = { ...(base || {}) };
  for (const [key, value] of Object.entries(override)) {
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      result[key] = deepMerge(result[key], value);
    } else {
      result[key] = value;
    }
  }
  return result;
}

function defaults() {
  return {
    runtime: {
      pollIntervalSeconds: 1,
      streamingTransport: 'sse',
      autoStart: true,
      stateDir: '.state',
      logLevel: 'info'
    },
    web: {
      host: '127.0.0.1',
      port: 4173,
      authTokenEnv: '',
      auth: {
        enabled: false,
        cookieName: 'mt5_risk_session',
        secureCookie: 'auto',
        sessionTtlHours: 12,
        users: []
      },
      systemUpdate: {
        enabled: true,
        allowApply: true,
        maxUploadMb: 200,
        updateDir: 'updates'
      }
    },
    provider: {
      type: 'mock',
      mockSnapshotPath: 'examples/mock-snapshot.json',
      managerApi: {
        command: 'adapters/MT5ManagerSnapshot/bin/Release64/MT5ManagerSnapshot.exe',
        args: [],
        cwd: '',
        timeoutMs: 30000
      },
      mt5WebApi: {
        crypt: 'aes',
        agent: 'MT5-RISK-MONITOR',
        timeoutMs: 30000,
        maxPositionsPerAccount: 5000,
        keepAlive: true
      }
    },
    mt5: {
      servers: [
        {
          name: 'primary',
          host: '',
          port: 443,
          login: 0,
          passwordEnv: 'MT5_MANAGER_PASSWORD',
          timeoutMs: 15000
        }
      ],
      groupMasks: [],
      accountLogins: [],
      symbolMasks: ['*'],
      baseCurrency: 'USD',
      serverTimeZone: DEFAULT_SERVER_TIME_ZONE,
      serverTimeOffsetMinutes: 180,
      disconnectAfterPollMultiples: 5,
      symbolSpecs: []
    },
    risk: {
      stopOutLevel: 0.5,
      accountStopOutLevels: {},
      accountOverrides: {},
      alertConditions: null,
      alertDistancePointsDefault: 0,
      warningDistancePointsDefault: 0,
      dangerDistancePointsDefault: 0,
      symbolDistancePoints: {},
      warningSymbolDistancePoints: {},
      dangerSymbolDistancePoints: {},
      symbolMappings: defaultSymbolMappings(),
      maxSearchDistancePoints: 200000,
      treatReportedMarginAsFixed: false,
      includeCreditInEquity: true,
      minimumMargin: 0.01
    },
    notifications: {
      cooldown: {
        seconds: 0,
        priceMovementPoints: 30,
        mode: 'priceOnly'
      }
    },
    lpAccount: {
      enabled: false,
      name: 'LP-USD',
      balance: 0,
      equityAdjustment: 0,
      credit: 0,
      leverage: 100,
      currency: 'USD',
      mode: 'aggregateClientExposure',
      hedgeDirection: 'same',
      aggregation: 'net',
      explicitPositions: []
    },
    email: {
      enabled: false,
      transport: 'console',
      cooldownSeconds: 0,
      templatePath: 'templates/liquidation-alert.html',
      templateHtml: '',
      subjectTemplate: '[Liquidation Risk] {{account.login}} {{risk.symbol}}',
      alertConditions: {
        accountScope: 'all',
        triggerMode: 'any',
        distanceToLiquidation: true,
        marginLevel: {
          enabled: false,
          threshold: 0.8
        },
        stopOut: {
          enabled: true
        }
      },
      smtp: {
        host: '',
        port: 587,
        secure: false,
        username: '',
        password: '',
        usernameEnv: 'SMTP_USER',
        passwordEnv: 'SMTP_PASSWORD',
        from: '',
        to: [],
        timeoutMs: 10000
      }
    },
    telegram: {
      enabled: false,
      botTokenEnv: 'TELEGRAM_BOT_TOKEN',
      botToken: '',
      chatIds: [],
      proxyUrl: '',
      parseMode: 'HTML',
      disableWebPagePreview: true,
      timeoutMs: 10000,
      messageTemplate:
        '<b>爆仓风险预警</b>\n账号: {{account.login}}\n组: {{account.group}}\n产品: {{risk.symbol}}\n方向: {{risk.direction}}\n当前价: {{risk.currentPrice}}\n爆仓价: {{risk.liquidationPrice}}\n距离: {{risk.distancePoints}} 点\n条件: {{alert.conditions}}'
    }
  };
}

async function loadConfig(argv, cwd = process.cwd()) {
  await loadEnvFile(cwd);
  const args = parseArgs(argv);
  const configPath = path.resolve(cwd, args.configPath);
  const loaded = await readJson(configPath);
  const config = deepMerge(defaults(), loaded);
  normalizeNotificationCooldown(config, loaded);
  config.mt5.serverTimeZone = normalizeServerTimeZone(
    config.mt5.serverTimeZone,
    config.mt5.serverTimeOffsetMinutes
  );
  config.mt5.serverTimeOffsetMinutes = offsetMinutesFromServerTimeZone(config.mt5.serverTimeZone);
  if (args.port) config.web.port = args.port;
  if (args.host) config.web.host = args.host;
  config.__configPath = configPath;
  config.__cwd = cwd;
  config.__runOnce = args.once;
  return config;
}

function normalizeNotificationCooldown(config, loaded = {}) {
  const loadedCooldown = loaded.notifications && loaded.notifications.cooldown;
  const cooldown = config.notifications.cooldown || {};
  const isLegacyDefault =
    loadedCooldown &&
    Number(loadedCooldown.priceMovementPoints || 0) === 0 &&
    String(loadedCooldown.mode || 'timeOnly') === 'timeOnly' &&
    [30, 1800].includes(Number(loadedCooldown.seconds || 0));

  if (!loadedCooldown || isLegacyDefault) {
    config.notifications.cooldown = {
      seconds: 0,
      priceMovementPoints: 30,
      mode: 'priceOnly'
    };
    config.email.cooldownSeconds = 0;
    return;
  }

  config.notifications.cooldown = {
    seconds: Number(cooldown.seconds) || 0,
    priceMovementPoints: Number(cooldown.priceMovementPoints) || 30,
    mode: cooldown.mode || 'priceOnly'
  };
  config.email.cooldownSeconds = config.notifications.cooldown.seconds;
}

function resolveFromCwd(config, filePath) {
  if (!filePath) return filePath;
  return path.isAbsolute(filePath) ? filePath : path.resolve(config.__cwd || process.cwd(), filePath);
}

module.exports = {
  parseArgs,
  loadConfig,
  resolveFromCwd,
  deepMerge,
  loadEnvFile
};
