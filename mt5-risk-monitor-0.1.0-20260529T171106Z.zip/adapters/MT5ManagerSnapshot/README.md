# MT5 Manager API Snapshot Adapter

Windows-only helper that calls the official MetaQuotes MT5 Manager API SDK and prints one JSON snapshot to stdout.

The main Node.js monitor starts this executable when `provider.type` is `managerApi`. The executable reads a JSON request from stdin and returns:

- `serverTime`
- `accounts`
- `positions`
- `symbols`
- `quotes`

## Build On Windows

Use Visual Studio Build Tools or Visual Studio Developer Command Prompt:

```bat
cd adapters\MT5ManagerSnapshot
msbuild MT5ManagerSnapshot.csproj /p:Configuration=Release /p:Platform=x64
```

The project references SDK assemblies from:

```text
MetaTrader5SDK\Libs
```

The build output is:

```text
adapters\MT5ManagerSnapshot\bin\Release64\MT5ManagerSnapshot.exe
```

`MT5APIManager64.dll`, `MetaQuotes.MT5CommonAPI64.dll`, and `MetaQuotes.MT5ManagerAPI64.dll` must be next to the executable. The project copies them from the SDK folder during build.

## Use

Set the password in the environment, not in JSON:

```bat
set MT5_MANAGER_PASSWORD=your-password
npm run web -- --config examples/config.manager-api.example.json
```

The adapter uses:

- `UserRequest` / `UserRequestArray`
- `UserAccountRequest`
- `PositionRequest`
- `SymbolRequest`
- `TickLast`
- `TimeServerRequest`

It is a client process only and does not need to be installed on the MT5 server.
