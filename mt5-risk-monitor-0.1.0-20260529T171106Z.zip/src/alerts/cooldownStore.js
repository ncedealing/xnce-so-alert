'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');

class CooldownStore {
  constructor(filePath) {
    this.filePath = filePath;
    this.state = {};
    this.loaded = false;
  }

  async load() {
    if (this.loaded) return;
    try {
      const raw = await fs.readFile(this.filePath, 'utf8');
      this.state = JSON.parse(raw);
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      this.state = {};
    }
    this.loaded = true;
  }

  async save() {
    await fs.mkdir(path.dirname(this.filePath), { recursive: true });
    await fs.writeFile(this.filePath, JSON.stringify(this.state, null, 2));
  }

  normalizeCooldown(cooldown) {
    if (typeof cooldown === 'number') {
      return { seconds: cooldown, priceMovementPoints: 0, mode: 'timeOnly' };
    }
    return {
      seconds: Number(cooldown && cooldown.seconds) || 0,
      priceMovementPoints: Number(cooldown && cooldown.priceMovementPoints) || 30,
      mode: (cooldown && cooldown.mode) || 'priceOnly'
    };
  }

  normalizeRecord(record) {
    if (!record) return null;
    if (typeof record === 'string') return { nextAllowedAt: record };
    return record;
  }

  priceMoveReady(record, priceState, points) {
    if (points <= 0) return true;
    if (!record || !Number.isFinite(Number(record.lastPrice))) return true;
    const price = Number(priceState && priceState.price);
    const point = Number((priceState && priceState.point) || record.point);
    const direction = String((priceState && priceState.direction) || record.direction || '').toLowerCase();
    if (!Number.isFinite(price) || !Number.isFinite(point) || point <= 0) return false;
    const diff = price - Number(record.lastPrice);
    if (direction === 'down') return -diff / point >= points;
    if (direction === 'up') return diff / point >= points;
    return Math.abs(price - Number(record.lastPrice)) / point >= points;
  }

  async canSend(key, cooldown, priceState = {}, now = new Date()) {
    if (priceState instanceof Date) {
      now = priceState;
      priceState = {};
    }
    await this.load();
    const settings = this.normalizeCooldown(cooldown);
    const record = this.normalizeRecord(this.state[key]);
    if (!record) return true;
    if (settings.seconds <= 0 && settings.priceMovementPoints <= 0) return true;

    const nextAllowed = record.nextAllowedAt ? new Date(record.nextAllowedAt) : null;
    const timeReady = settings.seconds <= 0 || !nextAllowed || nextAllowed <= now;
    const priceReady = this.priceMoveReady(record, priceState, settings.priceMovementPoints);

    if (settings.mode === 'priceOnly') return priceReady;
    if (settings.mode === 'timeOrPrice') return timeReady || priceReady;
    if (settings.mode === 'timeAndPrice') return timeReady && priceReady;
    return timeReady;
  }

  async markSent(key, cooldown, priceState = {}, now = new Date()) {
    if (priceState instanceof Date) {
      now = priceState;
      priceState = {};
    }
    await this.load();
    const settings = this.normalizeCooldown(cooldown);
    const nextAllowed = new Date(now.getTime() + settings.seconds * 1000);
    this.state[key] = {
      lastSentAt: now.toISOString(),
      nextAllowedAt: nextAllowed.toISOString(),
      lastPrice: Number.isFinite(Number(priceState && priceState.price)) ? Number(priceState.price) : undefined,
      point: Number.isFinite(Number(priceState && priceState.point)) ? Number(priceState.point) : undefined,
      direction: priceState && priceState.direction ? String(priceState.direction) : undefined
    };
    await this.save();
  }
}

module.exports = {
  CooldownStore
};
