'use strict';

const { renderTemplate, escapeHtml } = require('./templateRenderer');

function number(value, digits = 2) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return '';
  return parsed.toFixed(digits);
}

function positionsTable(positions) {
  if (!positions || positions.length === 0) return '<p>无持仓</p>';
  const rows = positions
    .map(
      (position) =>
        `<tr><td>${escapeHtml(position.ticket)}</td><td>${escapeHtml(position.symbol)}</td><td>${escapeHtml(position.action)}</td><td>${escapeHtml(position.volumeLots)}</td><td>${escapeHtml(position.openPrice)}</td></tr>`
    )
    .join('');
  return `<table cellpadding="6" cellspacing="0" style="border-collapse:collapse;border:1px solid #d1d5db"><thead><tr><th>Ticket</th><th>Symbol</th><th>方向</th><th>手数</th><th>开仓价</th></tr></thead><tbody>${rows}</tbody></table>`;
}

function buildAlertContext(report, symbolRisk, now = new Date()) {
  const account = report.account;
  const sourcePositions = report.positionDetails || report.positions || [];
  const relatedPositions = sourcePositions.filter(
    (position) => position.symbol === symbolRisk.symbol || position.canonicalSymbol === symbolRisk.symbol
  );
  const convertedPrices = (symbolRisk.convertedPrices || [])
    .map(
      (price) =>
        `${price.symbol}: ${number(price.currentPrice, 5)} -> ${number(price.liquidationPrice, 5)} (${number(price.distancePoints, 0)} pt)`
    )
    .join('\n');
  return {
    generatedAt: now.toISOString(),
    account: {
      login: account.login,
      group: account.group || '',
      currency: account.currency || 'USD',
      balance: number(account.balance),
      equity: number(report.equity),
      margin: number(report.margin),
      marginLevelPercent: Number.isFinite(report.marginLevel) ? number(report.marginLevel * 100) : 'INF',
      leverage: account.leverage
    },
    risk: {
      symbol: symbolRisk.symbol,
      direction: symbolRisk.direction === 'down' ? '下跌' : '上涨',
      currentPrice: number(symbolRisk.currentPrice, 5),
      liquidationPrice: number(symbolRisk.liquidationPrice, 5),
      distancePoints: number(symbolRisk.distancePoints, 0),
      alertDistancePoints: number(symbolRisk.alertDistancePoints, 0),
      stopOutLevelPercent: number(symbolRisk.stopOutLevel * 100),
      quoteBid: number(symbolRisk.quote.bid, 5),
      quoteAsk: number(symbolRisk.quote.ask, 5),
      grossLots: number(symbolRisk.grossLots, 2),
      netLots: number(symbolRisk.netLots, 2),
      convertedPrices
    },
    alert: {
      reason: symbolRisk.alertReason || '',
      conditions: (symbolRisk.alertReasons || []).join(', ')
    },
    positionsHtml: positionsTable(relatedPositions)
  };
}

function alertKey(report, symbolRisk) {
  const account = report.account.login;
  return [account, symbolRisk.symbol, symbolRisk.direction, symbolRisk.stopOutLevel].join(':');
}

function normalizeRatio(value, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return number > 1 ? number / 100 : number;
}

function isLpReport(report) {
  return String(report.account.group || '').toUpperCase() === 'LP' || String(report.account.login || '').toUpperCase().startsWith('LP');
}

function accountScopeMatches(report, scope = 'all') {
  if (scope === 'clientsOnly') return !isLpReport(report);
  if (scope === 'lpOnly') return isLpReport(report);
  return true;
}

function compareValue(actual, operator, expected) {
  if (!Number.isFinite(actual)) return false;
  const value = Number(expected);
  if (!Number.isFinite(value)) return false;
  if (operator === 'lt') return actual < value;
  if (operator === 'lte') return actual <= value;
  if (operator === 'gt') return actual > value;
  if (operator === 'gte') return actual >= value;
  if (operator === 'eq') return actual === value;
  if (operator === 'neq') return actual !== value;
  return actual <= value;
}

function metricValue(report, symbolRisk, metric) {
  if (metric === 'distancePoints' || metric === 'distance' || metric === 'pips') return Number(symbolRisk.distancePoints);
  if (metric === 'marginLevel') return Number(report.marginLevel);
  if (metric === 'marginLevelPercent') return Number(report.marginLevel) * 100;
  if (metric === 'grossLots' || metric === 'lots') return Number(symbolRisk.grossLots);
  if (metric === 'netLots') return Math.abs(Number(symbolRisk.netLots));
  if (metric === 'absNetLots') return Number(symbolRisk.absNetLots);
  if (metric === 'stopOut') return Number(report.marginLevel);
  return Number(symbolRisk[metric]);
}

function ruleLabel(rule, actual) {
  const metricNames = {
    distancePoints: '距离爆仓点数',
    pips: '距离爆仓点数',
    marginLevel: '预付款比例',
    marginLevelPercent: '预付款比例%',
    grossLots: '总手数',
    lots: '总手数',
    netLots: '净手数',
    absNetLots: '净手数'
  };
  return `${metricNames[rule.metric] || rule.metric} ${number(actual, 2)} ${rule.operator || 'lte'} ${rule.value}`;
}

function ruleMatchKey(rule = {}) {
  return [
    rule.metric || rule.type || 'condition',
    rule.operator || rule.op || 'lte',
    rule.value ?? rule.threshold ?? ''
  ].join(':');
}

function evaluateRuleExpression(report, symbolRisk, expression) {
  if (!expression) return { passed: false, reasons: [], matches: [] };
  if (expression.enabled === false) return { passed: true, reasons: [], matches: [] };

  if (expression.metric || expression.type) {
    const metric = expression.metric || expression.type;
    const operator = expression.operator || expression.op || 'lte';
    const actual = metricValue(report, symbolRisk, metric);
    const passed = compareValue(actual, operator, expression.value ?? expression.threshold);
    const reason = ruleLabel({ ...expression, metric, operator }, actual);
    return {
      passed,
      reasons: passed ? [reason] : [],
      matches: passed
        ? [{
            key: ruleMatchKey({ ...expression, metric, operator }),
            reason
          }]
        : []
    };
  }

  const op = String(expression.op || expression.logic || 'and').toLowerCase();
  const rules = expression.rules || expression.children || [];
  if (op === 'not') {
    const result = evaluateRuleExpression(report, symbolRisk, rules[0]);
    return {
      passed: !result.passed,
      reasons: !result.passed ? [`NOT(${result.reasons.join(', ') || 'condition'})`] : [],
      matches: []
    };
  }

  const results = rules.map((rule) => evaluateRuleExpression(report, symbolRisk, rule));
  const passed = op === 'or' ? results.some((result) => result.passed) : results.every((result) => result.passed);
  return {
    passed,
    reasons: results.filter((result) => result.passed).flatMap((result) => result.reasons),
    matches: results.filter((result) => result.passed).flatMap((result) => result.matches || [])
  };
}

function resolveAlertConditions(report, fallbackConditions = {}, riskConfig = {}) {
  const login = String(report.account.login ?? '');
  const override =
    riskConfig.accountOverrides && login && riskConfig.accountOverrides[login]
      ? riskConfig.accountOverrides[login].alertConditions
      : undefined;
  return override || riskConfig.alertConditions || fallbackConditions;
}

function evaluateAlertConditions(report, symbolRisk, alertConditions = {}) {
  if (!accountScopeMatches(report, alertConditions.accountScope || 'all')) {
    return { shouldSend: false, reasons: [] };
  }

  if (alertConditions.rules || alertConditions.op || alertConditions.logic) {
    const result = evaluateRuleExpression(report, symbolRisk, alertConditions);
    return {
      shouldSend: result.passed,
      reasons: result.reasons,
      matches: result.matches || []
    };
  }

  const checks = [];
  if (alertConditions.distanceToLiquidation !== false) {
    checks.push({
      enabled: true,
      passed: symbolRisk.distancePoints <= symbolRisk.alertDistancePoints,
      reason: `距离爆仓价 ${number(symbolRisk.distancePoints, 0)} 点 <= 阈值 ${number(symbolRisk.alertDistancePoints, 0)} 点`
    });
  }

  if (alertConditions.marginLevel && alertConditions.marginLevel.enabled) {
    const threshold = normalizeRatio(alertConditions.marginLevel.threshold, 0.8);
    checks.push({
      enabled: true,
      passed: Number.isFinite(report.marginLevel) && report.marginLevel <= threshold,
      reason: `预付款比例 ${number(report.marginLevel * 100, 2)}% <= ${number(threshold * 100, 2)}%`
    });
  }

  if (!alertConditions.stopOut || alertConditions.stopOut.enabled !== false) {
    checks.push({
      enabled: true,
      passed: Number.isFinite(report.marginLevel) && report.marginLevel <= report.stopOutLevel,
      reason: `预付款比例已低于爆仓线 ${number(report.stopOutLevel * 100, 2)}%`
    });
  }

  const enabledChecks = checks.filter((check) => check.enabled);
  if (enabledChecks.length === 0) return { shouldSend: false, reasons: [] };

  const triggerMode = alertConditions.triggerMode === 'all' ? 'all' : 'any';
  const shouldSend =
    triggerMode === 'all'
      ? enabledChecks.every((check) => check.passed)
      : enabledChecks.some((check) => check.passed);

  return {
    shouldSend,
    reasons: enabledChecks.filter((check) => check.passed).map((check) => check.reason),
    matches: enabledChecks
      .filter((check) => check.passed)
      .map((check, index) => ({
        key: `legacy:${index}`,
        reason: check.reason
      }))
  };
}

function normalizeCooldown(cooldown) {
  if (!cooldown || typeof cooldown !== 'object') return null;
  return {
    seconds: Number(cooldown.seconds) || 0,
    priceMovementPoints: Number(cooldown.priceMovementPoints) || 30,
    mode: cooldown.mode || 'priceOnly'
  };
}

function resolveAccountCooldown(report, riskConfig = {}) {
  const login = String(report.account.login ?? '');
  const override = login && riskConfig.accountOverrides ? riskConfig.accountOverrides[login] : null;
  return normalizeCooldown(override && override.cooldown);
}

function buildAlerts(reports, template, subjectTemplate, alertConditions = {}, riskConfig = {}) {
  const alerts = [];
  for (const report of reports) {
    const resolvedConditions = resolveAlertConditions(report, alertConditions, riskConfig);
    for (const symbolRisk of report.symbolRisks) {
      const evaluation = evaluateAlertConditions(report, symbolRisk, resolvedConditions);
      if (!evaluation.shouldSend) continue;
      const alertRisk = {
        ...symbolRisk,
        alertReason: evaluation.reasons[0] || '',
        alertReasons: evaluation.reasons
      };
      const context = buildAlertContext(report, alertRisk);
      context.alert.cooldownRules = '';
      alerts.push({
        key: alertKey(report, alertRisk),
        baseKey: alertKey(report, alertRisk),
        cooldown: resolveAccountCooldown(report, riskConfig),
        cooldownMatches: evaluation.matches || [],
        context,
        subject: renderTemplate(subjectTemplate, context),
        html: renderTemplate(template, context),
        report,
        symbolRisk: alertRisk
      });
    }
  }
  return alerts;
}

module.exports = {
  number,
  positionsTable,
  buildAlertContext,
  buildAlerts,
  alertKey,
  evaluateAlertConditions,
  evaluateRuleExpression,
  resolveAlertConditions
};
