'use strict';

const net = require('node:net');
const tls = require('node:tls');

function readEnvOrValue(config, valueKey, envKey) {
  if (config[valueKey]) return config[valueKey];
  if (config[envKey]) return process.env[config[envKey]];
  return undefined;
}

function encodeHeader(value) {
  return `=?UTF-8?B?${Buffer.from(String(value), 'utf8').toString('base64')}?=`;
}

function dotStuff(body) {
  return String(body).replace(/^\./gm, '..');
}

class SmtpSession {
  constructor(options) {
    this.options = options;
    this.socket = null;
    this.buffer = '';
  }

  connectSocket(secure) {
    const options = {
      host: this.options.host,
      port: this.options.port,
      servername: this.options.host,
      timeout: this.options.timeoutMs || 10000
    };
    return new Promise((resolve, reject) => {
      const socket = secure ? tls.connect(options, () => resolve(socket)) : net.connect(options, () => resolve(socket));
      socket.once('error', reject);
      socket.setTimeout(options.timeout, () => reject(new Error('SMTP timeout')));
    });
  }

  async connect() {
    this.socket = await this.connectSocket(this.options.secure);
    this.socket.setEncoding('utf8');
    this.socket.on('data', (chunk) => {
      this.buffer += chunk;
    });
    await this.readResponse();
    await this.command(`EHLO ${this.options.helloName || 'localhost'}`);
    if (!this.options.secure && this.options.startTls !== false) {
      await this.command('STARTTLS');
      this.socket = tls.connect({ socket: this.socket, servername: this.options.host });
      this.socket.setEncoding('utf8');
      this.socket.on('data', (chunk) => {
        this.buffer += chunk;
      });
      await this.command(`EHLO ${this.options.helloName || 'localhost'}`);
    }
  }

  async readResponse() {
    const deadline = Date.now() + (this.options.timeoutMs || 10000);
    while (Date.now() < deadline) {
      const lines = this.buffer.split(/\r?\n/);
      for (let index = 0; index < lines.length; index += 1) {
        const line = lines[index];
        if (/^\d{3} /.test(line)) {
          const response = lines.slice(0, index + 1).join('\n');
          this.buffer = lines.slice(index + 1).join('\n');
          const code = Number(line.slice(0, 3));
          if (code >= 400) throw new Error(`SMTP error ${response}`);
          return response;
        }
      }
      await new Promise((resolve) => setTimeout(resolve, 20));
    }
    throw new Error('SMTP response timeout');
  }

  async command(line) {
    this.socket.write(`${line}\r\n`);
    return this.readResponse();
  }

  async close() {
    if (!this.socket) return;
    try {
      await this.command('QUIT');
    } finally {
      this.socket.end();
    }
  }
}

class ConsoleMailer {
  async send({ to, subject }) {
    console.log(`[mail:console] to=${to.join(',')} subject=${subject}`);
  }
}

class SmtpMailer {
  constructor(smtpConfig) {
    this.smtpConfig = smtpConfig;
  }

  async send({ to, subject, html }) {
    const username = readEnvOrValue(this.smtpConfig, 'username', 'usernameEnv');
    const password = readEnvOrValue(this.smtpConfig, 'password', 'passwordEnv');
    const from = this.smtpConfig.from;
    const recipients = to && to.length > 0 ? to : this.smtpConfig.to || [];
    if (!from) throw new Error('email.smtp.from is required');
    if (recipients.length === 0) throw new Error('email.smtp.to is required');

    const session = new SmtpSession(this.smtpConfig);
    await session.connect();
    try {
      if (username && password) {
        await session.command('AUTH LOGIN');
        await session.command(Buffer.from(username, 'utf8').toString('base64'));
        await session.command(Buffer.from(password, 'utf8').toString('base64'));
      }

      await session.command(`MAIL FROM:<${from}>`);
      for (const recipient of recipients) await session.command(`RCPT TO:<${recipient}>`);
      await session.command('DATA');
      const message = [
        `From: ${from}`,
        `To: ${recipients.join(', ')}`,
        `Subject: ${encodeHeader(subject)}`,
        `Date: ${new Date().toUTCString()}`,
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8',
        'Content-Transfer-Encoding: 8bit',
        '',
        dotStuff(html),
        '.'
      ].join('\r\n');
      session.socket.write(`${message}\r\n`);
      await session.readResponse();
    } finally {
      await session.close();
    }
  }
}

function createMailer(config, options = {}) {
  if ((!options.force && !config.email.enabled) || config.email.transport === 'console') return new ConsoleMailer();
  if (config.email.transport === 'smtp') return new SmtpMailer(config.email.smtp || {});
  throw new Error(`Unsupported email.transport: ${config.email.transport}`);
}

module.exports = {
  ConsoleMailer,
  SmtpMailer,
  createMailer
};
