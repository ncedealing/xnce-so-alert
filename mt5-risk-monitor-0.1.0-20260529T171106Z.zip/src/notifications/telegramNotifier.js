'use strict';

const http = require('node:http');
const tls = require('node:tls');
const { renderTemplate } = require('../alerts/templateRenderer');

function readToken(config = {}) {
  if (config.botToken) return config.botToken;
  if (config.botTokenEnv) return process.env[config.botTokenEnv];
  return undefined;
}

function normalizeChatIds(chatIds) {
  if (Array.isArray(chatIds)) return chatIds.map(String).filter(Boolean);
  if (typeof chatIds === 'string') {
    return chatIds
      .split(',')
      .map((item) => item.trim())
      .filter(Boolean);
  }
  return [];
}

function looksLikeBotUsername(chatId) {
  return /^@[A-Za-z0-9_]*bot$/i.test(String(chatId || '').trim());
}

function validateChatIds(chatIds) {
  const invalid = chatIds.filter(looksLikeBotUsername);
  if (invalid.length > 0) {
    throw new Error(`Telegram Chat ID 配置错误：${invalid.join(', ')} 看起来是机器人用户名，不是接收方 Chat ID。请先给机器人发送 /start，再点击“读取最近聊天”获取数字 Chat ID；群组一般是负数，超级群常以 -100 开头。`);
  }
}

function defaultMessageTemplate() {
  return [
    '<b>爆仓风险预警</b>',
    '账号: {{account.login}}',
    '组: {{account.group}}',
    '产品: {{risk.symbol}}',
    '方向: {{risk.direction}}',
    '当前价: {{risk.currentPrice}}',
    '爆仓价: {{risk.liquidationPrice}}',
    '距离: {{risk.distancePoints}} 点',
    '条件: {{alert.conditions}}'
  ].join('\n');
}

class ConsoleTelegramNotifier {
  async sendAlert(alert) {
    console.log(`[telegram:console] subject=${alert.subject}`);
  }
}

class TelegramNotifier {
  constructor(config = {}, fetchImpl = globalThis.fetch) {
    this.config = config;
    this.fetchImpl = fetchImpl;
  }

  async sendAlert(alert) {
    const token = readToken(this.config);
    const chatIds = normalizeChatIds(this.config.chatIds);
    if (!token) throw new Error('Telegram Bot Token 未配置：请填写 Bot Token 或设置 TELEGRAM_BOT_TOKEN 环境变量。');
    if (chatIds.length === 0) throw new Error('Telegram Chat ID 未配置：请先给机器人发送 /start，再填写个人、群组或频道 Chat ID。');
    if (typeof this.fetchImpl !== 'function') throw new Error('当前 Node 版本没有 fetch，无法访问 Telegram API。');
    validateChatIds(chatIds);

    const text = renderTemplate(this.config.messageTemplate || defaultMessageTemplate(), alert.context);
    for (const chatId of chatIds) {
      await sendTelegramMessage(
        { ...this.config, botToken: token },
        chatId,
        text,
        this.fetchImpl
      );
    }
  }
}

async function telegramApiRequest(config = {}, method, payload = null, fetchImpl = globalThis.fetch) {
  const token = readToken(config);
  if (!token) throw new Error('Telegram Bot Token 未配置：请填写 Bot Token 或设置 TELEGRAM_BOT_TOKEN 环境变量。');
  if (typeof fetchImpl !== 'function') throw new Error('当前 Node 版本没有 fetch，无法访问 Telegram API。');

  const url = `https://api.telegram.org/bot${token}/${method}`;
  const timeoutMs = Number(config.timeoutMs) || 10000;
  const requestOptions = {
    method: payload ? 'POST' : 'GET',
    headers: payload ? { 'content-type': 'application/json' } : undefined,
    body: payload ? JSON.stringify(payload) : undefined,
    signal:
      typeof AbortSignal !== 'undefined' && AbortSignal.timeout
        ? AbortSignal.timeout(timeoutMs)
        : undefined
  };
  const proxyUrl = resolveTelegramProxyUrl(config);
  const response = await (
    proxyUrl && fetchImpl === globalThis.fetch
      ? fetchViaHttpProxy(url, requestOptions, proxyUrl, timeoutMs)
      : fetchImpl(url, requestOptions)
  ).catch((error) => {
    throw new Error(formatTelegramNetworkError(error, proxyUrl));
  });

  let text = '';
  if (typeof response.text === 'function') {
    text = await response.text().catch(() => '');
  } else if (typeof response.json === 'function') {
    const json = await response.json().catch(() => null);
    text = json ? JSON.stringify(json) : '';
  }
  let body = {};
  try {
    body = text ? JSON.parse(text) : {};
  } catch (error) {
    body = { description: text };
  }
  if (!response.ok || body.ok === false) {
    const detail = body.description || text || response.statusText || '';
    throw new Error(`Telegram API 返回错误：${response.status} ${detail}`);
  }
  return body;
}

function resolveTelegramProxyUrl(config = {}) {
  return String(
    config.proxyUrl ||
    process.env.HTTPS_PROXY ||
    process.env.https_proxy ||
    process.env.HTTP_PROXY ||
    process.env.http_proxy ||
    ''
  ).trim();
}

function formatTelegramNetworkError(error, proxyUrl = '') {
  const message = error && error.message ? error.message : String(error);
  if (proxyUrl) {
    return `Telegram API 请求失败：${message}。当前已尝试通过代理 ${proxyUrl} 访问，请确认 ClashX 的 HTTP/Mixed 端口正在监听，代理地址通常是 http://127.0.0.1:7890 或 http://127.0.0.1:7897。`;
  }
  return `Telegram API 请求失败：${message}。ClashX 全局模式通常不会自动代理 Node 后端进程，请在 Telegram 配置里填写代理地址，例如 http://127.0.0.1:7890。`;
}

function fetchViaHttpProxy(urlString, options = {}, proxyUrlString, timeoutMs = 10000) {
  const target = new URL(urlString);
  const proxy = new URL(proxyUrlString);
  if (target.protocol !== 'https:') throw new Error('Telegram API 只支持 HTTPS 请求');
  if (proxy.protocol !== 'http:') {
    throw new Error('当前 Telegram 代理只支持 http:// 代理地址；ClashX 请填写 HTTP/Mixed 端口，例如 http://127.0.0.1:7890');
  }

  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (error) reject(error);
      else resolve(value);
    };
    let connectReq;
    const timer = setTimeout(() => {
      if (connectReq) connectReq.destroy(new Error(`Telegram 代理连接超时 (${timeoutMs}ms)`));
      else finish(new Error(`Telegram 代理连接超时 (${timeoutMs}ms)`));
    }, timeoutMs);
    const proxyPort = Number(proxy.port || 80);
    const connectHeaders = {
      Host: `${target.hostname}:443`
    };
    if (proxy.username || proxy.password) {
      connectHeaders['Proxy-Authorization'] = `Basic ${Buffer.from(`${decodeURIComponent(proxy.username)}:${decodeURIComponent(proxy.password)}`).toString('base64')}`;
    }
    connectReq = http.request({
      host: proxy.hostname,
      port: proxyPort,
      method: 'CONNECT',
      path: `${target.hostname}:443`,
      headers: connectHeaders,
      timeout: timeoutMs
    });

    connectReq.on('timeout', () => {
      connectReq.destroy(new Error(`Telegram 代理连接超时 (${timeoutMs}ms)`));
    });
    connectReq.on('error', (error) => finish(error));
    connectReq.on('connect', (res, socket) => {
      if (res.statusCode !== 200) {
        socket.destroy();
        finish(new Error(`代理 CONNECT 失败：HTTP ${res.statusCode}`));
        return;
      }
      const tlsSocket = tls.connect({ socket, servername: target.hostname }, () => {
        const body = options.body ? String(options.body) : '';
        const headers = {
          Host: target.hostname,
          Connection: 'close',
          'Accept-Encoding': 'identity',
          ...(options.headers || {})
        };
        if (body && !headerExists(headers, 'content-length')) {
          headers['Content-Length'] = Buffer.byteLength(body);
        }
        const requestHead = [
          `${options.method || 'GET'} ${target.pathname}${target.search} HTTP/1.1`,
          ...Object.entries(headers).map(([key, value]) => `${key}: ${value}`),
          '',
          ''
        ].join('\r\n');
        tlsSocket.write(`${requestHead}${body}`);
      });
      const chunks = [];
      tlsSocket.setTimeout(timeoutMs, () => {
        tlsSocket.destroy(new Error(`Telegram 代理请求超时 (${timeoutMs}ms)`));
      });
      tlsSocket.on('data', (chunk) => chunks.push(chunk));
      tlsSocket.on('error', (error) => finish(error));
      tlsSocket.on('end', () => {
        try {
          finish(null, parseHttpResponse(Buffer.concat(chunks)));
        } catch (error) {
          finish(error);
        }
      });
    });
    connectReq.end();
  });
}

function headerExists(headers, name) {
  const normalized = name.toLowerCase();
  return Object.keys(headers).some((key) => key.toLowerCase() === normalized);
}

function parseHttpResponse(buffer) {
  const separator = Buffer.from('\r\n\r\n');
  const index = buffer.indexOf(separator);
  if (index < 0) throw new Error('Telegram API 返回了无效 HTTP 响应');
  const rawHeaders = buffer.slice(0, index).toString('latin1');
  const rawBody = buffer.slice(index + separator.length);
  const lines = rawHeaders.split('\r\n');
  const statusMatch = /^HTTP\/\d(?:\.\d)?\s+(\d{3})\s*(.*)$/i.exec(lines.shift() || '');
  if (!statusMatch) throw new Error('Telegram API 返回了无效状态行');
  const headers = {};
  for (const line of lines) {
    const split = line.indexOf(':');
    if (split < 0) continue;
    headers[line.slice(0, split).trim().toLowerCase()] = line.slice(split + 1).trim();
  }
  const bodyBuffer = /chunked/i.test(headers['transfer-encoding'] || '')
    ? decodeChunkedBody(rawBody)
    : rawBody;
  const status = Number(statusMatch[1]);
  return {
    ok: status >= 200 && status < 300,
    status,
    statusText: statusMatch[2] || '',
    text: async () => bodyBuffer.toString('utf8')
  };
}

function decodeChunkedBody(buffer) {
  const chunks = [];
  let offset = 0;
  while (offset < buffer.length) {
    const lineEnd = buffer.indexOf('\r\n', offset, 'latin1');
    if (lineEnd < 0) break;
    const sizeText = buffer.slice(offset, lineEnd).toString('latin1').split(';')[0].trim();
    const size = Number.parseInt(sizeText, 16);
    if (!Number.isFinite(size)) throw new Error('Telegram API 返回了无效 chunked 响应');
    offset = lineEnd + 2;
    if (size === 0) break;
    chunks.push(buffer.slice(offset, offset + size));
    offset += size + 2;
  }
  return Buffer.concat(chunks);
}

async function sendTelegramMessage(config = {}, chatId, text, fetchImpl = globalThis.fetch) {
  if (!chatId) throw new Error('Telegram Chat ID 未配置。');
  validateChatIds([chatId]);
  return telegramApiRequest(
    config,
    'sendMessage',
    {
      chat_id: String(chatId),
      text,
      parse_mode: config.parseMode || 'HTML',
      disable_web_page_preview: config.disableWebPagePreview !== false
    },
    fetchImpl
  );
}

async function getTelegramUpdates(config = {}, fetchImpl = globalThis.fetch) {
  const body = await telegramApiRequest(config, 'getUpdates', null, fetchImpl);
  return Array.isArray(body.result) ? body.result : [];
}

function extractChatsFromUpdates(updates = []) {
  const byId = new Map();
  for (const update of updates) {
    const message =
      update.message ||
      update.edited_message ||
      update.channel_post ||
      update.edited_channel_post ||
      update.my_chat_member ||
      update.chat_member;
    const chat = message && message.chat ? message.chat : null;
    if (!chat || chat.id === undefined || chat.id === null) continue;
    byId.set(String(chat.id), {
      id: String(chat.id),
      type: chat.type || '',
      title: chat.title || [chat.first_name, chat.last_name].filter(Boolean).join(' ') || '',
      username: chat.username ? `@${chat.username}` : '',
      lastText: message.text || message.caption || '',
      date: message.date ? new Date(Number(message.date) * 1000).toISOString() : null
    });
  }
  return [...byId.values()];
}

function createTelegramNotifier(config) {
  if (!config.telegram || !config.telegram.enabled) return new ConsoleTelegramNotifier();
  return new TelegramNotifier(config.telegram);
}

module.exports = {
  ConsoleTelegramNotifier,
  TelegramNotifier,
  createTelegramNotifier,
  defaultMessageTemplate,
  extractChatsFromUpdates,
  getTelegramUpdates,
  looksLikeBotUsername,
  normalizeChatIds,
  readToken,
  resolveTelegramProxyUrl,
  sendTelegramMessage,
  telegramApiRequest
};
