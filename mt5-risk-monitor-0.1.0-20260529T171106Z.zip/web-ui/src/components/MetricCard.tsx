import { Activity, ShieldAlert, Users } from 'lucide-react';
import type { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface MetricCardProps {
  label: string;
  value: string | number;
  icon?: ReactNode;
  variant?: 'default' | 'danger';
  hover?: 'default' | 'danger';
  className?: string;
  onClick?: () => void;
}

export function MetricCard({ label, value, icon, variant = 'default', hover = 'default', className, onClick }: MetricCardProps) {
  const Component = onClick ? 'button' : 'div';
  return (
    <Component
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      className={cn(
        'flex min-w-0 flex-1 flex-col justify-between rounded-md border border-zinc-800 bg-zinc-900 p-4 text-left shadow-sm',
        onClick &&
          (hover === 'danger'
            ? 'cursor-pointer transition-colors hover:border-red-900/70 hover:bg-red-950/10'
            : 'cursor-pointer transition-colors hover:border-emerald-900/70 hover:bg-emerald-950/10'),
        className,
      )}
    >
      <div className="mb-2 flex items-center justify-between text-zinc-400">
        <p className="truncate text-sm font-medium">{label}</p>
        {icon}
      </div>
      <p
        className={cn(
          'text-2xl font-bold tabular-nums leading-none tracking-tight',
          variant === 'danger' ? 'text-red-500' : 'text-zinc-100',
        )}
      >
        {value}
      </p>
    </Component>
  );
}

interface MetricRowProps {
  accounts: number;
  positions: number;
  alerts: number;
  onPositionsClick?: () => void;
  onAlertsClick?: () => void;
}

export function MetricRow({ accounts, positions, alerts, onPositionsClick, onAlertsClick }: MetricRowProps) {
  return (
    <div className="grid shrink-0 grid-cols-1 gap-4 sm:grid-cols-3">
      <MetricCard label="监测账号总数" value={accounts} icon={<Users className="h-4 w-4" />} />
      <MetricCard label="持仓订单总数" value={positions} icon={<Activity className="h-4 w-4" />} onClick={onPositionsClick} />
      <MetricCard
        label="高危告警数"
        value={alerts}
        icon={<ShieldAlert className="h-4 w-4 text-red-500" />}
        variant={alerts > 0 ? 'danger' : 'default'}
        hover="danger"
        onClick={onAlertsClick}
      />
    </div>
  );
}
