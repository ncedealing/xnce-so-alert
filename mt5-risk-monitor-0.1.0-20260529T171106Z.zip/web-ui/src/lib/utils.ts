import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function asNumber(value: unknown, fallback = 0): number {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

export function formatNumber(value: unknown, digits = 2): string {
  return asNumber(value).toLocaleString('en-US', {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

export function formatCompactNumber(value: unknown, digits = 4): string {
  const number = asNumber(value);
  return Number(number.toFixed(digits)).toString();
}

export function formatPrice(value: unknown, digits = 5): string {
  return asNumber(value).toFixed(digits);
}

export function formatDateTime(iso: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleString('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
}

export function directionLabel(direction: string): string {
  if (direction === 'up') return '↑ 上涨';
  if (direction === 'down') return '↓ 下跌';
  return direction;
}

export function marginLevelPercent(marginLevel: unknown): number {
  return asNumber(marginLevel) * 100;
}

export function parseCommaList(value: unknown): string[] {
  return String(value ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

export function joinCommaList(values: unknown): string {
  return Array.isArray(values) ? values.join(', ') : '';
}

export function parseSymbolDistanceMap(value: string): Record<string, number> {
  return parseNumberMap(value);
}

export function parseNumberMap(value: string): Record<string, number> {
  const result: Record<string, number> = {};
  for (const part of parseCommaList(value)) {
    const [key, raw] = part.split(':').map((s) => s.trim());
    if (key && raw) {
      const num = Number(raw);
      if (!Number.isNaN(num)) result[key] = num;
    }
  }
  return result;
}

export function ratioToPercent(value: unknown, fallback = 0): number {
  return asNumber(value, fallback) * 100;
}

export function percentToRatio(value: unknown, fallback = 0): number {
  return asNumber(value, fallback) / 100;
}

export function parsePercentMap(value: string): Record<string, number> {
  const result: Record<string, number> = {};
  for (const part of parseCommaList(value)) {
    const [key, raw] = part.split(':').map((s) => s.trim());
    if (key && raw) {
      const num = Number(raw.replace(/%$/, ''));
      if (!Number.isNaN(num)) result[key] = percentToRatio(num);
    }
  }
  return result;
}

export function formatPercentMap(map: Record<string, number> = {}): string {
  return Object.entries(map)
    .map(([key, value]) => `${key}:${formatCompactNumber(ratioToPercent(value), 2)}%`)
    .join(', ');
}

export function formatSymbolDistanceMap(map: Record<string, number>): string {
  return formatNumberMap(map);
}

export function formatNumberMap(map: Record<string, number> = {}): string {
  return Object.entries(map)
    .map(([key, value]) => `${key}:${value}`)
    .join(', ');
}
