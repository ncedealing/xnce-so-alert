'use strict';

const {
  toNumber,
  normalizeAction,
  pointFromSymbol,
  estimatePositionMargin,
  estimatePositionProfit,
  positionProfitMetrics
} = require('./margin');
const {
  canonicalSymbol,
  convertedPricesForBase,
  lotsToBaseMultiplier,
  mappedToBasePrice,
  mappingForSymbol,
  normalizeSymbolName,
  quoteFromBaseQuote
} = require('./symbolMapping');

function arrayToMap(items, key) {
  const map = new Map();
  for (const item of items || []) map.set(item[key], item);
  return map;
}

function defaultSymbolSpec(symbol) {
  const normalized = normalizeSymbolName(symbol);
  if (normalized === 'XAUUSD') {
    return { symbol: 'XAUUSD', digits: 2, point: 0.01, contractSize: 100, currencyProfit: 'USD' };
  }
  return {};
}

function symbolSpecForName(symbolsByName, symbol) {
  if (!symbol) return {};
  const direct = symbolsByName.get(symbol);
  if (direct) return direct;
  const normalized = normalizeSymbolName(symbol);
  for (const [name, spec] of symbolsByName.entries()) {
    if (normalizeSymbolName(name) === normalized) return spec;
  }
  return defaultSymbolSpec(symbol);
}

function normalizeStopOutLevel(value) {
  const number = toNumber(value, 0.5);
  return number > 1 ? number / 100 : number;
}

function getAccountStopOutLevel(account = {}, riskConfig = {}) {
  const byAccount = riskConfig.accountStopOutLevels || {};
  const login = String(account.login ?? '');
  const configured =
    (login && riskConfig.accountOverrides && riskConfig.accountOverrides[login]
      ? riskConfig.accountOverrides[login].stopOutLevel
      : undefined) ??
    account.stopOutLevel ??
    account.stopoutLevel ??
    account.stopOut ??
    (login ? byAccount[login] : undefined);
  return normalizeStopOutLevel(configured ?? riskConfig.stopOutLevel);
}

function getAlertDistancePoints(symbol, riskConfig = {}) {
  const bySymbol = riskConfig.symbolDistancePoints || {};
  if (bySymbol[symbol] !== undefined) return toNumber(bySymbol[symbol]);
  return toNumber(riskConfig.alertDistancePointsDefault, 0);
}

function distanceThresholdFromExpression(expression) {
  if (!expression || typeof expression !== 'object') return NaN;
  const metric = expression.metric || expression.type;
  const operator = expression.operator || expression.op || 'lte';
  if (metric === 'distancePoints' && ['lt', 'lte', 'eq'].includes(String(operator).toLowerCase())) {
    const value = toNumber(expression.value ?? expression.threshold, NaN);
    return Number.isFinite(value) && value > 0 ? value : NaN;
  }
  const rules = expression.rules || expression.children || [];
  const values = rules
    .map((rule) => distanceThresholdFromExpression(rule))
    .filter((value) => Number.isFinite(value) && value > 0);
  return values.length ? Math.max(...values) : NaN;
}

function configuredDistance(value) {
  const number = toNumber(value, NaN);
  return Number.isFinite(number) && number > 0 ? number : NaN;
}

function accountRiskOverride(account = {}, riskConfig = {}) {
  const login = String(account.login ?? '');
  return login && riskConfig.accountOverrides ? riskConfig.accountOverrides[login] || {} : {};
}

function getDangerDistancePoints(symbol, account = {}, riskConfig = {}) {
  const override = accountRiskOverride(account, riskConfig);
  const dangerBySymbol = riskConfig.dangerSymbolDistancePoints || {};
  const legacyBySymbol = riskConfig.symbolDistancePoints || {};
  const values = [
    override.dangerDistancePoints,
    dangerBySymbol[symbol],
    riskConfig.dangerDistancePointsDefault,
    legacyBySymbol[symbol],
    riskConfig.alertDistancePointsDefault,
    distanceThresholdFromExpression(override.alertConditions),
    distanceThresholdFromExpression(riskConfig.alertConditions)
  ].map(configuredDistance);
  const found = values.find((value) => Number.isFinite(value));
  return Number.isFinite(found) ? found : 0;
}

function getWarningDistancePoints(symbol, account = {}, riskConfig = {}, dangerDistancePoints = 0) {
  const override = accountRiskOverride(account, riskConfig);
  const bySymbol = riskConfig.warningSymbolDistancePoints || {};
  const values = [
    override.warningDistancePoints,
    bySymbol[symbol],
    riskConfig.warningDistancePointsDefault
  ].map(configuredDistance);
  const found = values.find((value) => Number.isFinite(value));
  if (Number.isFinite(found)) return Math.max(found, dangerDistancePoints);
  return dangerDistancePoints > 0 ? dangerDistancePoints * 2 : 0;
}

function riskSeverity({ distancePoints, marginLevel, stopOutLevel, warningDistancePoints, dangerDistancePoints }) {
  const distance = toNumber(distancePoints, Number.POSITIVE_INFINITY);
  const margin = toNumber(marginLevel, Number.POSITIVE_INFINITY);
  const stopOut = toNumber(stopOutLevel, 0.5);
  const danger = configuredDistance(dangerDistancePoints);
  const warning = configuredDistance(warningDistancePoints);
  if (margin <= stopOut || (Number.isFinite(danger) && distance <= danger)) return 'danger';
  if (margin <= stopOut * 1.5 || (Number.isFinite(warning) && distance <= warning)) return 'warning';
  return 'normal';
}

function quoteForSymbol(quotesBySymbol, symbol) {
  return quotesBySymbol.get(symbol);
}

function quoteForNormalizedSymbol(quotesBySymbol, symbol) {
  const normalized = normalizeSymbolName(symbol);
  if (quotesBySymbol.has(symbol)) return quotesBySymbol.get(symbol);
  for (const [key, quote] of quotesBySymbol.entries()) {
    if (normalizeSymbolName(key) === normalized) return quote;
  }
  return null;
}

function quoteMid(quote) {
  if (!quote) return NaN;
  const bid = toNumber(quote.bid, NaN);
  const ask = toNumber(quote.ask, NaN);
  if (Number.isFinite(bid) && Number.isFinite(ask) && bid > 0 && ask > 0) return (bid + ask) / 2;
  if (Number.isFinite(bid) && bid > 0) return bid;
  if (Number.isFinite(ask) && ask > 0) return ask;
  return NaN;
}

function inferProfitCurrency(symbolSpec = {}, symbol = '', fallback = 'USD') {
  const configured =
    symbolSpec.currencyProfit ||
    symbolSpec.profitCurrency ||
    symbolSpec.currency_profit ||
    symbolSpec.currencyQuote ||
    symbolSpec.currency_quote;
  if (configured) return normalizeSymbolName(configured);
  const normalized = normalizeSymbolName(symbol).replace(/[^A-Z]/g, '');
  if (normalized.length >= 6) return normalized.slice(-3);
  return normalizeSymbolName(fallback || 'USD');
}

function currencyToUsdRate(currency, quotesBySymbol) {
  const normalized = normalizeSymbolName(currency || 'USD');
  if (!normalized || normalized === 'USD') return 1;

  const direct = quoteMid(quoteForNormalizedSymbol(quotesBySymbol, `${normalized}USD`));
  if (Number.isFinite(direct) && direct > 0) return direct;

  const inverse = quoteMid(quoteForNormalizedSymbol(quotesBySymbol, `USD${normalized}`));
  if (Number.isFinite(inverse) && inverse > 0) return 1 / inverse;

  return 1;
}

function calculatePositionTotals(account, positions, symbolsByName, quotesBySymbol, riskConfig = {}, shiftedQuotes = new Map()) {
  let floating = 0;
  let margin = 0;

  for (const position of positions) {
    const symbol = symbolSpecForName(symbolsByName, position.symbol);
    const quote = shiftedQuotes.get(position.symbol) || quoteForSymbol(quotesBySymbol, position.symbol);
    const metrics = positionProfitMetrics(position, symbol, quote);
    if (shiftedQuotes.size === 0 && metrics.profitSource === 'MT5_POSITION_PROFIT') {
      floating += metrics.netProfit;
    } else {
      floating += estimatePositionProfit(position, symbol, quote) + toNumber(position.swap) + toNumber(position.commission);
    }
    margin += estimatePositionMargin(position, symbol, quote, account, riskConfig);
  }

  return { floating, margin };
}

function hasReportedMargin(account) {
  const margin = toNumber(account && account.margin, NaN);
  return Number.isFinite(margin) && margin >= 0;
}

function reportedMarginLevel(account) {
  const ratio = toNumber(account && account.marginLevel, NaN);
  if (Number.isFinite(ratio) && ratio > 0) return ratio;

  const percent = toNumber(
    (account && account.marginLevelPercent) ?? (account && account.margin_level),
    NaN
  );
  if (Number.isFinite(percent) && percent > 0) return percent / 100;

  return NaN;
}

function calculatePortfolioState(account, positions, symbolsByName, quotesBySymbol, riskConfig = {}, options = {}) {
  const shiftedQuotes = options.shiftedQuotes || new Map();
  const calculated = calculatePositionTotals(account, positions, symbolsByName, quotesBySymbol, riskConfig, shiftedQuotes);

  const credit = riskConfig.includeCreditInEquity === false ? 0 : toNumber(account.credit);
  const balance = toNumber(account.balance);
  const equityAdjustment = toNumber(account.equityAdjustment);
  const currentEquity = toNumber(account.equity, NaN);
  const currentMargin = toNumber(account.margin, NaN);
  const hasProvidedFloatingOffset = Object.prototype.hasOwnProperty.call(options, 'floatingOffset');
  const floatingOffset = hasProvidedFloatingOffset
    ? options.floatingOffset
    : Number.isFinite(currentEquity) && !options.disableReportedEquityOffset
      ? currentEquity - balance - credit - equityAdjustment - calculated.floating
      : 0;
  const equity = balance + credit + calculated.floating + floatingOffset + equityAdjustment;

  let margin = calculated.margin;
  if (hasReportedMargin(account)) {
    if (riskConfig.treatReportedMarginAsFixed) {
      margin = currentMargin;
    } else if (shiftedQuotes.size > 0) {
      const currentCalculated = calculatePositionTotals(
        account,
        positions,
        symbolsByName,
        quotesBySymbol,
        riskConfig
      );
      margin = Math.max(0, currentMargin + calculated.margin - currentCalculated.margin);
    } else {
      margin = currentMargin;
    }
  }
  const accountMarginLevel = shiftedQuotes.size === 0 ? reportedMarginLevel(account) : NaN;

  return {
    equity,
    margin,
    floating: calculated.floating + floatingOffset,
    floatingOffset,
    marginLevel: Number.isFinite(accountMarginLevel)
      ? accountMarginLevel
      : margin > 0
        ? equity / margin
        : Number.POSITIVE_INFINITY
  };
}

function shiftedQuote(quote, direction, distancePoints, point) {
  const shift = (direction === 'down' ? -1 : 1) * distancePoints * point;
  return {
    ...quote,
    bid: Math.max(0.00000001, toNumber(quote.bid) + shift),
    ask: Math.max(0.00000001, toNumber(quote.ask) + shift)
  };
}

function riskSidePrice(quote, direction) {
  return direction === 'down' ? toNumber(quote.bid) : toNumber(quote.ask);
}

function searchLimitPoints(quote, direction, point, riskConfig) {
  const configured = toNumber(riskConfig.maxSearchDistancePoints, 200000);
  if (direction === 'down') {
    const priceLimit = Math.floor((riskSidePrice(quote, direction) * 0.95) / point);
    return Math.max(1, Math.min(configured, priceLimit));
  }
  return Math.max(1, configured);
}

function accountEquityGapToStopOut(currentState, stopOutLevel) {
  if (!Number.isFinite(currentState.equity) || !Number.isFinite(currentState.margin)) return NaN;
  if (currentState.margin <= 0) return NaN;
  return currentState.equity - currentState.margin * stopOutLevel;
}

function basePointValueToAccount({ positions, symbol, direction, symbolsByName, quotesBySymbol, riskConfig }) {
  const signedLots = netSignedVolume(positions, symbol, riskConfig);
  if (direction === 'down' && signedLots <= 0) return 0;
  if (direction === 'up' && signedLots >= 0) return 0;

  const symbolSpec = symbolSpecForName(symbolsByName, symbol);
  const contractSize = toNumber(symbolSpec.contractSize, 100000);
  const point = pointFromSymbol(symbolSpec);
  const profitCurrency = inferProfitCurrency(symbolSpec, symbol);
  const rateToAccount = toNumber(
    symbolSpec.profitCurrencyRateToUsd ?? symbolSpec.rateProfitToUsd,
    currencyToUsdRate(profitCurrency, quotesBySymbol || new Map())
  );
  return Math.abs(signedLots) * contractSize * point * rateToAccount;
}

function directLiquidationForDirection({
  account,
  positions,
  symbol,
  direction,
  symbolsByName,
  quotesBySymbol,
  riskConfig,
  stopOutLevel,
  currentState
}) {
  const quote = quotesBySymbol.get(symbol);
  const symbolSpec = symbolSpecForName(symbolsByName, symbol);
  if (!quote) return null;

  const point = pointFromSymbol(symbolSpec);
  const currentPrice = riskSidePrice(quote, direction);
  const equityGap = accountEquityGapToStopOut(currentState, stopOutLevel);
  if (!Number.isFinite(equityGap)) return null;

  const pointValueAccount = basePointValueToAccount({
    positions,
    symbol,
    direction,
    symbolsByName,
    quotesBySymbol,
    riskConfig
  });
  if (pointValueAccount <= 0) return null;

  const distancePoints = Math.max(0, equityGap / pointValueAccount);
  const rawLiquidationPrice =
    direction === 'down'
      ? currentPrice - distancePoints * point
      : currentPrice + distancePoints * point;
  const liquidationPrice = Math.max(0.00000001, rawLiquidationPrice);

  return {
    symbol,
    direction,
    currentPrice,
    liquidationPrice,
    distancePoints,
    quote,
    stopOutLevel,
    point,
    pointValueAccount,
    equityGap,
    convertedPrices: convertedPricesForBase({
      baseSymbol: symbol,
      direction,
      currentBasePrice: currentPrice,
      liquidationBasePrice: liquidationPrice,
      symbolsByName,
      quotesBySymbol,
      riskConfig
    })
  };
}

function findLiquidationForDirection({
  account,
  positions,
  symbol,
  direction,
  symbolsByName,
  quotesBySymbol,
  riskConfig,
  stopOutLevel
}) {
  const quote = quotesBySymbol.get(symbol);
  const symbolSpec = symbolSpecForName(symbolsByName, symbol);
  if (!quote) return null;

  const point = pointFromSymbol(symbolSpec);
  const currentState = calculatePortfolioState(account, positions, symbolsByName, quotesBySymbol, riskConfig);
  if (currentState.margin <= 0) return null;

  const currentPrice = riskSidePrice(quote, direction);
  const direct = directLiquidationForDirection({
    account,
    positions,
    symbol,
    direction,
    symbolsByName,
    quotesBySymbol,
    riskConfig,
    stopOutLevel,
    currentState
  });
  if (direct) return direct;

  const currentGap = currentState.marginLevel - stopOutLevel;
  if (currentGap <= 0) {
    return {
      symbol,
      direction,
      currentPrice,
      liquidationPrice: currentPrice,
      distancePoints: 0,
      quote,
      stopOutLevel,
      point,
      convertedPrices: convertedPricesForBase({
        baseSymbol: symbol,
        direction,
        currentBasePrice: currentPrice,
        liquidationBasePrice: currentPrice,
        symbolsByName,
        quotesBySymbol,
        riskConfig
      })
    };
  }

  const maxPoints = searchLimitPoints(quote, direction, point, riskConfig);
  const shifted = shiftedQuotesForRiskSymbol(symbol, quote, direction, maxPoints, point, quotesBySymbol, riskConfig);
  const farState = calculatePortfolioState(account, positions, symbolsByName, quotesBySymbol, riskConfig, {
    shiftedQuotes: shifted,
    floatingOffset: currentState.floatingOffset
  });

  if (farState.marginLevel > stopOutLevel) return null;

  let low = 0;
  let high = maxPoints;
  for (let index = 0; index < 80; index += 1) {
    const mid = (low + high) / 2;
    const midQuotes = shiftedQuotesForRiskSymbol(symbol, quote, direction, mid, point, quotesBySymbol, riskConfig);
    const state = calculatePortfolioState(account, positions, symbolsByName, quotesBySymbol, riskConfig, {
      shiftedQuotes: midQuotes,
      floatingOffset: currentState.floatingOffset
    });
    if (state.marginLevel <= stopOutLevel) high = mid;
    else low = mid;
  }

  const distancePoints = high;
  const finalQuote = shiftedQuote(quote, direction, distancePoints, point);
  const liquidationPrice = riskSidePrice(finalQuote, direction);
  return {
    symbol,
    direction,
    currentPrice,
    liquidationPrice,
    distancePoints,
    quote,
    stopOutLevel,
    point,
    convertedPrices: convertedPricesForBase({
      baseSymbol: symbol,
      direction,
      currentBasePrice: currentPrice,
      liquidationBasePrice: liquidationPrice,
      symbolsByName,
      quotesBySymbol,
      riskConfig
    })
  };
}

function shiftedQuotesForRiskSymbol(symbol, quote, direction, distancePoints, point, quotesBySymbol, riskConfig) {
  const shiftedBaseQuote = shiftedQuote(quote, direction, distancePoints, point);
  const shifted = new Map([[symbol, shiftedBaseQuote]]);
  for (const [quoteSymbol] of quotesBySymbol.entries()) {
    if (quoteSymbol === symbol) continue;
    const mapped = mappingForSymbol(quoteSymbol, riskConfig);
    if (!mapped || normalizeSymbolName(mapped.mapping.baseSymbol) !== normalizeSymbolName(symbol)) continue;
    shifted.set(quoteSymbol, quoteFromBaseQuote(quoteSymbol, shiftedBaseQuote, mapped.mapping, quotesBySymbol));
  }
  return shifted;
}

function netSignedVolume(positions, symbol, riskConfig = {}) {
  return positions
    .filter((position) => canonicalSymbol(position.symbol, riskConfig) === symbol)
    .reduce((sum, position) => {
      const signed = normalizeAction(position.action) === 'BUY' ? 1 : -1;
      return (
        sum +
        signed *
          Math.abs(toNumber(position.volumeLots ?? position.volume)) *
          lotsToBaseMultiplier(position.symbol, riskConfig)
      );
    }, 0);
}

function baseOpenPriceForPosition(position, riskConfig, quotesBySymbol) {
  const mapped = mappingForSymbol(position.symbol, riskConfig);
  if (mapped && mapped.mapping && mapped.mapping.baseSymbol) {
    return mappedToBasePrice(position.openPrice, mapped.mapping, quotesBySymbol);
  }
  return toNumber(position.openPrice);
}

function buildPositionDetails(positions, symbolsByName, quotesBySymbol, riskConfig = {}) {
  return positions.map((position) => {
    const symbol = symbolSpecForName(symbolsByName, position.symbol);
    const quote = quotesBySymbol.get(position.symbol);
    const metrics = positionProfitMetrics(position, symbol, quote);
    const lotsMultiplier = lotsToBaseMultiplier(position.symbol, riskConfig);
    const canonical = canonicalSymbol(position.symbol, riskConfig);
    const baseOpenPrice = baseOpenPriceForPosition(position, riskConfig, quotesBySymbol);
    const baseSpec = symbolSpecForName(symbolsByName, canonical);
    const baseEquivalentLots = metrics.volumeLots * lotsMultiplier;
    const baseContractSize = toNumber(baseSpec.contractSize, metrics.contractSize);
    const basePoint = pointFromSymbol(baseSpec);
    const baseProfitCurrency = inferProfitCurrency(baseSpec, canonical, metrics.profitCurrency);
    const baseProfitCurrencyRateToUsd = toNumber(
      baseSpec.profitCurrencyRateToUsd ?? baseSpec.rateProfitToUsd,
      currencyToUsdRate(baseProfitCurrency, quotesBySymbol)
    );
    const basePointValuePerLotAccount = baseContractSize * basePoint * baseProfitCurrencyRateToUsd;
    return {
      ...position,
      action: metrics.action,
      volumeLots: metrics.volumeLots,
      contractSize: metrics.contractSize,
      point: metrics.point,
      closePrice: metrics.closePrice,
      currentPrice: metrics.closePrice,
      closePriceSide: metrics.closePriceSide,
      quoteBid: quote ? toNumber(quote.bid, NaN) : undefined,
      quoteAsk: quote ? toNumber(quote.ask, NaN) : undefined,
      quoteTime: metrics.quoteTime,
      priceDiff: metrics.priceDiff,
      pointValue: metrics.pointValue,
      pointValueAccount: metrics.pointValueAccount,
      profitCurrency: metrics.profitCurrency,
      profitCurrencyRateToAccount: metrics.profitCurrencyRateToAccount,
      profit: metrics.profit,
      swap: metrics.swap,
      commission: metrics.commission,
      netProfit: metrics.netProfit,
      reportedProfit: metrics.reportedProfit,
      computedProfit: metrics.computedProfit,
      computedNetProfit: metrics.computedNetProfit,
      profitSource: metrics.profitSource,
      profitCheckDiff: metrics.profitCheckDiff,
      canonicalSymbol: canonical,
      lotsToBaseMultiplier: lotsMultiplier,
      baseEquivalentLots,
      baseContractSize,
      basePoint,
      baseProfitCurrency,
      basePointValuePerLotAccount,
      basePointValueAccount: baseEquivalentLots * basePointValuePerLotAccount,
      basePointValueCurrency: 'USD',
      baseOpenPrice
    };
  });
}

function buildSymbolExposures(positionDetails, quotesBySymbol, symbolsByName, riskConfig = {}) {
  const bySymbol = new Map();
  for (const position of positionDetails) {
    const exposureSymbol = position.canonicalSymbol || position.symbol;
    const baseSpec = symbolSpecForName(symbolsByName, exposureSymbol);
    const baseContractSize = toNumber(baseSpec.contractSize, position.contractSize);
    const basePoint = pointFromSymbol(baseSpec);
    const baseProfitCurrency = inferProfitCurrency(baseSpec, exposureSymbol, position.profitCurrency);
    const baseProfitCurrencyRateToUsd = toNumber(
      baseSpec.profitCurrencyRateToUsd ?? baseSpec.rateProfitToUsd,
      currencyToUsdRate(baseProfitCurrency, quotesBySymbol)
    );
    const current = bySymbol.get(exposureSymbol) || {
      symbol: exposureSymbol,
      displaySymbol: exposureSymbol,
      buyLots: 0,
      sellLots: 0,
      grossLots: 0,
      netLots: 0,
      netDirection: 'FLAT',
      positionCount: 0,
      openLots: 0,
      openPriceValue: 0,
      buyOpenLots: 0,
      buyOpenPriceValue: 0,
      sellOpenLots: 0,
      sellOpenPriceValue: 0,
      contractSize: baseContractSize,
      point: basePoint,
      profitCurrency: baseProfitCurrency,
      pointValueCurrency: 'USD',
      profitCurrencyRateToAccount: baseProfitCurrencyRateToUsd,
      pointValuePerLot: baseContractSize * basePoint,
      pointValuePerLotAccount: baseContractSize * basePoint * baseProfitCurrencyRateToUsd,
      totalPointValue: 0,
      totalPointValueAccount: 0,
      netPointValue: 0,
      netPointValueAccount: 0,
      grossContractUnits: 0,
      netContractUnits: 0,
      profit: 0,
      swap: 0,
      commission: 0,
      netProfit: 0,
      quote: quotesBySymbol.get(exposureSymbol) || null,
      components: []
    };
    const baseLots = Math.abs(position.baseEquivalentLots ?? position.volumeLots);
    const openPrice = toNumber(position.baseOpenPrice, position.openPrice);
    const signedLots = normalizeAction(position.action) === 'BUY' ? baseLots : -baseLots;
    current.openLots += baseLots;
    current.openPriceValue += openPrice * baseLots;
    if (signedLots > 0) {
      current.buyLots += baseLots;
      current.buyOpenLots += baseLots;
      current.buyOpenPriceValue += openPrice * baseLots;
    } else {
      current.sellLots += baseLots;
      current.sellOpenLots += baseLots;
      current.sellOpenPriceValue += openPrice * baseLots;
    }
    current.grossLots += baseLots;
    current.netLots += signedLots;
    current.positionCount += 1;
    current.totalPointValue += position.pointValue;
    current.totalPointValueAccount += position.pointValueAccount;
    current.grossContractUnits += baseLots * current.contractSize;
    current.profit += position.profit;
    current.swap += toNumber(position.swap);
    current.commission += toNumber(position.commission);
    current.netProfit += toNumber(position.netProfit, position.profit);
    current.components.push({
      symbol: position.symbol,
      volumeLots: position.volumeLots,
      baseEquivalentLots: baseLots,
      baseOpenPrice: openPrice,
      action: position.action,
      ticket: position.ticket,
      profit: position.profit,
      swap: position.swap,
      commission: position.commission,
      netProfit: position.netProfit
    });
    bySymbol.set(exposureSymbol, current);
  }

  return [...bySymbol.values()]
    .map((exposure) => {
      const finalSpec = symbolSpecForName(symbolsByName, exposure.symbol);
      const finalContractSize = toNumber(finalSpec.contractSize, exposure.contractSize);
      const finalPoint = pointFromSymbol(finalSpec);
      const finalProfitCurrency = inferProfitCurrency(finalSpec, exposure.symbol, exposure.profitCurrency);
      const finalProfitCurrencyRateToUsd = toNumber(
        finalSpec.profitCurrencyRateToUsd ?? finalSpec.rateProfitToUsd,
        currencyToUsdRate(finalProfitCurrency, quotesBySymbol)
      );
      const finalPointValuePerLot = finalContractSize * finalPoint;
      const finalPointValuePerLotAccount = finalPointValuePerLot * finalProfitCurrencyRateToUsd;
      const netDirection = exposure.netLots > 1e-9 ? 'BUY' : exposure.netLots < -1e-9 ? 'SELL' : 'FLAT';
      const netLots = Math.abs(exposure.netLots) < 1e-9 ? 0 : exposure.netLots;
      const averageOpenPrice = exposure.openLots > 0 ? exposure.openPriceValue / exposure.openLots : 0;
      const buyAverageOpenPrice =
        exposure.buyOpenLots > 0 ? exposure.buyOpenPriceValue / exposure.buyOpenLots : 0;
      const sellAverageOpenPrice =
        exposure.sellOpenLots > 0 ? exposure.sellOpenPriceValue / exposure.sellOpenLots : 0;
      const netAverageOpenPrice =
        netDirection === 'BUY' ? buyAverageOpenPrice : netDirection === 'SELL' ? sellAverageOpenPrice : averageOpenPrice;
      const grossPointValue = exposure.grossLots * finalPointValuePerLot;
      const grossPointValueAccount = exposure.grossLots * finalPointValuePerLotAccount;
      const netPointValue = Math.abs(netLots) * finalPointValuePerLot;
      const netPointValueAccount = Math.abs(netLots) * finalPointValuePerLotAccount;
      return {
        ...exposure,
        contractSize: finalContractSize,
        point: finalPoint,
        profitCurrency: finalProfitCurrency,
        profitCurrencyRateToAccount: finalProfitCurrencyRateToUsd,
        pointValuePerLot: finalPointValuePerLot,
        pointValuePerLotAccount: finalPointValuePerLotAccount,
        netLots,
        absNetLots: Math.abs(netLots),
        netDirection,
        averageOpenPrice,
        buyAverageOpenPrice,
        sellAverageOpenPrice,
        netAverageOpenPrice,
        adverseDirection: netDirection === 'BUY' ? 'down' : netDirection === 'SELL' ? 'up' : 'both',
        totalPointValue: grossPointValue,
        totalPointValueAccount: grossPointValueAccount,
        netPointValue,
        netPointValueAccount,
        netContractUnits: Math.abs(netLots) * exposure.contractSize
      };
    })
    .sort((left, right) => {
      if (right.grossLots !== left.grossLots) return right.grossLots - left.grossLots;
      if (right.grossContractUnits !== left.grossContractUnits) return right.grossContractUnits - left.grossContractUnits;
      return left.symbol.localeCompare(right.symbol);
    });
}

function calculateAccountRisk(account, positions, symbols, quotes, riskConfig = {}) {
  const accountPositions = positions.filter((position) => String(position.login) === String(account.login));
  const symbolsByName = arrayToMap(symbols, 'symbol');
  const quotesBySymbol = arrayToMap(quotes, 'symbol');
  const stopOutLevel = getAccountStopOutLevel(account, riskConfig);
  const currentState = calculatePortfolioState(account, accountPositions, symbolsByName, quotesBySymbol, riskConfig);
  const positionDetails = buildPositionDetails(accountPositions, symbolsByName, quotesBySymbol, riskConfig);

  const uniqueSymbols = [...new Set(accountPositions.map((position) => canonicalSymbol(position.symbol, riskConfig)))];
  const symbolRisks = [];
  for (const symbol of uniqueSymbols) {
    const signedVolume = netSignedVolume(accountPositions, symbol, riskConfig);
    const directions =
      Math.abs(signedVolume) < 1e-9 ? ['down', 'up'] : signedVolume > 0 ? ['down'] : ['up'];
    for (const direction of directions) {
      const result = findLiquidationForDirection({
        account,
        positions: accountPositions,
        symbol,
        direction,
        symbolsByName,
        quotesBySymbol,
        riskConfig,
        stopOutLevel
      });
      if (!result) continue;
      const dangerDistancePoints = getDangerDistancePoints(symbol, account, riskConfig);
      const warningDistancePoints = getWarningDistancePoints(symbol, account, riskConfig, dangerDistancePoints);
      const severity = riskSeverity({
        distancePoints: result.distancePoints,
        marginLevel: currentState.marginLevel,
        stopOutLevel,
        warningDistancePoints,
        dangerDistancePoints
      });
      symbolRisks.push({
        ...result,
        warningDistancePoints,
        dangerDistancePoints,
        alertDistancePoints: dangerDistancePoints || getAlertDistancePoints(symbol, riskConfig),
        severity,
        shouldAlert: severity === 'danger'
      });
    }
  }

  symbolRisks.sort((left, right) => left.distancePoints - right.distancePoints);
  const symbolExposures = buildSymbolExposures(positionDetails, quotesBySymbol, symbolsByName, riskConfig).map((exposure) => {
    const preferredDirection =
      exposure.netDirection === 'BUY' ? 'down' : exposure.netDirection === 'SELL' ? 'up' : undefined;
    const risk =
      symbolRisks.find((item) => item.symbol === exposure.symbol && item.direction === preferredDirection) ||
      symbolRisks.find((item) => item.symbol === exposure.symbol) ||
      null;
    if (risk) {
      risk.grossLots = exposure.grossLots;
      risk.buyLots = exposure.buyLots;
      risk.sellLots = exposure.sellLots;
      risk.netLots = exposure.netLots;
      risk.absNetLots = exposure.absNetLots;
      risk.netDirection = exposure.netDirection;
      risk.averageOpenPrice = exposure.netAverageOpenPrice || exposure.averageOpenPrice;
      risk.buyAverageOpenPrice = exposure.buyAverageOpenPrice;
      risk.sellAverageOpenPrice = exposure.sellAverageOpenPrice;
      risk.convertedPrices = convertedPricesForBase({
        baseSymbol: risk.symbol,
        direction: risk.direction,
        openBasePrice: risk.averageOpenPrice,
        currentBasePrice: risk.currentPrice,
        liquidationBasePrice: risk.liquidationPrice,
        symbolsByName,
        quotesBySymbol,
        riskConfig
      });
    }
    return { ...exposure, risk };
  });

  return {
    account,
    positions: accountPositions,
    positionDetails,
    symbolExposures,
    dashboardExposure: symbolExposures[0] || null,
    equity: currentState.equity,
    margin: currentState.margin,
    floating: currentState.floating,
    marginLevel: currentState.marginLevel,
    stopOutLevel,
    symbolRisks
  };
}

function calculateSnapshotRisk(snapshot, riskConfig = {}) {
  return (snapshot.accounts || []).map((account) =>
    calculateAccountRisk(
      account,
      snapshot.positions || [],
      snapshot.symbols || [],
      snapshot.quotes || [],
      riskConfig
    )
  );
}

module.exports = {
  normalizeStopOutLevel,
  getAccountStopOutLevel,
  getAlertDistancePoints,
  getWarningDistancePoints,
  getDangerDistancePoints,
  distanceThresholdFromExpression,
  riskSeverity,
  hasReportedMargin,
  reportedMarginLevel,
  accountEquityGapToStopOut,
  basePointValueToAccount,
  directLiquidationForDirection,
  calculatePortfolioState,
  calculateAccountRisk,
  calculateSnapshotRisk
};
