'use strict';

const LEVELS = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40
};

function createLogger(level = 'info') {
  const threshold = LEVELS[level] || LEVELS.info;
  function write(kind, args) {
    if ((LEVELS[kind] || LEVELS.info) < threshold) return;
    console.log(JSON.stringify({ time: new Date().toISOString(), level: kind, message: args.join(' ') }));
  }
  return {
    debug: (...args) => write('debug', args),
    info: (...args) => write('info', args),
    warn: (...args) => write('warn', args),
    error: (...args) => write('error', args)
  };
}

module.exports = {
  createLogger
};
