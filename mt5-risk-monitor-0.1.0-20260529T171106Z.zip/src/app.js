'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');
const { loadConfig, resolveFromCwd } = require('./config');
const { createProvider } = require('./providers');
const { filterAccountsByGroup, matchesGroupMask } = require('./domain/groupMask');
const { calculateSnapshotRisk } = require('./domain/riskEngine');
const { buildLpSnapshot } = require('./domain/lpExposure');
const { canonicalSymbol, mappingForSymbol } = require('./domain/symbolMapping');
const { CooldownStore } = require('./alerts/cooldownStore');
const { buildAlerts } = require('./alerts/alertEngine');
const { createMailer } = require('./mail/smtpMailer');
const { createTelegramNotifier } = require('./notifications/telegramNotifier');
const { createLogger } = require('./util/logger');

function filterSnapshot(snapshot, groupMasks, symbolMasks = [], riskConfig = {}) {
  const accountLoginSet = new Set((snapshot.__accountLogins || []).map((login) => String(login)));
  const accounts = filterAccountsByGroup(snapshot.accounts || [], groupMasks).filter(
    (account) => accountLoginSet.size === 0 || accountLoginSet.has(String(account.login))
  );
  const logins = new Set(accounts.map((account) => String(account.login)));
  const matchesSymbol = (symbol) => matchesGroupMask(symbol, symbolMasks);
  const matchesPositionSymbol = (position) =>
    matchesSymbol(position.symbol) || matchesSymbol(canonicalSymbol(position.symbol, riskConfig));
  const positions = (snapshot.positions || []).filter(
    (position) => logins.has(String(position.login)) && matchesPositionSymbol(position)
  );
  const usedSymbols = new Set(positions.map((position) => position.symbol));
  for (const position of positions) {
    const mapped = mappingForSymbol(position.symbol, riskConfig);
    if (mapped) {
      if (mapped.mapping.baseSymbol) usedSymbols.add(mapped.mapping.baseSymbol);
      if (mapped.mapping.fxSymbol) usedSymbols.add(mapped.mapping.fxSymbol);
      if (mapped.mapping.quoteSymbol) usedSymbols.add(mapped.mapping.quoteSymbol);
    }
  }
  const filterMarketItem = (item) => symbolMasks.length === 0 || usedSymbols.has(item.symbol) || matchesSymbol(item.symbol);
  const { __accountLogins, ...baseSnapshot } = snapshot;
  return {
    ...baseSnapshot,
    accounts,
    positions,
    symbols: (snapshot.symbols || []).filter(filterMarketItem),
    quotes: (snapshot.quotes || []).filter(filterMarketItem)
  };
}

function normalizeAccountLogins(values) {
  if (!values) return [];
  if (Array.isArray(values)) return values.map((value) => String(value).trim()).filter(Boolean);
  return String(values)
    .split(',')
    .map((value) => value.trim())
    .filter(Boolean);
}

function matchingSymbolSpec(symbol, specs = []) {
  const normalized = String(symbol || '').toUpperCase();
  const exact = specs.find((spec) => String(spec.symbol || '').toUpperCase() === normalized);
  if (exact) return exact;
  return specs.find((spec) => matchesGroupMask(normalized, [spec.symbol]));
}

function applyConfiguredSymbolSpecs(snapshot, symbolSpecs = []) {
  if (!Array.isArray(symbolSpecs) || symbolSpecs.length === 0) return snapshot;
  const bySymbol = new Map((snapshot.symbols || []).map((symbol) => [symbol.symbol, { ...symbol }]));
  const knownSymbols = new Set([
    ...(snapshot.symbols || []).map((symbol) => symbol.symbol),
    ...(snapshot.positions || []).map((position) => position.symbol),
    ...(snapshot.quotes || []).map((quote) => quote.symbol)
  ]);

  for (const symbol of knownSymbols) {
    const configured = matchingSymbolSpec(symbol, symbolSpecs);
    if (!configured) continue;
    bySymbol.set(symbol, mergeSymbolSpecFallback(bySymbol.get(symbol) || {}, configured, symbol));
  }

  return {
    ...snapshot,
    symbols: [...bySymbol.values()]
  };
}

function mergeSymbolSpecFallback(existing, configured, symbol) {
  const merged = { ...existing, symbol };
  for (const [key, value] of Object.entries(configured || {})) {
    if (key === 'symbol') continue;
    if (value === undefined || value === null || value === '') continue;
    if (isMissingSymbolField(merged[key])) merged[key] = value;
  }
  return merged;
}

function isMissingSymbolField(value) {
  if (value === undefined || value === null || value === '') return true;
  if (typeof value === 'number') return !Number.isFinite(value) || value <= 0;
  return false;
}

function appendLpRiskReports(snapshot, riskConfig, lpConfig) {
  const reports = calculateSnapshotRisk(snapshot, riskConfig);
  const lp = buildLpSnapshot(lpConfig, snapshot.positions || []);
  if (!lp) return reports;

  const lpSnapshot = {
    accounts: [lp.account],
    positions: lp.positions,
    symbols: snapshot.symbols || [],
    quotes: snapshot.quotes || []
  };
  return reports.concat(calculateSnapshotRisk(lpSnapshot, riskConfig));
}

function summarizeReports(reports) {
  return reports
    .map((report) => {
      const nearest = report.symbolRisks[0];
      if (!nearest) return `${report.account.login}: no liquidation price`;
      return `${report.account.login}:${nearest.symbol}/${nearest.direction} ${nearest.distancePoints.toFixed(0)}pt`;
    })
    .join('; ');
}

function resolveCooldown(config) {
  const notificationCooldown = config.notifications && config.notifications.cooldown;
  return {
    seconds: Number(
      notificationCooldown && notificationCooldown.seconds !== undefined
        ? notificationCooldown.seconds
        : 0
    ),
    priceMovementPoints: Number((notificationCooldown && notificationCooldown.priceMovementPoints) || 30),
    mode: (notificationCooldown && notificationCooldown.mode) || 'priceOnly'
  };
}

function alertPriceState(alert) {
  const risk = alert.symbolRisk || {};
  return {
    price: risk.currentPrice,
    point: risk.point,
    direction: risk.direction
  };
}

function alertCooldown(alert, fallbackCooldown) {
  return alert && alert.cooldown ? alert.cooldown : fallbackCooldown;
}

async function sendWithCooldown({ channel, alert, cooldown, cooldownStore, logger, send }) {
  const key = `${channel}:${alert.key}`;
  const priceState = alertPriceState(alert);
  const effectiveCooldown = alertCooldown(alert, cooldown);
  if (!(await cooldownStore.canSend(key, effectiveCooldown, priceState))) {
    logger.info(`${channel} cooldown skip key=${alert.key}`);
    return false;
  }
  try {
    await send();
  } catch (error) {
    logger.error(`${channel} alert failed key=${alert.key}: ${error.message}`);
    return false;
  }
  await cooldownStore.markSent(key, effectiveCooldown, priceState);
  logger.warn(`${channel} alert sent key=${alert.key} subject=${alert.subject}`);
  return true;
}

async function runOnce(config, services) {
  const { provider, mailer, telegramNotifier, cooldownStore, logger, template } = services;
  const rawSnapshot = await provider.getSnapshot({
    groupMasks: config.mt5.groupMasks || [],
    symbolMasks: config.mt5.symbolMasks || [],
    accountLogins: normalizeAccountLogins(config.mt5.accountLogins)
  });
  const enrichedSnapshot = applyConfiguredSymbolSpecs(rawSnapshot, config.mt5.symbolSpecs || []);
  enrichedSnapshot.__accountLogins = normalizeAccountLogins(config.mt5.accountLogins);
  const snapshot = filterSnapshot(enrichedSnapshot, config.mt5.groupMasks || [], config.mt5.symbolMasks || [], config.risk);
  const reports = appendLpRiskReports(snapshot, config.risk, config.lpAccount);
  const alerts = buildAlerts(reports, template, config.email.subjectTemplate, config.email.alertConditions, config.risk);

  logger.info(
    `snapshot accounts=${snapshot.accounts.length} positions=${snapshot.positions.length} alerts=${alerts.length} ${summarizeReports(reports)}`
  );

  const cooldown = resolveCooldown(config);
  for (const alert of alerts) {
    if (config.email.enabled) {
      await sendWithCooldown({
        channel: 'email',
        alert,
        cooldown,
        cooldownStore,
        logger,
        send: async () => {
          const recipients = (config.email.smtp && config.email.smtp.to) || [];
          await mailer.send({ to: recipients, subject: alert.subject, html: alert.html });
        }
      });
    } else {
      logger.info(`email disabled skip key=${alert.key}`);
    }

    if (config.telegram && config.telegram.enabled) {
      await sendWithCooldown({
        channel: 'telegram',
        alert,
        cooldown,
        cooldownStore,
        logger,
        send: async () => telegramNotifier.sendAlert(alert)
      });
    } else {
      logger.info(`telegram disabled skip key=${alert.key}`);
    }
  }

  return { snapshot, reports, alerts };
}

async function createServices(config) {
  const provider = createProvider(config);
  const mailer = createMailer(config);
  const telegramNotifier = createTelegramNotifier(config);
  const stateDir = resolveFromCwd(config, config.runtime.stateDir);
  const cooldownStore = new CooldownStore(path.join(stateDir, 'alerts.json'));
  const templatePath = resolveFromCwd(config, config.email.templatePath);
  const template = config.email.templateHtml || await fs.readFile(templatePath, 'utf8');
  const logger = createLogger(config.runtime.logLevel);
  return { provider, mailer, telegramNotifier, cooldownStore, template, logger };
}

async function closeServices(services) {
  if (services && services.provider && typeof services.provider.close === 'function') {
    await services.provider.close();
  }
}

function monitorIntervalMs(config) {
  return Math.max(100, Number(config.runtime.pollIntervalSeconds || 1) * 1000);
}

async function run(argv = process.argv) {
  const config = await loadConfig(argv);
  const services = await createServices(config);
  const logger = services.logger;

  if (config.__runOnce) {
    await runOnce(config, services);
    return;
  }

  let running = false;
  const intervalMs = monitorIntervalMs(config);
  const tick = async () => {
    if (running) {
      logger.warn('previous poll still running');
      return;
    }
    running = true;
    try {
      await runOnce(config, services);
    } catch (error) {
      logger.error(error.stack || error.message);
    } finally {
      running = false;
    }
  };

  await tick();
  setInterval(tick, intervalMs);
}

module.exports = {
  filterSnapshot,
  applyConfiguredSymbolSpecs,
  mergeSymbolSpecFallback,
  normalizeAccountLogins,
  appendLpRiskReports,
  summarizeReports,
  resolveCooldown,
  sendWithCooldown,
  closeServices,
  monitorIntervalMs,
  runOnce,
  createServices,
  run
};
