import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Code2, Eye, Loader2, RefreshCw, Send } from 'lucide-react';
import { NotificationCooldownEditor } from '@/components/ConfigEditors';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { toast } from '@/hooks/use-toast';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { joinCommaList, parseCommaList } from '@/lib/utils';
import type { AppConfig, TelegramChat } from '@/types/api';

interface EmailNotificationTabProps {
  config: AppConfig;
  onChange: (config: AppConfig) => void;
  onSave?: (config: AppConfig) => Promise<unknown>;
}

export function EmailNotificationTab({ config, onChange, onSave }: EmailNotificationTabProps) {
  const { t } = useI18n();
  const update = (patch: Partial<AppConfig>) => onChange({ ...config, ...patch });
  const email = normalizeEmail(config);
  const smtp = email.smtp;
  const telegram = normalizeTelegram(config);
  const notifications = normalizeNotifications(config);
  const cooldown = notifications.cooldown;
  const smtpPassword = smtp.password === '[redacted]' ? '' : smtp.password || '';
  const telegramBotToken = telegram.botToken === '[redacted]' ? '' : telegram.botToken || '';
  const [templateMode, setTemplateMode] = useState<'preview' | 'html'>('preview');
  const [templateLoaded, setTemplateLoaded] = useState(false);
  const [testingEmail, setTestingEmail] = useState(false);
  const [testingTelegram, setTestingTelegram] = useState(false);
  const [loadingTelegramChats, setLoadingTelegramChats] = useState(false);
  const [telegramChats, setTelegramChats] = useState<TelegramChat[]>([]);
  const [telegramNotice, setTelegramNotice] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const templateHtml = email.templateHtml || '';
  const previewHtml = useMemo(() => renderTemplatePreview(templateHtml, t), [templateHtml, t]);
  const telegramChatIdWarning = telegram.chatIds.some((chatId) => /^@[A-Za-z0-9_]*bot$/i.test(String(chatId || '').trim()))
    ? t('Chat IDs 中看起来填了机器人用户名。机器人用户名不能作为接收方，请点击“读取最近聊天”获取数字 Chat ID。', 'Chat IDs appear to contain the bot username. The bot username cannot be used as a recipient; load recent chats to get the numeric Chat ID.')
    : '';

  useEffect(() => {
    if (templateLoaded || email.templateHtml) return;
    setTemplateLoaded(true);
    api.getEmailTemplate()
      .then((result) => {
        if (result.html && !email.templateHtml) {
          update({ email: { ...email, templateHtml: result.html } });
        }
      })
      .catch(() => {});
  }, [templateLoaded, email]);

  const sendTestEmail = async () => {
    setTestingEmail(true);
    try {
      if (onSave) await onSave(config);
      const result = await api.sendTestEmail();
      toast({
        title: t('测试邮件已发送', 'Test email sent'),
        description: result.to.length ? t(`收件人：${result.to.join(', ')}`, `Recipients: ${result.to.join(', ')}`) : `Transport: ${result.transport}`,
      });
    } catch (error) {
      toast({
        title: t('测试邮件发送失败', 'Failed to send test email'),
        description: error instanceof Error ? error.message : t('未知错误', 'Unknown error'),
        variant: 'destructive',
      });
    } finally {
      setTestingEmail(false);
    }
  };

  const sendTestTelegram = async () => {
    setTestingTelegram(true);
    setTelegramNotice(null);
    try {
      if (telegramChatIdWarning) {
        throw new Error(telegramChatIdWarning);
      }
      if (onSave) await onSave(config);
      const result = await api.sendTestTelegram();
      const message = t(`测试消息已发送到：${result.chatIds.join(', ')}`, `Test message sent to: ${result.chatIds.join(', ')}`);
      setTelegramNotice({ type: 'success', text: message });
      toast({
        title: t('Telegram 测试消息已发送', 'Telegram test message sent'),
        description: message,
      });
    } catch (error) {
      const message = telegramActionErrorMessage(error, t);
      setTelegramNotice({ type: 'error', text: message });
      toast({
        title: t('Telegram 测试失败', 'Telegram test failed'),
        description: message,
        variant: 'destructive',
      });
    } finally {
      setTestingTelegram(false);
    }
  };

  const loadTelegramChats = async () => {
    setLoadingTelegramChats(true);
    setTelegramNotice(null);
    try {
      if (onSave) await onSave(config);
      const result = await api.getTelegramUpdates();
      setTelegramChats(result.chats);
      setTelegramNotice({
        type: result.chats.length ? 'success' : 'info',
        text: result.chats.length
          ? t(`读取到 ${result.chats.length} 个聊天，请点击“填入”保存 Chat ID。`, `Found ${result.chats.length} chats. Click “Use” to save a Chat ID.`)
          : t('没有读取到聊天。请先在 Telegram 给机器人发送 /start；群组需要把机器人加入群并发送一条消息。', 'No chats found. Send /start to the bot first; for groups, add the bot and send one message.'),
      });
    } catch (error) {
      const message = telegramActionErrorMessage(error, t);
      setTelegramNotice({ type: 'error', text: message });
      toast({
        title: t('读取 Chat ID 失败', 'Failed to load Chat IDs'),
        description: message,
        variant: 'destructive',
      });
    } finally {
      setLoadingTelegramChats(false);
    }
  };

  const appendTelegramChatId = (chatId: string) => {
    const nextChatIds = Array.from(new Set([...telegram.chatIds, chatId].filter(Boolean)));
    update({ telegram: { ...telegram, chatIds: nextChatIds } });
    setTelegramNotice({ type: 'success', text: t(`已填入 Chat ID：${chatId}，请保存配置。`, `Chat ID added: ${chatId}. Please save configuration.`) });
  };

  return (
    <div className="space-y-3 pb-16">
      <Card>
        <CardHeader>
          <CardTitle>{t('邮件服务器配置', 'Email Server Configuration')}</CardTitle>
          <CardDescription>{t('SMTP、发件人和收件人', 'SMTP, sender, and recipients')}</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <ToggleField
            className="sm:col-span-2 lg:col-span-3"
            label={t('启用邮件提醒', 'Enable Email Alerts')}
            checked={email.enabled}
            onCheckedChange={(checked) => update({ email: { ...email, enabled: checked } })}
          />
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-zinc-800 bg-zinc-950/60 p-3 sm:col-span-2 lg:col-span-3">
            <div>
              <div className="text-xs font-semibold text-zinc-200">{t('模拟触发邮件测试', 'Simulated Trigger Email Test')}</div>
              <p className="mt-1 text-[11px] text-zinc-500">{t('会先保存当前邮件配置，再用模拟爆仓数据渲染 HTML 模板并发送测试邮件。', 'Saves the current email configuration first, then renders the HTML template with simulated liquidation data and sends a test email.')}</p>
            </div>
            <Button type="button" variant="outline" onClick={sendTestEmail} disabled={testingEmail}>
              {testingEmail ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
              {testingEmail ? t('发送中...', 'Sending...') : t('发送测试邮件', 'Send Test Email')}
            </Button>
          </div>
          <Field label={t('发送方式', 'Transport')}>
            <select
              className="flex h-8 w-full rounded-md border border-zinc-800 bg-zinc-950 px-2 text-xs text-zinc-100"
              value={email.transport}
              onChange={(e) => update({ email: { ...email, transport: e.target.value } })}
            >
              <option value="console">console</option>
              <option value="smtp">smtp</option>
            </select>
          </Field>
          <Field label={t('SMTP 主机', 'SMTP Host')}>
            <Input
              value={smtp.host}
              onChange={(e) => update({ email: { ...email, smtp: { ...smtp, host: e.target.value } } })}
            />
          </Field>
          <Field label={t('SMTP 端口', 'SMTP Port')}>
            <Input
              type="number"
              value={smtp.port}
              onChange={(e) => update({ email: { ...email, smtp: { ...smtp, port: Number(e.target.value) } } })}
            />
          </Field>
          <ToggleField
            label={t('启用 TLS', 'Secure (TLS)')}
            checked={smtp.secure}
            onCheckedChange={(checked) => update({ email: { ...email, smtp: { ...smtp, secure: checked } } })}
          />
          <Field label={t('发件人', 'From')}>
            <Input
              value={smtp.from}
              onChange={(e) => update({ email: { ...email, smtp: { ...smtp, from: e.target.value } } })}
            />
          </Field>
          <Field label={t('收件人（逗号分隔）', 'To (comma-separated)')}>
            <Input
              value={joinCommaList(smtp.to)}
              onChange={(e) => update({ email: { ...email, smtp: { ...smtp, to: parseCommaList(e.target.value) } } })}
            />
          </Field>
          <Field label={t('用户名', 'Username')}>
            <Input
              value={smtp.username || ''}
              placeholder={smtp.usernameEnv ? `已使用 ${smtp.usernameEnv}` : ''}
              onChange={(e) => update({ email: { ...email, smtp: { ...smtp, username: e.target.value } } })}
            />
          </Field>
          <Field label={t('密码', 'Password')}>
            <Input
              type="password"
              value={smtpPassword}
              placeholder={smtp.password === '[redacted]' ? '已保存密码' : smtp.passwordEnv ? `已使用 ${smtp.passwordEnv}` : ''}
              onChange={(e) => update({ email: { ...email, smtp: { ...smtp, password: e.target.value } } })}
            />
          </Field>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('邮件模板', 'Email Template')}</CardTitle>
          <CardDescription>{t('HTML 邮件模板可直接编辑；默认显示预览，也可以切换源码', 'HTML templates can be edited directly; preview is shown by default and source code is one click away.')}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
          <Field label={t('HTML 模板路径', 'HTML Template Path')}>
            <Input
              value={email.templatePath}
              onChange={(e) => update({ email: { ...email, templatePath: e.target.value } })}
            />
          </Field>
          <Field label={t('邮件主题模板', 'Email Subject Template')}>
            <Input
              value={email.subjectTemplate}
              onChange={(e) => update({ email: { ...email, subjectTemplate: e.target.value } })}
            />
          </Field>
          </div>
          <div className="overflow-hidden rounded-md border border-zinc-800">
            <div className="flex items-center justify-between border-b border-zinc-800 bg-zinc-950 px-3 py-2">
              <div className="text-xs font-semibold text-zinc-300">{t('邮件模板内容', 'Email Template Content')}</div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setTemplateMode(templateMode === 'preview' ? 'html' : 'preview')}
              >
                {templateMode === 'preview' ? <Code2 className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                {templateMode === 'preview' ? t('查看 HTML', 'View HTML') : t('查看预览', 'View Preview')}
              </Button>
            </div>
            {templateMode === 'preview' ? (
              <iframe
                title={t('邮件模板预览', 'Email template preview')}
                className="h-[460px] w-full bg-white"
                sandbox=""
                srcDoc={previewHtml}
              />
            ) : (
              <textarea
                value={templateHtml}
                onChange={(e) => update({ email: { ...email, templateHtml: e.target.value } })}
                className="h-[460px] w-full resize-none bg-zinc-950 p-3 font-mono text-xs leading-relaxed text-zinc-100 outline-none focus:ring-1 focus:ring-emerald-600"
              />
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('Telegram 机器人配置', 'Telegram Bot Configuration')}</CardTitle>
          <CardDescription>{t('机器人 Token、Chat ID 与 Telegram 消息模板', 'Bot token, chat IDs, and Telegram message template')}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-2 rounded-md border border-zinc-800 bg-zinc-950/70 p-3 text-xs text-zinc-300 sm:grid-cols-3">
            <div>
              <div className="mb-1 font-semibold text-zinc-100">{t('1. 创建机器人', '1. Create Bot')}</div>
              <p className="leading-relaxed text-zinc-500">
                {t('在 Telegram 打开', 'Open')} <span className="font-mono text-zinc-300">@BotFather</span>{t('，使用', ', use')} <span className="font-mono text-zinc-300">/newbot</span> {t('获取 Bot Token。', 'to get a Bot Token.')}
              </p>
              <p className="mt-1 leading-relaxed text-zinc-500">
                {t('后台只需要一个 Bot Token。机器人用户名只方便搜索，实际发送还必须有接收方 Chat ID。', 'Only one Bot Token is needed. The bot username is only for finding the bot; sending also requires the recipient Chat ID.')}
              </p>
            </div>
            <div>
              <div className="mb-1 font-semibold text-zinc-100">{t('2. 准备 Chat ID', '2. Prepare Chat ID')}</div>
              <p className="leading-relaxed text-zinc-500">
                {t('私聊机器人先发送', 'Send')} <span className="font-mono text-zinc-300">/start</span>{t('；群组提醒先把机器人加入群并发送一条消息，再填写群组 ID 或频道用户名。', ' to the bot first. For group alerts, add the bot to the group, send one message, then enter the group ID or channel username.')}
              </p>
            </div>
            <div>
              <div className="mb-1 font-semibold text-zinc-100">{t('3. 保存并启用', '3. Save and Enable')}</div>
              <p className="leading-relaxed text-zinc-500">
                {t('Token 推荐写入环境变量；页面可临时填写明文 Token，保存时会隐藏展示，启用后与邮件共用通知冷却规则。', 'It is recommended to store the token in an environment variable. You can temporarily enter a plain token here; it will be hidden after saving and shares the same notification cooldown with email alerts.')}
              </p>
            </div>
          </div>
          <div className="space-y-3 rounded-md border border-zinc-800 bg-zinc-950/60 p-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-xs font-semibold text-zinc-200">{t('Chat ID 获取与测试', 'Chat ID Discovery and Test')}</div>
                <p className="mt-1 text-[11px] leading-relaxed text-zinc-500">
                  {t('填写或保存 Bot Token 后，先给机器人发送 /start，再点击读取最近聊天。读取到的个人 ID 通常是数字；群组或超级群一般是负数，超级群常以 -100 开头。如果在中国大陆网络运行，请填写 ClashX HTTP/Mixed 代理地址。', 'After entering or saving the Bot Token, send /start to the bot, then load recent chats. Personal IDs are usually numbers; groups are negative, and supergroups often start with -100. If running from mainland China, enter the ClashX HTTP/Mixed proxy URL.')}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Button type="button" variant="outline" onClick={loadTelegramChats} disabled={loadingTelegramChats}>
                  {loadingTelegramChats ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
                  {loadingTelegramChats ? t('读取中...', 'Loading...') : t('读取最近聊天', 'Load Recent Chats')}
                </Button>
                <Button type="button" variant="outline" onClick={sendTestTelegram} disabled={testingTelegram}>
                  {testingTelegram ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                  {testingTelegram ? t('发送中...', 'Sending...') : t('发送测试消息', 'Send Test Message')}
                </Button>
              </div>
            </div>
            {telegramNotice && (
              <div
                className={`rounded-md border px-3 py-2 text-xs ${
                  telegramNotice.type === 'error'
                    ? 'border-red-900/60 bg-red-950/30 text-red-200'
                    : telegramNotice.type === 'success'
                      ? 'border-emerald-900/60 bg-emerald-950/20 text-emerald-200'
                      : 'border-amber-900/60 bg-amber-950/20 text-amber-200'
                }`}
              >
                {telegramNotice.text}
              </div>
            )}
            {telegramChatIdWarning && (
              <div className="rounded-md border border-amber-900/60 bg-amber-950/20 px-3 py-2 text-xs text-amber-200">
                {telegramChatIdWarning}
              </div>
            )}
            {telegramChats.length > 0 && (
              <div className="overflow-hidden rounded-md border border-zinc-800">
                <div className="grid grid-cols-[140px_90px_1fr_110px] border-b border-zinc-800 bg-zinc-950 px-2 py-2 text-[10px] font-semibold uppercase text-zinc-500">
                  <div>{t('Chat ID', 'Chat ID')}</div>
                  <div>{t('类型', 'Type')}</div>
                  <div>{t('名称/最近消息', 'Name / Last Message')}</div>
                  <div className="text-right">{t('操作', 'Action')}</div>
                </div>
                {telegramChats.map((chat) => (
                  <div key={chat.id} className="grid grid-cols-[140px_90px_1fr_110px] items-center gap-0 border-b border-zinc-800/60 px-2 py-2 text-xs last:border-b-0">
                    <div className="font-mono text-zinc-200">{chat.id}</div>
                    <div className="text-zinc-500">{chat.type || '—'}</div>
                    <div className="min-w-0">
                      <div className="truncate text-zinc-300">{chat.title || chat.username || '—'}</div>
                      <div className="truncate text-[10px] text-zinc-600">{chat.lastText || chat.date || '—'}</div>
                    </div>
                    <div className="text-right">
                      <Button type="button" variant="secondary" size="sm" onClick={() => appendTelegramChatId(chat.id)}>
                        {t('填入', 'Use')}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <ToggleField
            className="sm:col-span-2 lg:col-span-3"
            label={t('启用 Telegram 提醒', 'Enable Telegram Alerts')}
            checked={telegram.enabled}
            onCheckedChange={(checked) => update({ telegram: { ...telegram, enabled: checked } })}
          />
          <Field label={t('Bot Token', 'Bot Token')}>
            <Input
              type="password"
              value={telegramBotToken}
              placeholder={telegram.botToken === '[redacted]' ? t('已保存 Token，留空不修改', 'Saved token; leave blank to keep it') : t('粘贴 BotFather 生成的 Token', 'Paste the token generated by BotFather')}
              onChange={(e) => update({ telegram: { ...telegram, botToken: e.target.value } })}
            />
          </Field>
          <Field label={t('Chat IDs（逗号分隔）', 'Chat IDs (comma-separated)')}>
            <Input
              value={joinCommaList(telegram.chatIds)}
              placeholder={t('个人/群组数字 ID，例如 123456789 或 -1001234567890', 'Numeric personal/group ID, e.g. 123456789 or -1001234567890')}
              onChange={(e) => update({ telegram: { ...telegram, chatIds: parseCommaList(e.target.value) } })}
            />
          </Field>
          <Field label={t('代理地址（可选）', 'Proxy URL (Optional)')}>
            <Input
              value={telegram.proxyUrl || ''}
              placeholder="http://127.0.0.1:7890"
              onChange={(e) => update({ telegram: { ...telegram, proxyUrl: e.target.value } })}
            />
          </Field>
          <Field label={t('解析模式', 'Parse Mode')}>
            <select
              className="flex h-8 w-full rounded-md border border-zinc-800 bg-zinc-950 px-2 text-xs text-zinc-100"
              value={telegram.parseMode}
              onChange={(e) => update({ telegram: { ...telegram, parseMode: e.target.value } })}
            >
              <option value="HTML">HTML</option>
              <option value="MarkdownV2">MarkdownV2</option>
              <option value="">{t('无', 'None')}</option>
            </select>
          </Field>
          <Field label={t('请求超时 (ms)', 'Request Timeout (ms)')}>
            <Input
              type="number"
              min={1000}
              value={telegram.timeoutMs}
              onChange={(e) => update({ telegram: { ...telegram, timeoutMs: Number(e.target.value) } })}
            />
          </Field>
          <ToggleField
            label={t('禁用链接预览', 'Disable Link Preview')}
            checked={telegram.disableWebPagePreview}
            onCheckedChange={(checked) => update({ telegram: { ...telegram, disableWebPagePreview: checked } })}
          />
          <div className="sm:col-span-2 lg:col-span-3">
            <Field label={t('Telegram 消息模板', 'Telegram Message Template')}>
              <textarea
                value={telegram.messageTemplate}
                onChange={(e) => update({ telegram: { ...telegram, messageTemplate: e.target.value } })}
                className="min-h-32 w-full rounded-md border border-zinc-800 bg-zinc-950 px-3 py-2 font-mono text-xs text-zinc-100 outline-none focus:ring-1 focus:ring-emerald-600"
              />
            </Field>
          </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-3">
        <Card>
          <CardHeader>
            <CardTitle>{t('通知冷却', 'Notification Cooldown')}</CardTitle>
            <CardDescription>{t('默认向更不利方向每 30 pip 才重复提醒；也可以叠加时间冷却', 'By default, repeat alerts are sent only after every 30-pip adverse move; time cooldown can also be combined.')}</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <NotificationCooldownEditor
                value={cooldown}
                onChange={(nextCooldown) =>
                  update({
                    email: { ...email, cooldownSeconds: nextCooldown.seconds },
                    notifications: {
                      ...notifications,
                      cooldown: nextCooldown,
                    },
                  })
                }
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function normalizeEmail(config: AppConfig) {
  const base = {
    enabled: false,
    transport: 'console',
    templatePath: 'templates/liquidation-alert.html',
    templateHtml: '',
    cooldownSeconds: 0,
    subjectTemplate: '[爆仓预警] {{account.login}} {{risk.symbol}} 距离 {{risk.distancePoints}} 点',
    alertConditions: {
      accountScope: 'all' as const,
      triggerMode: 'any' as const,
      distanceToLiquidation: true,
      stopOut: { enabled: true },
      marginLevel: { enabled: false, threshold: 0.8 },
    },
    smtp: {
      host: '',
      port: 587,
      secure: false,
      username: '',
      password: '',
      usernameEnv: 'SMTP_USER',
      passwordEnv: 'SMTP_PASSWORD',
      from: '',
      to: [] as string[],
      timeoutMs: 10000,
    },
  };
  return {
    ...base,
    ...(config.email || {}),
    alertConditions: {
      ...base.alertConditions,
      ...(config.email?.alertConditions || {}),
      stopOut: {
        ...base.alertConditions.stopOut,
        ...(config.email?.alertConditions?.stopOut || {}),
      },
      marginLevel: {
        ...base.alertConditions.marginLevel,
        ...(config.email?.alertConditions?.marginLevel || {}),
      },
    },
    smtp: {
      ...base.smtp,
      ...(config.email?.smtp || {}),
    },
  };
}

function renderTemplatePreview(html: string, t: (zh: string, en: string) => string) {
  const template = html || `<div style="font-family:Arial;padding:24px">${t('邮件模板尚未加载', 'Email template is not loaded')}</div>`;
  return template.replace(/\{\{\s*([^}]+)\s*\}\}/g, (_match, key) => {
    const normalized = String(key).trim();
    const values: Record<string, string> = {
      'account.login': '100002',
      'account.group': 'real\\Real_sale\\Basic5k',
      'account.currency': 'USD',
      'account.balance': '1,000.00',
      'account.equity': '1,051.68',
      'account.margin': '79.02',
      'account.marginLevelPercent': '1330.90',
      'account.leverage': '5000',
      'risk.symbol': 'XAUUSD',
      'risk.direction': '下跌',
      'risk.currentPrice': '4508.08',
      'risk.liquidationPrice': '4478.37',
      'risk.distancePoints': '3374',
      'risk.alertDistancePoints': '300',
      'risk.stopOutLevelPercent': '50.00',
      'risk.quoteBid': '4500.00',
      'risk.quoteAsk': '4500.15',
      'risk.grossLots': '0.70',
      'risk.netLots': '0.30',
      'risk.convertedPrices': 'XAUUSD: 4508.08 -> 4478.37 (3374 pt)',
      'alert.reason': '距离爆仓点数 3374.00 <= 5000',
      'alert.conditions': '距离爆仓点数 3374.00 <= 5000',
      generatedAt: new Date().toISOString(),
      positionsHtml:
        `<table cellpadding="6" cellspacing="0" style="border-collapse:collapse;border:1px solid #d1d5db"><tr><td>12345</td><td>XAUUSD</td><td>${t('买', 'BUY')}</td><td>0.50</td><td>4508.08</td></tr></table>`,
    };
    return values[normalized] ?? '';
  });
}

function telegramActionErrorMessage(error: unknown, t: (zh: string, en: string) => string) {
  const message = error instanceof Error ? error.message : t('未知错误', 'Unknown error');
  if (message.includes('后端 API 版本过旧') || message.includes('接口不存在') || message.includes('Unknown API route')) {
    return t(
      '当前页面已经更新，但 2001 端口仍在运行旧后端，Telegram 新接口还没有生效。请停止旧服务后重启：python3 mac_local_demo.py --stop-stale，然后重新运行 mac_local_demo.py。',
      'The page is updated, but port 2001 is still running an old backend and the Telegram API routes are not active. Restart with: python3 mac_local_demo.py --stop-stale, then run mac_local_demo.py again.',
    );
  }
  return message;
}

function normalizeTelegram(config: AppConfig) {
  const defaults = {
    enabled: false,
    botTokenEnv: 'TELEGRAM_BOT_TOKEN',
    botToken: '',
    chatIds: [] as string[],
    proxyUrl: '',
    parseMode: 'HTML',
    disableWebPagePreview: true,
    timeoutMs: 10000,
    messageTemplate: '<b>爆仓风险预警</b>\n账号: {{account.login}}\n产品: {{risk.symbol}}\n距离: {{risk.distancePoints}} 点',
  };
  return Object.assign({}, defaults, config.telegram || {});
}

function normalizeNotifications(config: AppConfig) {
  const cooldownDefaults = {
    seconds: 0,
    priceMovementPoints: 30,
    mode: 'priceOnly' as const,
  };
  return Object.assign({}, config.notifications || {}, {
    cooldown: Object.assign({}, cooldownDefaults, config.notifications?.cooldown || {}),
  });
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-1">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function ToggleField({
  label,
  checked,
  onCheckedChange,
  className = '',
}: {
  label: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  className?: string;
}) {
  return (
    <div className={`space-y-1 ${className}`}>
      <Label>{label}</Label>
      <div className="flex h-8 items-center">
        <Switch checked={checked} onCheckedChange={onCheckedChange} />
      </div>
    </div>
  );
}
