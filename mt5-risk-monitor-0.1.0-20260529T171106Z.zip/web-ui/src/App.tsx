import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Activity, LockKeyhole, Server, ShieldCheck, UserRound } from 'lucide-react';
import { AppShell } from '@/components/AppShell';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Toaster } from '@/components/ui/toaster';
import { toast } from '@/hooks/use-toast';
import { useI18n } from '@/i18n';
import { useMonitor } from '@/hooks/useMonitor';
import { api } from '@/lib/api';
import type { AuthStatus } from '@/types/api';

type View = 'dashboard' | 'configuration';

export default function App() {
  const { t } = useI18n();
  const [view, setView] = useState<View>('dashboard');
  const [auth, setAuth] = useState<AuthStatus | null>(null);
  const appActive = Boolean(auth && (!auth.enabled || auth.authenticated));
  const {
    status,
    risk,
    config,
    saving,
    toggleMonitor,
    saveConfig,
    testMt5Connection,
    streamConnected,
  } = useMonitor(appActive);

  useEffect(() => {
    api.authStatus()
      .then(setAuth)
      .catch(() => setAuth({ enabled: false, authenticated: true, user: null }));
  }, []);

  const handleToggleMonitor = useCallback(async () => {
    try {
      const s = await toggleMonitor();
      toast({
        title: s.running ? t('轮询已启动', 'Monitoring started') : t('轮询已停止', 'Monitoring stopped'),
        description: s.running
          ? t(`每 ${s.pollIntervalSeconds} 秒自动同步`, `Auto-sync every ${s.pollIntervalSeconds} seconds`)
          : t('后台轮询已暂停', 'Background polling is paused'),
      });
    } catch (e) {
      toast({
        title: t('操作失败', 'Operation failed'),
        description: e instanceof Error ? e.message : t('未知错误', 'Unknown error'),
        variant: 'destructive',
      });
    }
  }, [toggleMonitor]);

  if (!auth) {
    return <FullScreenMessage text={t('加载中...', 'Loading...')} />;
  }

  if (auth.enabled && !auth.authenticated) {
    return (
      <ErrorBoundary>
        <LoginPage onLoggedIn={setAuth} />
        <Toaster />
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary>
      <AppShell
        view={view}
        onViewChange={setView}
        status={status}
        risk={risk}
        config={config}
        streamConnected={streamConnected}
        saving={saving}
        onToggleMonitor={handleToggleMonitor}
        onSaveConfig={saveConfig}
        onTestMt5Connection={testMt5Connection}
      />
      <Toaster />
    </ErrorBoundary>
  );
}

function LoginPage({ onLoggedIn }: { onLoggedIn: (status: AuthStatus) => void }) {
  const { t } = useI18n();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const login = async () => {
    setSubmitting(true);
    try {
      const status = await api.login(username, password);
      onLoggedIn(status);
      toast({ title: t('登录成功', 'Login successful'), description: t(`欢迎 ${status.user?.username || username}`, `Welcome ${status.user?.username || username}`) });
    } catch (error) {
      toast({
        title: t('登录失败', 'Login failed'),
        description: error instanceof Error ? error.message : t('用户名或密码错误', 'Invalid username or password'),
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="grid min-h-screen bg-zinc-950 text-zinc-200 lg:grid-cols-[1.1fr_0.9fr]">
      <section className="relative hidden overflow-hidden border-r border-zinc-800 bg-zinc-950 lg:flex lg:flex-col lg:justify-between">
        <div className="absolute inset-x-0 top-0 h-64 bg-[linear-gradient(135deg,rgba(16,185,129,0.22),rgba(24,24,27,0)_62%)]" />
        <div className="relative p-12">
          <div className="flex items-center gap-3">
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 shadow-[0_0_18px_rgba(16,185,129,0.9)]" />
            <div>
              <div className="text-xl font-bold tracking-wide text-white">MT5 Risk Monitor</div>
              <div className="text-xs uppercase tracking-[0.28em] text-emerald-400">{t('专业风控控制台', 'Professional Risk Console')}</div>
            </div>
          </div>

          <div className="mt-20 max-w-xl">
            <h1 className="text-4xl font-bold leading-tight tracking-tight text-white">
              {t('实时监控客户与 LP 账户的爆仓风险', 'Real-time liquidation risk monitoring for client and LP accounts')}
            </h1>
            <p className="mt-5 max-w-lg text-sm leading-7 text-zinc-400">
              {t('通过服务端连接 MT5 Manager / Web API，同步账号、持仓、报价、保证金和告警状态。浏览器只负责登录与展示，敏感配置保存在服务器端。', 'The server connects to MT5 Manager / Web API to sync accounts, positions, quotes, margin, and alert status. The browser only handles login and display; sensitive configuration stays on the server.')}
            </p>
          </div>
        </div>

        <div className="relative grid gap-3 p-12 pt-0">
          <LoginFeature icon={<Server className="h-4 w-4" />} title={t('IP + 端口 / 域名访问', 'IP + Port / Domain Access')} text={t('同一套服务可直接监听内网 IP，也可接入 Nginx 或 Cloudflare。', 'The same service can listen on an internal IP directly, or sit behind Nginx or Cloudflare.')} />
          <LoginFeature icon={<ShieldCheck className="h-4 w-4" />} title={t('HttpOnly 会话', 'HttpOnly Session')} text={t('登录状态使用服务端会话 Cookie，不写入 localStorage。', 'Login state uses server-side session cookies and is not written to localStorage.')} />
          <LoginFeature icon={<Activity className="h-4 w-4" />} title={t('实时风控数据', 'Real-time Risk Data')} text={t('页面通过 SSE 接收后端推送，持仓明细随最新快照刷新。', 'The page receives backend pushes through SSE, and position details refresh with the latest snapshot.')} />
        </div>
      </section>

      <section className="flex min-h-screen items-center justify-center px-5 py-10">
        <div className="w-full max-w-md">
          <div className="mb-8 lg:hidden">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.9)]" />
              <h1 className="text-xl font-bold text-white">MT5 Risk Monitor</h1>
            </div>
            <p className="mt-2 text-xs text-zinc-500">{t('专业风控控制台', 'Professional Risk Console')}</p>
          </div>

          <div className="rounded-md border border-zinc-800 bg-zinc-900 p-7 shadow-2xl">
            <div className="mb-6">
              <div className="mb-3 inline-flex rounded-md border border-emerald-900/50 bg-emerald-950/20 px-2.5 py-1 text-[11px] font-medium text-emerald-300">
                {t('安全后台登录', 'Secure Admin Login')}
              </div>
              <h2 className="text-2xl font-bold text-white">{t('登录风控后台', 'Sign in to Risk Console')}</h2>
              <p className="mt-2 text-sm text-zinc-500">{t('使用部署时生成的后台用户名和密码。', 'Use the admin username and password generated during deployment.')}</p>
            </div>

            <form className="space-y-4" onSubmit={(event) => { event.preventDefault(); void login(); }}>
              <div className="space-y-1.5">
                <Label>{t('用户名', 'Username')}</Label>
                <div className="relative">
                  <UserRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
                  <Input className="pl-9" value={username} autoComplete="username" onChange={(event) => setUsername(event.target.value)} />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>{t('密码', 'Password')}</Label>
                <div className="relative">
                  <LockKeyhole className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
                  <Input className="pl-9" type="password" value={password} autoComplete="current-password" onChange={(event) => setPassword(event.target.value)} />
                </div>
              </div>
              <Button className="w-full" type="submit" disabled={submitting || !username || !password}>
                {submitting ? t('登录中...', 'Signing in...') : t('登录系统', 'Sign In')}
              </Button>
            </form>

            <div className="mt-5 rounded border border-zinc-800 bg-zinc-950 px-3 py-2 text-[11px] leading-5 text-zinc-500">
              {t('支持通过服务器 IP:端口访问，也支持域名 / Cloudflare 代理访问。生产环境建议启用 HTTPS 并限制源站访问。', 'Supports server IP:port access as well as domain / Cloudflare proxy access. HTTPS and origin restrictions are recommended in production.')}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function LoginFeature({ icon, title, text }: { icon: ReactNode; title: string; text: string }) {
  return (
    <div className="flex gap-3 rounded-md border border-zinc-800 bg-zinc-900/70 p-4">
      <div className="mt-0.5 text-emerald-400">{icon}</div>
      <div>
        <div className="text-sm font-semibold text-zinc-100">{title}</div>
        <div className="mt-1 text-xs leading-5 text-zinc-500">{text}</div>
      </div>
    </div>
  );
}

function FullScreenMessage({ text }: { text: string }) {
  return <div className="flex h-screen items-center justify-center bg-zinc-950 text-xs text-zinc-500">{text}</div>;
}
