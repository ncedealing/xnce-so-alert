'use strict';

const net = require('node:net');
const fs = require('node:fs/promises');
const path = require('node:path');
const { mergeRedactedSecrets, resolveSecret } = require('./secrets');
const { testMt5WebApiConnection } = require('../providers/mt5WebApiProvider');

function testTcpConnection(server = {}) {
  const host = String(server.host || '').trim();
  const port = Number(server.port);
  const login = server.login;
  const timeoutMs = Math.max(1000, Number(server.timeoutMs || 5000));
  const checkedAt = new Date().toISOString();

  if (!host || !Number.isFinite(port) || port <= 0) {
    return Promise.resolve({
      status: 'disconnected',
      ok: false,
      host,
      port: Number.isFinite(port) ? port : 0,
      login,
      checkedAt,
      latencyMs: 0,
      error: 'MT5 server host or port is missing'
    });
  }

  return new Promise((resolve) => {
    const started = Date.now();
    const socket = net.createConnection({ host, port });
    let settled = false;

    const finish = (payload) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      resolve({
        host,
        port,
        login,
        checkedAt,
        latencyMs: Date.now() - started,
        ...payload
      });
    };

    socket.setTimeout(timeoutMs);
    socket.once('connect', () => {
      finish({ status: 'connected', ok: true, error: null });
    });
    socket.once('timeout', () => {
      finish({ status: 'disconnected', ok: false, error: `Connection timeout after ${timeoutMs}ms` });
    });
    socket.once('error', (error) => {
      const message =
        error.code === 'EPERM'
          ? `Local runtime blocked outbound TCP socket: ${error.message}`
          : error.message;
      finish({ status: 'disconnected', ok: false, error: message });
    });
  });
}

async function diagnoseMt5Connection(config, serverOverride = {}) {
  const deepAuth = serverOverride.deepAuth === true || serverOverride.mode === 'deep';
  const configuredServer = (((config.mt5 || {}).servers && config.mt5.servers[0]) || {});
  const server = mergeRedactedSecrets(
    {
      ...configuredServer,
      ...(serverOverride || {})
    },
    configuredServer
  );
  const checks = [];
  const tcp = await testTcpConnection(connectionTestServer(server, { authTimeoutMs: serverOverride.tcpTimeoutMs || 3000 }));
  checks.push({
    key: 'tcp',
    status: tcp.ok ? 'ok' : 'error',
    message: tcp.ok
      ? `TCP port reachable: ${tcp.host}:${tcp.port} (${tcp.latencyMs}ms)`
      : `TCP connection failed: ${tcp.error || 'unknown error'}`
  });

  const providerType = serverOverride.providerType || (config.provider && config.provider.type);
  checks.push({
    key: 'provider',
    status: providerType === 'managerApi' || providerType === 'mt5WebApi' ? 'ok' : 'warning',
    message: providerMessage(providerType)
  });

  const secret = resolveSecret(server, 'password', 'passwordEnv');
  checks.push({
    key: 'password',
    status: secret.value ? 'ok' : 'error',
    message: formatPasswordCheckMessage(secret)
  });

  if (providerType === 'mt5WebApi') {
    if (!deepAuth) {
      checks.push({
        key: 'webApiAuth',
        status: 'warning',
        message: '快速测试只验证 MT5 TCP 端口和密码配置；如需确认 Web API 登录权限，请点击“登录验证”。'
      });
    } else if (tcp.ok && secret.value) {
      try {
        const webApi = await testMt5WebApiConnection(config, connectionTestServer(server, serverOverride));
        checks.push({
          key: 'webApiAuth',
          status: 'ok',
          message: `MT5 Web API login succeeded (${webApi.latencyMs}ms), server time ${webApi.serverTime}`
        });
      } catch (error) {
        const configuredCrypt = webApiCrypt(config);
        let message = webApiLoginFailureMessage(error, configuredCrypt);
        const alternateCrypt = alternateWebApiCrypt(configuredCrypt);
        if (serverOverride.tryAlternateCrypt === true && shouldTryAlternateWebApiCrypt(error) && alternateCrypt) {
          try {
            const altWebApi = await testMt5WebApiConnection(
              configWithWebApiCrypt(config, alternateCrypt),
              connectionTestServer(server, serverOverride)
            );
            message += `; alternate crypt=${alternateCrypt} login succeeded (${altWebApi.latencyMs}ms). Save Web API 加密模式 as ${alternateCrypt}.`;
          } catch (altError) {
            message += `; alternate crypt=${alternateCrypt} also failed: ${altError.message}`;
          }
        }
        checks.push({
          key: 'webApiAuth',
          status: 'error',
          message
        });
      }
    } else {
      checks.push({
        key: 'webApiAuth',
        status: 'warning',
        message: 'MT5 Web API login skipped until TCP and password checks pass'
      });
    }
    const blocking = checks.filter((check) => check.status === 'error');
    return {
      ...tcp,
      ok: tcp.ok && blocking.length === 0,
      status: tcp.ok && blocking.length === 0 ? 'connected' : 'disconnected',
      error: blocking.length ? blocking.map((check) => check.message).join('; ') : tcp.error,
      checks
    };
  }

  if (providerType !== 'managerApi') {
    const blocking = checks.filter((check) => check.status === 'error');
    return {
      ...tcp,
      ok: tcp.ok && blocking.length === 0,
      status: tcp.ok && blocking.length === 0 ? 'connected' : 'disconnected',
      error: blocking.length ? blocking.map((check) => check.message).join('; ') : tcp.error,
      checks
    };
  }

  const adapter = (config.provider && config.provider.managerApi) || {};
  const command = adapter.command
    ? resolveFromConfig(config, adapter.command)
    : '';
  if (command) {
    const exists = await fileExists(command);
    checks.push({
      key: 'adapterCommand',
      status: exists ? 'ok' : 'error',
      message: exists ? `Manager API adapter exists: ${command}` : `Manager API adapter is not built or not found: ${command}`
    });
  } else {
    checks.push({
      key: 'adapterCommand',
      status: 'error',
      message: 'provider.managerApi.command is missing'
    });
  }

  if (process.platform !== 'win32') {
    checks.push({
      key: 'platform',
      status: 'warning',
      message: `Current platform is ${process.platform}/${process.arch}; MT5 Manager API DLL adapter must run on Windows`
    });
  } else {
    checks.push({
      key: 'platform',
      status: 'ok',
      message: 'Current platform is Windows'
    });
  }

  const blocking = checks.filter((check) => check.status === 'error');
  return {
    ...tcp,
    ok: tcp.ok && blocking.length === 0,
    status: tcp.ok && blocking.length === 0 ? 'connected' : 'disconnected',
    error: blocking.length ? blocking.map((check) => check.message).join('; ') : tcp.error,
    checks
  };
}

function resolveFromConfig(config, filePath) {
  if (path.isAbsolute(filePath)) return filePath;
  return path.resolve(config.__cwd || process.cwd(), filePath);
}

function connectionTestServer(server, serverOverride = {}) {
  const configured = Number(server.timeoutMs || 0);
  const requested = Number(serverOverride.authTimeoutMs || 4000);
  const timeoutMs = Math.max(1000, Math.min(configured > 0 ? configured : requested, requested));
  return { ...server, timeoutMs };
}

async function fileExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

module.exports = {
  testTcpConnection,
  diagnoseMt5Connection,
  webApiLoginFailureMessage,
  shouldTryAlternateWebApiCrypt
};

function providerMessage(providerType) {
  if (providerType === 'managerApi') return 'provider.type is managerApi (Windows DLL adapter)';
  if (providerType === 'mt5WebApi') return 'provider.type is mt5WebApi (Mac/Linux direct TCP Web API)';
  if (providerType === 'mock') return 'provider.type is mock; monitoring is using demo data until you switch to mt5WebApi or managerApi';
  return `provider.type is ${providerType || 'missing'}; use mt5WebApi on Mac/Linux or managerApi on Windows`;
}

function formatPasswordCheckMessage(secret) {
  if (secret.source === 'env') return `${secret.envName} is set`;
  if (secret.source === 'direct') return 'Manager password is configured as a saved secret';
  if (secret.source === 'legacyEnvField') {
    return 'Manager password is configured as a saved secret';
  }
  const envName = secret.envName || 'MT5_MANAGER_PASSWORD';
  return `Manager password is missing; enter a saved password or set ${envName}`;
}

function webApiCrypt(config) {
  const provider = (config && config.provider && config.provider.mt5WebApi) || {};
  return provider.crypt || 'aes';
}

function alternateWebApiCrypt(crypt) {
  if (crypt === 'aes') return 'none';
  if (crypt === 'none') return 'aes';
  return '';
}

function configWithWebApiCrypt(config, crypt) {
  return {
    ...config,
    provider: {
      ...(config.provider || {}),
      mt5WebApi: {
        ...((config.provider && config.provider.mt5WebApi) || {}),
        crypt
      }
    }
  };
}

function shouldTryAlternateWebApiCrypt(error) {
  const message = String((error && error.message) || '');
  return /ECONNRESET|Socket closed|Invalid packet header|AUTH_START|AUTH_ANSWER|CRYPT_RAND/i.test(message);
}

function webApiLoginFailureMessage(error, crypt = 'aes') {
  const message = String((error && error.message) || error || 'unknown error');
  const prefix = `MT5 Web API login failed with crypt=${crypt}: ${message}`;
  if (/ECONNRESET|Socket closed/i.test(message)) {
    return `${prefix}. TCP is reachable, but the server reset the Web API handshake. Confirm this port is the MT5 Web API endpoint, not only the Windows Manager API/DLL port; also check Web API Manager access, IP whitelist, and encryption mode.`;
  }
  if (/Invalid packet header/i.test(message)) {
    return `${prefix}. The endpoint returned data that does not look like MT5 Web API protocol; confirm the Web API port and encryption mode.`;
  }
  if (/AUTH_START|AUTH_ANSWER|CRYPT_RAND/i.test(message)) {
    return `${prefix}. Check Manager login/password, Manager permissions, Web API access, and encryption mode.`;
  }
  return prefix;
}
