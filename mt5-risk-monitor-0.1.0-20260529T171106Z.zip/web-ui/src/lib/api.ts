import type {
  AppConfig,
  AuthStatus,
  AuthUser,
  ConfigSaveResponse,
  Mt5ConnectionStatus,
  RiskResult,
  SnapshotSymbol,
  SystemStatus,
  SystemUpdateStatus,
  TelegramChat,
} from '@/types/api';

const API_BASE = '';
const DEFAULT_REQUEST_TIMEOUT_MS = 15000;

type ApiRequestInit = RequestInit & {
  timeoutMs?: number;
};

function getAuthHeaders(): HeadersInit {
  return {};
}

async function request<T>(path: string, init?: ApiRequestInit): Promise<T> {
  const { timeoutMs = DEFAULT_REQUEST_TIMEOUT_MS, ...fetchInit } = init || {};
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  let res: Response;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      ...fetchInit,
      signal: controller.signal,
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeaders(),
        ...fetchInit.headers,
      },
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') {
      throw new Error(`请求超时：${path} 超过 ${Math.round(timeoutMs / 1000)} 秒没有响应`);
    }
    throw error;
  } finally {
    window.clearTimeout(timer);
  }
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    if (body.error === 'Unknown API route') {
      throw new Error('后端 API 版本过旧或服务未重启：当前页面请求的接口不存在，请停止旧进程后重新运行 mac_local_demo.py。');
    }
    if (res.status === 401) {
      throw new Error(body.error || '未登录或登录已过期');
    }
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  return res.json() as Promise<T>;
}

function eventSourceUrl(path = '/api/events') {
  return `${API_BASE}${path}`;
}

async function uploadRequest<T>(path: string, formData: FormData, timeoutMs = 120000): Promise<T> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  let res: Response;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      method: 'POST',
      body: formData,
      signal: controller.signal,
      credentials: 'same-origin',
      headers: {
        ...getAuthHeaders(),
      },
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') {
      throw new Error(`上传超时：${path} 超过 ${Math.round(timeoutMs / 1000)} 秒没有响应`);
    }
    throw error;
  } finally {
    window.clearTimeout(timer);
  }
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export const api = {
  authStatus: () => request<AuthStatus>('/api/auth/status'),
  login: (username: string, password: string) =>
    request<AuthStatus & { ok: boolean }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    }),
  logout: () => request<{ ok: boolean }>('/api/auth/logout', { method: 'POST' }),
  getAuthUsers: () => request<{ users: AuthUser[] }>('/api/auth/users'),
  addAuthUser: (username: string, password: string) =>
    request<{ ok: boolean; users: AuthUser[] }>('/api/auth/users', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    }),
  resetAuthUserPassword: (username: string, newPassword: string) =>
    request<{ ok: boolean; users: AuthUser[] }>(`/api/auth/users/${encodeURIComponent(username)}?action=reset-password`, {
      method: 'POST',
      body: JSON.stringify({ newPassword }),
    }),
  deleteAuthUser: (username: string) =>
    request<{ ok: boolean; users: AuthUser[] }>(`/api/auth/users/${encodeURIComponent(username)}`, {
      method: 'DELETE',
    }),
  changePassword: (currentPassword: string, newPassword: string) =>
    request<{ ok: boolean }>('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword, newPassword }),
    }),
  getStatus: () => request<SystemStatus>('/api/status'),
  getConfig: () => request<AppConfig>('/api/config'),
  getSystemUpdateStatus: () => request<SystemUpdateStatus>('/api/system/update/status'),
  uploadSystemUpdate: (file: File, apply = false) => {
    const formData = new FormData();
    formData.append('package', file, file.name);
    return uploadRequest<{ ok: boolean; package: SystemUpdateStatus['latest']; applied: SystemUpdateStatus['latest'] | null }>(
      `/api/system/update/upload${apply ? '?apply=1' : ''}`,
      formData,
    );
  },
  applySystemUpdate: () => request<{ ok: boolean; applied: SystemUpdateStatus['latest'] }>('/api/system/update/apply', { method: 'POST', timeoutMs: 120000 }),
  getEmailTemplate: () => request<{ html: string }>('/api/email-template'),
  sendTestEmail: () =>
    request<{ ok: boolean; subject: string; to: string[]; transport: string; generatedAt: string }>('/api/email/test', {
      method: 'POST',
      timeoutMs: 20000,
    }),
  sendTestTelegram: () =>
    request<{ ok: boolean; chatIds: string[]; generatedAt: string }>('/api/telegram/test', {
      method: 'POST',
      timeoutMs: 20000,
    }),
  getTelegramUpdates: () =>
    request<{ ok: boolean; chats: TelegramChat[]; updateCount: number }>('/api/telegram/updates', {
      method: 'POST',
      timeoutMs: 20000,
    }),
  saveConfig: (config: AppConfig) =>
    request<ConfigSaveResponse>('/api/config', {
      method: 'PUT',
      body: JSON.stringify(config),
    }),
  checkNow: () =>
    request<RiskResult>('/api/check', { method: 'POST', timeoutMs: 20000 }),
  testMt5Connection: (server: unknown) =>
    request<Mt5ConnectionStatus>('/api/mt5/test-connection', {
      method: 'POST',
      body: JSON.stringify({ server }),
      timeoutMs: 7000,
    }),
  startMonitor: () =>
    request<SystemStatus>('/api/monitor/start', { method: 'POST' }),
  stopMonitor: () =>
    request<SystemStatus>('/api/monitor/stop', { method: 'POST' }),
  getRisk: () => request<RiskResult | null>('/api/risk'),
  getSymbols: () => request<{ symbols: SnapshotSymbol[] }>('/api/symbols', { timeoutMs: 20000 }),
  eventSourceUrl,
};

export function flattenRiskRows(result: RiskResult | null) {
  if (!result) return [];
  const rows = [];
  for (const report of result.reports) {
    for (const risk of report.symbolRisks) {
      rows.push({
        id: `${report.account.login}:${risk.symbol}:${risk.direction}`,
        login: report.account.login,
        group: report.account.group,
        equity: report.equity,
        margin: report.margin,
        marginLevel: report.marginLevel,
        stopOutLevel: report.stopOutLevel,
        symbol: risk.symbol,
        direction: risk.direction,
        bid: risk.quote.bid,
        ask: risk.quote.ask,
        liquidationPrice: risk.liquidationPrice,
        distancePoints: risk.distancePoints,
        alertDistancePoints: risk.alertDistancePoints,
        shouldAlert: risk.shouldAlert,
      });
    }
  }
  return rows;
}
