'use strict';

const DEFAULT_SERVER_OFFSET_MINUTES = 180;
const DEFAULT_SERVER_TIME_ZONE = 'GMT+3';
const SERVER_TIME_ZONES = {
  'GMT+2': 120,
  'GMT+3': 180
};

function normalizeServerTimeZone(value, fallbackOffsetMinutes = DEFAULT_SERVER_OFFSET_MINUTES) {
  const text = String(value || '').trim().toUpperCase().replace('UTC', 'GMT');
  if (text === 'GMT+2' || text === '+2' || text === '+02' || text === '+02:00') return 'GMT+2';
  if (text === 'GMT+3' || text === '+3' || text === '+03' || text === '+03:00') return 'GMT+3';
  const offset = Number(fallbackOffsetMinutes);
  return offset === 120 ? 'GMT+2' : DEFAULT_SERVER_TIME_ZONE;
}

function offsetMinutesFromServerTimeZone(value, fallbackOffsetMinutes = DEFAULT_SERVER_OFFSET_MINUTES) {
  const zone = normalizeServerTimeZone(value, fallbackOffsetMinutes);
  return SERVER_TIME_ZONES[zone] || DEFAULT_SERVER_OFFSET_MINUTES;
}

function normalizeServerTime(value, offsetOrZone = DEFAULT_SERVER_TIME_ZONE) {
  if (value === null || value === undefined || value === '') return null;
  const offset =
    typeof offsetOrZone === 'string'
      ? offsetMinutesFromServerTimeZone(offsetOrZone)
      : Number.isFinite(Number(offsetOrZone))
        ? Number(offsetOrZone)
        : DEFAULT_SERVER_OFFSET_MINUTES;

  if (typeof value === 'number' && Number.isFinite(value)) {
    const timestamp = value < 10_000_000_000 ? value * 1000 : value;
    return new Date(timestamp).toISOString();
  }

  const text = String(value).trim();
  if (!text) return null;

  if (/^\d{10,13}$/.test(text)) {
    const numeric = Number(text);
    const timestamp = text.length === 10 ? numeric * 1000 : numeric;
    return new Date(timestamp).toISOString();
  }

  const withSeparator = text.replace(' ', 'T');
  const hasZone = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(withSeparator);
  const parsed = Date.parse(hasZone ? withSeparator : withDefaultOffset(withSeparator, offset));
  if (!Number.isFinite(parsed)) return null;
  return new Date(parsed).toISOString();
}

function withDefaultOffset(value, offsetMinutes) {
  const sign = offsetMinutes >= 0 ? '+' : '-';
  const absolute = Math.abs(offsetMinutes);
  const hours = String(Math.floor(absolute / 60)).padStart(2, '0');
  const minutes = String(absolute % 60).padStart(2, '0');
  return `${value}${sign}${hours}:${minutes}`;
}

module.exports = {
  DEFAULT_SERVER_OFFSET_MINUTES,
  DEFAULT_SERVER_TIME_ZONE,
  offsetMinutesFromServerTimeZone,
  normalizeServerTimeZone,
  normalizeServerTime
};
