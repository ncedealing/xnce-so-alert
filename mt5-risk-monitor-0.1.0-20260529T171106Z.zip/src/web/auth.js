'use strict';

const crypto = require('node:crypto');

const PASSWORD_HASH_PREFIX = 'scrypt';
const SCRYPT_OPTIONS = { N: 16384, r: 8, p: 1, keylen: 32 };

function authConfig(config = {}) {
  return (config.web && config.web.auth) || {};
}

function authEnabled(config = {}) {
  const auth = authConfig(config);
  return Boolean(auth.enabled && Array.isArray(auth.users) && auth.users.length > 0);
}

function publicAuthStatus(req, config, sessions) {
  const session = currentSession(req, config, sessions);
  return {
    enabled: authEnabled(config),
    authenticated: Boolean(session),
    user: session ? { username: session.username, role: session.role || 'admin' } : null
  };
}

function validateUsername(username) {
  return /^[A-Za-z][A-Za-z0-9_-]{7,31}$/.test(String(username || ''));
}

function validatePassword(password) {
  const text = String(password || '');
  return (
    text.length >= 12 &&
    /[a-z]/.test(text) &&
    /[A-Z]/.test(text) &&
    /\d/.test(text) &&
    /[^A-Za-z0-9]/.test(text)
  );
}

function passwordPolicyText() {
  return '密码至少 12 位，并包含大写字母、小写字母、数字和符号';
}

function userByUsername(config, username) {
  const users = authConfig(config).users || [];
  return users.find((user) => user.username === username);
}

async function hashPassword(password, salt = crypto.randomBytes(16).toString('base64')) {
  const derived = await scrypt(password, salt);
  return `${PASSWORD_HASH_PREFIX}:${SCRYPT_OPTIONS.N}:${SCRYPT_OPTIONS.r}:${SCRYPT_OPTIONS.p}:${salt}:${derived.toString('base64')}`;
}

async function verifyPassword(password, encoded) {
  const parts = String(encoded || '').split(':');
  if (parts.length !== 6 || parts[0] !== PASSWORD_HASH_PREFIX) return false;
  const [, rawN, rawR, rawP, salt, expected] = parts;
  const options = {
    N: Number(rawN),
    r: Number(rawR),
    p: Number(rawP),
    keylen: Buffer.from(expected, 'base64').length
  };
  if (!Number.isFinite(options.N) || !Number.isFinite(options.r) || !Number.isFinite(options.p) || options.keylen <= 0) {
    return false;
  }
  const actual = await scrypt(password, salt, options);
  const expectedBuffer = Buffer.from(expected, 'base64');
  if (sameBuffer(actual, expectedBuffer)) return true;

  const legacySalt = Buffer.from(salt, 'base64');
  if (legacySalt.length > 0 && legacySalt.toString('base64') === salt) {
    const legacyActual = await scrypt(password, legacySalt, options);
    if (sameBuffer(legacyActual, expectedBuffer)) return true;
  }
  return false;
}

function scrypt(password, salt, options = SCRYPT_OPTIONS) {
  return new Promise((resolve, reject) => {
    crypto.scrypt(String(password), salt, options.keylen, options, (error, derivedKey) => {
      if (error) reject(error);
      else resolve(derivedKey);
    });
  });
}

function sameBuffer(actual, expected) {
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

function createSession(req, res, config, sessions, user) {
  const auth = authConfig(config);
  const token = crypto.randomBytes(32).toString('base64url');
  const ttlMs = Math.max(1, Number(auth.sessionTtlHours || 12)) * 60 * 60 * 1000;
  const expiresAt = Date.now() + ttlMs;
  sessions.set(token, {
    username: user.username,
    role: user.role || 'admin',
    expiresAt
  });
  setCookie(res, cookieName(config), token, {
    maxAgeSeconds: Math.floor(ttlMs / 1000),
    secure: shouldUseSecureCookie(req, auth)
  });
  return token;
}

function destroySession(req, res, config, sessions) {
  const token = sessionToken(req, config);
  if (token) sessions.delete(token);
  setCookie(res, cookieName(config), '', {
    maxAgeSeconds: 0,
    secure: shouldUseSecureCookie(req, authConfig(config))
  });
}

function currentSession(req, config, sessions) {
  if (!authEnabled(config)) return { username: 'local', role: 'admin', local: true };
  const token = sessionToken(req, config);
  if (!token) return null;
  const session = sessions.get(token);
  if (!session) return null;
  if (session.expiresAt <= Date.now()) {
    sessions.delete(token);
    return null;
  }
  return session;
}

function sessionToken(req, config) {
  const cookies = parseCookies(req.headers.cookie || '');
  return cookies[cookieName(config)] || '';
}

function cookieName(config) {
  return authConfig(config).cookieName || 'mt5_risk_session';
}

function parseCookies(header) {
  const cookies = {};
  for (const item of String(header || '').split(';')) {
    const index = item.indexOf('=');
    if (index <= 0) continue;
    const key = item.slice(0, index).trim();
    const value = item.slice(index + 1).trim();
    if (key) cookies[key] = decodeURIComponent(value);
  }
  return cookies;
}

function shouldUseSecureCookie(req, auth = {}) {
  if (auth.secureCookie === true) return true;
  if (auth.secureCookie === false) return false;
  const proto = String(req.headers['x-forwarded-proto'] || '').toLowerCase();
  if (proto.split(',').map((item) => item.trim()).includes('https')) return true;
  return Boolean(req.socket && req.socket.encrypted);
}

function setCookie(res, name, value, { maxAgeSeconds, secure = false }) {
  const parts = [
    `${name}=${encodeURIComponent(value)}`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    `Max-Age=${Math.max(0, Number(maxAgeSeconds) || 0)}`
  ];
  if (secure) parts.push('Secure');
  res.setHeader('Set-Cookie', parts.join('; '));
}

function listPublicUsers(config) {
  return (authConfig(config).users || []).map((user) => ({
    username: user.username,
    role: user.role || 'admin',
    createdAt: user.createdAt || null,
    updatedAt: user.updatedAt || null
  }));
}

module.exports = {
  authEnabled,
  createSession,
  currentSession,
  destroySession,
  hashPassword,
  listPublicUsers,
  passwordPolicyText,
  publicAuthStatus,
  userByUsername,
  validatePassword,
  validateUsername,
  verifyPassword
};
