import { useEffect, useState, type ReactNode } from 'react';
import {
  Activity,
  Clock3,
  Languages,
  LayoutDashboard,
  Server,
  Settings,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { useI18n } from '@/i18n';
import { cn } from '@/lib/utils';
import type { SystemStatus } from '@/types/api';

type View = 'dashboard' | 'configuration';

interface TopBarProps {
  view: View;
  status: SystemStatus | null;
  streamConnected: boolean;
  onToggleMonitor: () => void;
  onViewChange: (view: View) => void;
}

export function TopBar({
  view,
  status,
  streamConnected,
  onToggleMonitor,
  onViewChange,
}: TopBarProps) {
  const { language, toggleLanguage, t } = useI18n();
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const running = status?.running ?? false;
  const connection = status?.mt5Connection;
  const serverTimeStale = isServerTimeStale(status, now);
  const mt5Error =
    serverTimeStale || connection?.status === 'disconnected'
      ? connection?.error || status?.lastError || null
      : connection?.error || null;
  const serverTime = formatServerClock(
    status?.serverTime,
    status?.serverTimeUpdatedAt,
    status?.serverTimeOffsetMinutes,
    now,
    serverTimeStale,
  );

  return (
    <header className="flex h-14 shrink-0 items-center justify-between border-b border-zinc-800 bg-zinc-950 px-6 shadow-sm">
      <div className="flex min-w-0 items-center gap-8">
        <button
          type="button"
          className="flex items-center gap-2"
          onClick={() => onViewChange('dashboard')}
        >
          <div className="h-2 w-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)]" />
          <div className="whitespace-nowrap text-left">
            <span className="font-bold tracking-wide text-zinc-100">MT5 Risk Monitor</span>
            <span className="ml-1 text-sm font-normal text-zinc-500">PRO</span>
          </div>
        </button>

        <nav className="hidden items-center gap-1 rounded-md border border-zinc-800 bg-zinc-900 p-1 md:flex">
          <NavButton
            active={view === 'dashboard'}
            onClick={() => onViewChange('dashboard')}
            icon={<LayoutDashboard className="h-4 w-4" />}
          >
            {t('总览', 'Overview')}
          </NavButton>
          <NavButton
            active={view === 'configuration'}
            onClick={() => onViewChange('configuration')}
            icon={<Settings className="h-4 w-4" />}
          >
            {t('配置', 'Configuration')}
          </NavButton>
        </nav>
      </div>

      <div className="hidden items-center gap-4 text-sm lg:flex">
        <div className="group relative">
          <div
            className={cn(
              'flex items-center gap-2 rounded-md border px-2 py-1 text-[11px]',
              serverTimeStale
                ? 'border-red-900/60 bg-red-950/20 text-red-400'
                : connection?.status === 'connected'
                ? 'border-emerald-900/60 bg-emerald-950/20 text-emerald-400'
                : connection?.status === 'testing'
                  ? 'border-amber-900/60 bg-amber-950/20 text-amber-400'
                  : 'border-zinc-800 bg-zinc-900 text-zinc-500',
            )}
          >
            <Server className="h-3 w-3" />
            <span>
              {serverTimeStale
                ? t('MT5断联', 'MT5 Offline')
                : connection?.status === 'connected'
                ? t('MT5连接', 'MT5 Connected')
                : connection?.status === 'testing'
                  ? t('MT5连接中', 'MT5 Connecting')
                  : t('MT5未连接', 'MT5 Not Connected')}
            </span>
          </div>
          {mt5Error && (
            <div className="pointer-events-none absolute left-1/2 top-full z-50 mt-2 hidden w-[min(720px,80vw)] -translate-x-1/2 rounded-md border border-red-900/60 bg-zinc-950 p-3 text-left font-mono text-[11px] leading-relaxed text-red-200 shadow-2xl shadow-black/40 group-hover:block">
              <div className="mb-1 font-sans text-xs font-semibold text-red-400">{t('MT5连接错误详情', 'MT5 Connection Error')}</div>
              <pre className="max-h-64 overflow-auto whitespace-pre-wrap break-words">{mt5Error}</pre>
            </div>
          )}
        </div>
        <div
          className={cn(
            'flex items-center gap-2 text-zinc-400',
            running
              ? 'text-emerald-400'
              : 'text-zinc-500',
          )}
        >
          <span className="relative mr-1 flex h-2.5 w-2.5">
            {running && (
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
            )}
            <span
              className={cn(
                'relative inline-flex h-2.5 w-2.5 rounded-full',
                running ? 'bg-emerald-500' : 'bg-zinc-600',
              )}
            />
          </span>
          <Activity className="h-3 w-3" />
          <span>
            {running
              ? `${streamConnected ? t('实时推送', 'Live Stream') : t('监控中', 'Monitoring')} (${status?.pollIntervalSeconds ?? '—'}s)`
              : t('已停止', 'Stopped')}
          </span>
        </div>
        <time
          className={cn(
            'flex items-center gap-1 text-[11px] font-mono tabular-nums',
            serverTimeStale ? 'text-red-400' : status?.serverTime ? 'text-zinc-400' : 'text-zinc-500',
          )}
          title={serverTimeStale ? t('服务器时间未按轮询更新，视为断联', 'Server time did not update within the expected interval, treated as disconnected') : undefined}
        >
          <Clock3 className="h-3 w-3" />
          <span>{serverTime || t('服务器时间未读取', 'Server time unavailable')}</span>
        </time>
      </div>

      <div className="flex items-center gap-1.5">
        <div className="flex items-center gap-1.5 rounded-md border border-zinc-800 px-2 py-1">
          <Switch checked={running} onCheckedChange={() => onToggleMonitor()} />
          <span className="text-[10px] text-zinc-400 hidden sm:inline">
            {running ? t('运行中', 'Running') : t('已停止', 'Stopped')}
          </span>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={toggleLanguage}
          title={t('切换语言', 'Switch language')}
        >
          <Languages className="h-3.5 w-3.5" />
          {language === 'zh' ? 'EN' : '中文'}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => onViewChange(view === 'configuration' ? 'dashboard' : 'configuration')}
          title={view === 'configuration' ? t('收起配置', 'Collapse configuration') : t('展开配置', 'Open configuration')}
        >
          <Settings className="h-4 w-4" />
        </Button>
      </div>
    </header>
  );
}

function NavButton({
  active,
  onClick,
  icon,
  children,
}: {
  active: boolean;
  onClick: () => void;
  icon: ReactNode;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex items-center gap-2 rounded px-3 py-1.5 text-sm font-medium transition-colors',
        active ? 'bg-zinc-800 text-white shadow-sm' : 'text-zinc-400 hover:text-zinc-200',
      )}
    >
      {icon}
      {children}
    </button>
  );
}

function isServerTimeStale(status: SystemStatus | null, now: Date) {
  if (status?.serverTimeStale) return true;
  if (!status?.running) return false;
  const lastFreshAt = status.serverTimeUpdatedAt || status.lastCheckedAt || status.monitorStartedAt;
  if (!lastFreshAt) return false;
  const updated = new Date(lastFreshAt).getTime();
  if (!Number.isFinite(updated)) return false;
  const intervalMs = Math.max(100, Number(status.pollIntervalSeconds || 1) * 1000);
  const multiplier = Number(status.mt5DisconnectAfterPollMultiples || 5);
  const staleAfterMs = Number(status.serverTimeStaleThresholdMs) || intervalMs * (Number.isFinite(multiplier) && multiplier > 0 ? multiplier : 5);
  return now.getTime() - updated > staleAfterMs;
}

function formatServerClock(
  serverTime?: string | null,
  updatedAt?: string | null,
  offsetMinutes = 180,
  now = new Date(),
  stale = false,
) {
  if (!serverTime) return '';
  const base = new Date(serverTime).getTime();
  if (!Number.isFinite(base)) return '';
  const offset = Number.isFinite(Number(offsetMinutes)) ? Number(offsetMinutes) : 180;
  const updated = updatedAt ? new Date(updatedAt).getTime() : NaN;
  const drift = stale ? 0 : Number.isFinite(updated) ? now.getTime() - updated : 0;
  const current = new Date(base + Math.max(0, drift) + offset * 60_000);
  const text = current.toLocaleString('zh-CN', {
    timeZone: 'UTC',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }) + ` ${formatGmtOffset(offset)}`;
  return stale ? `${text} 断联` : text;
}

function formatGmtOffset(offsetMinutes: number) {
  const sign = offsetMinutes >= 0 ? '+' : '-';
  const absolute = Math.abs(offsetMinutes);
  const hours = String(Math.floor(absolute / 60)).padStart(2, '0');
  const minutes = String(absolute % 60).padStart(2, '0');
  return minutes === '00' ? `GMT${sign}${Number(hours)}` : `GMT${sign}${hours}:${minutes}`;
}
