import { useEffect, useState, type ReactNode } from 'react';
import { KeyRound, Plus, ShieldCheck, Trash2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/hooks/use-toast';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import type { AuthUser } from '@/types/api';

export function SecurityTab() {
  const { t } = useI18n();
  const [users, setUsers] = useState<AuthUser[]>([]);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newPasswordAgain, setNewPasswordAgain] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [currentUsername, setCurrentUsername] = useState('');
  const [resetUsername, setResetUsername] = useState('');
  const [resetPassword, setResetPassword] = useState('');
  const [resetPasswordAgain, setResetPasswordAgain] = useState('');
  const [busy, setBusy] = useState(false);

  const refreshUsers = async () => {
    const [result, status] = await Promise.all([api.getAuthUsers(), api.authStatus()]);
    setUsers(result.users || []);
    setCurrentUsername(status.user?.username || '');
  };

  useEffect(() => {
    refreshUsers().catch(() => {});
  }, []);

  const changePassword = async () => {
    if (newPassword !== newPasswordAgain) {
      toast({ title: t('密码不一致', 'Passwords do not match'), description: t('请确认两次输入的新密码相同。', 'Please make sure both new password entries are identical.'), variant: 'destructive' });
      return;
    }
    setBusy(true);
    try {
      await api.changePassword(currentPassword, newPassword);
      setCurrentPassword('');
      setNewPassword('');
      setNewPasswordAgain('');
      toast({ title: t('密码已更新', 'Password updated'), description: t('下次登录请使用新密码。', 'Use the new password the next time you sign in.') });
    } catch (error) {
      toast({ title: t('修改失败', 'Update failed'), description: error instanceof Error ? error.message : t('未知错误', 'Unknown error'), variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  const addAdmin = async () => {
    setBusy(true);
    try {
      const result = await api.addAuthUser(newUsername, adminPassword);
      setUsers(result.users || []);
      setNewUsername('');
      setAdminPassword('');
      toast({ title: t('管理员用户已添加', 'Admin user added'), description: t(`用户 ${newUsername} 可以登录后台。`, `User ${newUsername} can sign in to the console.`) });
    } catch (error) {
      toast({ title: t('添加失败', 'Add failed'), description: error instanceof Error ? error.message : t('未知错误', 'Unknown error'), variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  const resetOtherPassword = async () => {
    if (!resetUsername) return;
    if (resetPassword !== resetPasswordAgain) {
      toast({ title: t('密码不一致', 'Passwords do not match'), description: t('请确认两次输入的新密码相同。', 'Please make sure both new password entries are identical.'), variant: 'destructive' });
      return;
    }
    setBusy(true);
    try {
      const result = await api.resetAuthUserPassword(resetUsername, resetPassword);
      setUsers(result.users || []);
      setResetUsername('');
      setResetPassword('');
      setResetPasswordAgain('');
      toast({ title: t('密码已重置', 'Password reset'), description: t(`用户 ${resetUsername} 下次登录需要使用新密码。`, `User ${resetUsername} must use the new password next time.`) });
    } catch (error) {
      toast({ title: t('重置失败', 'Reset failed'), description: error instanceof Error ? error.message : t('未知错误', 'Unknown error'), variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  const deleteUser = async (username: string) => {
    if (!window.confirm(t(`确认删除用户 ${username}？`, `Delete user ${username}?`))) return;
    setBusy(true);
    try {
      const result = await api.deleteAuthUser(username);
      setUsers(result.users || []);
      if (resetUsername === username) {
        setResetUsername('');
        setResetPassword('');
        setResetPasswordAgain('');
      }
      toast({ title: t('用户已删除', 'User deleted'), description: t(`用户 ${username} 已不能登录后台。`, `User ${username} can no longer sign in.`) });
    } catch (error) {
      toast({ title: t('删除失败', 'Delete failed'), description: error instanceof Error ? error.message : t('未知错误', 'Unknown error'), variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-3 pb-16">
      <Card>
        <CardHeader>
          <CardTitle>{t('管理员用户', 'Admin Users')}</CardTitle>
          <CardDescription>{t('后台登录用户；用户名 8-32 位，以字母开头，只能包含字母、数字、下划线和中划线', 'Console login users. Usernames must be 8-32 characters, start with a letter, and contain only letters, numbers, underscores, and hyphens.')}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-hidden rounded-md border border-zinc-800">
            <table className="w-full text-left text-xs text-zinc-400">
              <thead className="bg-zinc-950 text-[10px] uppercase text-zinc-500">
                <tr>
                  <th className="px-3 py-2">{t('用户名', 'Username')}</th>
                  <th className="px-3 py-2">{t('角色', 'Role')}</th>
                  <th className="px-3 py-2">{t('创建时间', 'Created At')}</th>
                  <th className="px-3 py-2">{t('更新时间', 'Updated At')}</th>
                  <th className="px-3 py-2 text-right">{t('操作', 'Actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60">
                {users.length ? users.map((user) => {
                  const isCurrent = user.username === currentUsername;
                  const onlyUser = users.length <= 1;
                  return (
                    <tr key={user.username}>
                      <td className="px-3 py-2 font-mono text-zinc-200">
                        {user.username}
                        {isCurrent && <span className="ml-2 rounded border border-emerald-500/40 px-1.5 py-0.5 text-[10px] text-emerald-300">{t('当前用户', 'Current')}</span>}
                      </td>
                      <td className="px-3 py-2">{user.role}</td>
                      <td className="px-3 py-2 font-mono">{formatTime(user.createdAt)}</td>
                      <td className="px-3 py-2 font-mono">{formatTime(user.updatedAt)}</td>
                      <td className="px-3 py-2">
                        <div className="flex justify-end gap-2">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            disabled={busy || isCurrent}
                            onClick={() => {
                              setResetUsername(user.username);
                              setResetPassword('');
                              setResetPasswordAgain('');
                            }}
                            title={isCurrent ? t('当前用户请使用下方“修改密码”', 'Use Change Password for the current user') : t('重置密码', 'Reset Password')}
                          >
                            <KeyRound className="h-3.5 w-3.5" />
                            {t('重置密码', 'Reset')}
                          </Button>
                          <Button
                            type="button"
                            variant="destructive"
                            size="sm"
                            disabled={busy || isCurrent || onlyUser}
                            onClick={() => deleteUser(user.username)}
                            title={isCurrent ? t('不能删除当前登录用户', 'Cannot delete the current user') : onlyUser ? t('至少保留一个管理员', 'Keep at least one admin') : t('删除用户', 'Delete User')}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                            {t('删除', 'Delete')}
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                }) : (
                  <tr><td className="px-3 py-8 text-center text-zinc-500" colSpan={5}>{t('暂无后台用户', 'No admin users')}</td></tr>
                )}
              </tbody>
            </table>
          </div>
          {resetUsername && (
            <div className="mt-3 rounded-md border border-zinc-800 bg-zinc-950/80 p-3">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-zinc-100">{t('重置其他用户密码', 'Reset Another User Password')}</p>
                  <p className="mt-1 text-xs text-zinc-500">
                    {t('目标用户', 'Target user')}: <span className="font-mono text-zinc-300">{resetUsername}</span>
                  </p>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setResetUsername('');
                    setResetPassword('');
                    setResetPasswordAgain('');
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <PasswordPolicy />
              <div className="mt-3 grid gap-3 md:grid-cols-[1fr_1fr_auto]">
                <Field label={t('新密码', 'New Password')}><Input type="password" value={resetPassword} onChange={(event) => setResetPassword(event.target.value)} /></Field>
                <Field label={t('确认新密码', 'Confirm New Password')}><Input type="password" value={resetPasswordAgain} onChange={(event) => setResetPasswordAgain(event.target.value)} /></Field>
                <div className="flex items-end">
                  <Button onClick={resetOtherPassword} disabled={busy || !resetPassword || !resetPasswordAgain}>
                    <KeyRound className="h-3.5 w-3.5" />
                    {t('确认重置', 'Reset Password')}
                  </Button>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-3 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>{t('修改密码', 'Change Password')}</CardTitle>
            <CardDescription>{t('修改当前登录用户的密码', 'Change the password for the current login user')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <PasswordPolicy />
            <Field label={t('当前密码', 'Current Password')}><Input type="password" value={currentPassword} onChange={(event) => setCurrentPassword(event.target.value)} /></Field>
            <Field label={t('新密码', 'New Password')}><Input type="password" value={newPassword} onChange={(event) => setNewPassword(event.target.value)} /></Field>
            <Field label={t('确认新密码', 'Confirm New Password')}><Input type="password" value={newPasswordAgain} onChange={(event) => setNewPasswordAgain(event.target.value)} /></Field>
            <Button onClick={changePassword} disabled={busy || !currentPassword || !newPassword || !newPasswordAgain}>
              <ShieldCheck className="h-3.5 w-3.5" />
              {t('更新密码', 'Update Password')}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{t('添加管理员用户', 'Add Admin User')}</CardTitle>
            <CardDescription>{t('添加新的后台管理员账号', 'Add a new console administrator account')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <PasswordPolicy />
            <Field label={t('新用户名', 'New Username')}><Input value={newUsername} onChange={(event) => setNewUsername(event.target.value)} placeholder="admin_ops01" /></Field>
            <Field label={t('初始密码', 'Initial Password')}><Input type="password" value={adminPassword} onChange={(event) => setAdminPassword(event.target.value)} /></Field>
            <Button onClick={addAdmin} disabled={busy || !newUsername || !adminPassword}>
              <Plus className="h-3.5 w-3.5" />
              {t('添加管理员', 'Add Admin')}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function PasswordPolicy() {
  const { t } = useI18n();
  return (
    <div className="rounded-md border border-zinc-800 bg-zinc-950 px-3 py-2 text-[11px] leading-relaxed text-zinc-500">
      {t('密码至少 12 位，并包含大写字母、小写字母、数字和符号。', 'Password must be at least 12 characters and include uppercase letters, lowercase letters, numbers, and symbols.')}
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return <div className="space-y-1"><Label>{label}</Label>{children}</div>;
}

function formatTime(value?: string | null) {
  if (!value) return '—';
  return String(value).replace('T', ' ').replace(/\.\d{3}Z$/, ' UTC');
}
