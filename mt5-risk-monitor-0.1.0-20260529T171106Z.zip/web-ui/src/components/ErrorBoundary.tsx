import { Component, type ErrorInfo, type ReactNode } from 'react';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  error: Error | null;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = { error: null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('UI render failed', error, info);
  }

  render() {
    if (!this.state.error) return this.props.children;

    return (
      <div className="flex h-screen w-screen items-center justify-center bg-zinc-950 p-6 text-zinc-300">
        <div className="w-full max-w-xl rounded-md border border-red-900/50 bg-zinc-900 p-5 shadow-2xl">
          <p className="text-sm font-semibold text-red-400">页面渲染失败</p>
          <p className="mt-2 text-xs text-zinc-400">
            已阻止全屏黑屏。请刷新页面，或检查配置对象是否缺少新版本字段。
          </p>
          <pre className="mt-4 max-h-48 overflow-auto rounded bg-zinc-950 p-3 text-[11px] text-red-200">
            {this.state.error.message}
          </pre>
          <button
            type="button"
            className="mt-4 rounded-md bg-emerald-600 px-3 py-2 text-xs font-medium text-white hover:bg-emerald-500"
            onClick={() => this.setState({ error: null })}
          >
            返回页面
          </button>
        </div>
      </div>
    );
  }
}
