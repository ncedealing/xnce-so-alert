'use strict';

function toNumber(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function normalizeAction(action) {
  const value = String(action || '').toUpperCase();
  if (value === '0' || value === 'BUY' || value === 'POSITION_TYPE_BUY') return 'BUY';
  if (value === '1' || value === 'SELL' || value === 'POSITION_TYPE_SELL') return 'SELL';
  return value || 'BUY';
}

function pointFromSymbol(symbol) {
  if (toNumber(symbol && symbol.point) > 0) return toNumber(symbol.point);
  const digits = toNumber(symbol && symbol.digits, 5);
  return 10 ** -digits;
}

function marginRateForPosition(position, symbol) {
  const action = normalizeAction(position.action);
  if (action === 'BUY' && toNumber(symbol && symbol.marginLong) > 0) return toNumber(symbol.marginLong);
  if (action === 'SELL' && toNumber(symbol && symbol.marginShort) > 0) return toNumber(symbol.marginShort);
  if (toNumber(position.marginRate) > 0) return toNumber(position.marginRate);
  if (toNumber(symbol && symbol.marginRateInitial) > 0) return toNumber(symbol.marginRateInitial);
  return 1;
}

function marginPriceForPosition(position, quote) {
  const action = normalizeAction(position.action);
  if (!quote) return toNumber(position.openPrice);
  if (action === 'BUY') return toNumber(quote.ask, quote.bid);
  return toNumber(quote.bid, quote.ask);
}

function estimatePositionMargin(position, symbol, quote, account, riskConfig = {}) {
  if (riskConfig.treatReportedMarginAsFixed && toNumber(position.margin) > 0) {
    return toNumber(position.margin);
  }

  const volumeLots = Math.abs(toNumber(position.volumeLots ?? position.volume));
  if (volumeLots === 0) return 0;

  const rateToAccount = toNumber(
    position.marginCurrencyRateToAccount ??
      position.rateMargin ??
      (symbol && symbol.marginCurrencyRateToAccount),
    1
  );
  const marginRate = marginRateForPosition(position, symbol || {});

  if (toNumber(symbol && symbol.marginInitial) > 0) {
    return Math.max(
      riskConfig.minimumMargin || 0,
      volumeLots * toNumber(symbol.marginInitial) * marginRate * rateToAccount
    );
  }

  const leverage = Math.max(
    1,
    toNumber(position.leverage ?? (account && account.leverage) ?? (symbol && symbol.leverage), 1)
  );
  const contractSize = toNumber(position.contractSize ?? (symbol && symbol.contractSize), 100000);
  const price = Math.max(0, marginPriceForPosition(position, quote));
  const margin = (volumeLots * contractSize * price * marginRate * rateToAccount) / leverage;
  return Math.max(riskConfig.minimumMargin || 0, margin);
}

function exitPriceForPosition(position, quote) {
  const action = normalizeAction(position.action);
  if (!quote) return toNumber(position.currentPrice, toNumber(position.openPrice));
  return action === 'BUY' ? toNumber(quote.bid, quote.ask) : toNumber(quote.ask, quote.bid);
}

function exitPriceSideForPosition(position, quote) {
  if (!quote) return position.currentPrice !== undefined ? 'MT5' : 'OPEN';
  return normalizeAction(position.action) === 'BUY' ? 'BID' : 'ASK';
}

function displayClosePriceForPosition(position, quote) {
  const current = toNumber(position.currentPrice, NaN);
  if (Number.isFinite(current) && current > 0) return current;
  return exitPriceForPosition(position, quote);
}

function displayClosePriceSideForPosition(position, quote) {
  const current = toNumber(position.currentPrice, NaN);
  if (Number.isFinite(current) && current > 0) return 'MT5';
  return exitPriceSideForPosition(position, quote);
}

function estimatePositionProfit(position, symbol, quote) {
  const volumeLots = Math.abs(toNumber(position.volumeLots ?? position.volume));
  if (volumeLots === 0) return 0;

  const action = normalizeAction(position.action);
  const contractSize = toNumber(position.contractSize ?? (symbol && symbol.contractSize), 100000);
  const openPrice = toNumber(position.openPrice);
  const closePrice = exitPriceForPosition(position, quote);
  const priceDiff = action === 'BUY' ? closePrice - openPrice : openPrice - closePrice;
  const rateToAccount = toNumber(
    position.profitCurrencyRateToAccount ??
      position.rateProfit ??
      (symbol && symbol.profitCurrencyRateToAccount),
    1
  );

  return priceDiff * volumeLots * contractSize * rateToAccount;
}

function positionProfitMetrics(position, symbol, quote) {
  const action = normalizeAction(position.action);
  const volumeLots = Math.abs(toNumber(position.volumeLots ?? position.volume));
  const contractSize = toNumber(position.contractSize ?? (symbol && symbol.contractSize), 100000);
  const point = pointFromSymbol(symbol || {});
  const openPrice = toNumber(position.openPrice);
  const closePrice = displayClosePriceForPosition(position, quote);
  const priceDiff = action === 'BUY' ? closePrice - openPrice : openPrice - closePrice;
  const rateToAccount = toNumber(
    position.profitCurrencyRateToAccount ??
      position.rateProfit ??
      (symbol && symbol.profitCurrencyRateToAccount),
    1
  );
  const pointValue = volumeLots * contractSize * point;
  const pointValueAccount = pointValue * rateToAccount;
  const computedProfit = priceDiff * volumeLots * contractSize * rateToAccount;
  const swap = toNumber(position.swap);
  const commission = toNumber(position.commission);
  const computedNetProfit = computedProfit + swap + commission;
  const reportedProfit = toNumber(position.profit, NaN);
  const hasReportedProfit = Number.isFinite(reportedProfit);
  const profit = hasReportedProfit ? reportedProfit : computedProfit;

  return {
    action,
    volumeLots,
    contractSize,
    point,
    openPrice,
    closePrice,
    priceDiff,
    pointValue,
    pointValueAccount,
    profitCurrency: (symbol && symbol.currencyProfit) || position.currencyProfit || 'USD',
    profitCurrencyRateToAccount: rateToAccount,
    profit,
    swap,
    commission,
    netProfit: profit + swap + commission,
    computedProfit,
    computedNetProfit,
    reportedProfit: hasReportedProfit ? reportedProfit : undefined,
    profitSource: hasReportedProfit ? 'MT5_POSITION_PROFIT' : 'calculated',
    profitCheckDiff: hasReportedProfit ? reportedProfit - computedProfit : 0,
    closePriceSide: displayClosePriceSideForPosition(position, quote),
    quoteTime: quote && quote.time ? quote.time : ''
  };
}

module.exports = {
  toNumber,
  normalizeAction,
  pointFromSymbol,
  estimatePositionMargin,
  estimatePositionProfit,
  exitPriceForPosition,
  exitPriceSideForPosition,
  positionProfitMetrics
};
