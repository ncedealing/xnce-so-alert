'use strict';

const REDACTED = '[redacted]';

function isEnvVarName(value) {
  if (typeof value !== 'string') return false;
  const trimmed = value.trim();
  if (!trimmed) return true;
  return /^[A-Za-z_][A-Za-z0-9_]*$/.test(trimmed);
}

function shouldRedactSecret(key, value) {
  if (!/password|token|secret/i.test(key)) return false;
  if (/Env$/i.test(key)) {
    return Boolean(value) && !isEnvVarName(value);
  }
  return Boolean(value);
}

function redactSecrets(value) {
  if (Array.isArray(value)) return value.map(redactSecrets);
  if (!value || typeof value !== 'object') return value;

  const result = {};
  for (const [key, item] of Object.entries(value)) {
    if (shouldRedactSecret(key, item)) {
      result[key] = REDACTED;
    } else {
      result[key] = redactSecrets(item);
    }
  }
  return result;
}

function mergeRedactedSecrets(incoming, current) {
  if (incoming === REDACTED) return current;
  if (Array.isArray(incoming)) {
    return incoming.map((item, index) => mergeRedactedSecrets(item, Array.isArray(current) ? current[index] : undefined));
  }
  if (!incoming || typeof incoming !== 'object') return incoming;

  const result = {};
  for (const [key, value] of Object.entries(incoming)) {
    result[key] = mergeRedactedSecrets(
      value,
      current && typeof current === 'object' ? current[key] : undefined
    );
  }
  return result;
}

function resolveSecret(config = {}, valueKey, envKey) {
  const envName = config[envKey];
  if (isEnvVarName(envName) && envName && process.env[envName]) {
    return {
      value: process.env[envName],
      source: 'env',
      envName
    };
  }
  if (config[valueKey]) {
    return {
      value: String(config[valueKey]),
      source: 'direct',
      envName: isEnvVarName(envName) ? envName : ''
    };
  }
  if (envName && !isEnvVarName(envName)) {
    return {
      value: String(envName),
      source: 'legacyEnvField',
      envName: ''
    };
  }
  return {
    value: '',
    source: 'missing',
    envName: envName || ''
  };
}

module.exports = {
  REDACTED,
  isEnvVarName,
  mergeRedactedSecrets,
  redactSecrets,
  resolveSecret
};
