import { useEffect, useState, type ReactNode } from 'react';
import { BellRing, Check, GitBranch, ListTree, Loader2, Mail, Save, Server, ShieldCheck, UploadCloud } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ConfigSaveBar, Mt5ConfigurationTab } from '@/components/Mt5ConfigurationTab';
import { EmailNotificationTab } from '@/components/EmailNotificationTab';
import { SecurityTab } from '@/components/SecurityTab';
import { SystemUpdateTab } from '@/components/SystemUpdateTab';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';
import { useI18n } from '@/i18n';
import type { AppConfig, Mt5ConnectionStatus, Mt5ServerConfig, RiskResult } from '@/types/api';

type ConfigTab = 'mt5' | 'symbolList' | 'symbolMapping' | 'notification' | 'alertCondition' | 'systemUpdate' | 'security';

const tabMeta: Record<ConfigTab, { titleZh: string; titleEn: string; descriptionZh: string; descriptionEn: string }> = {
  mt5: {
    titleZh: 'MT5',
    titleEn: 'MT5',
    descriptionZh: '配置管理端连接、组过滤、账号过滤和 LP 账号。',
    descriptionEn: 'Configure manager connection, group masks, account filters and LP account settings.',
  },
  symbolList: {
    titleZh: '产品列表',
    titleEn: 'Symbol List',
    descriptionZh: '读取 MT5 产品规格，并设置持仓监控的产品过滤。',
    descriptionEn: 'Read MT5 product specifications and control symbol filters.',
  },
  symbolMapping: {
    titleZh: '产品映射',
    titleEn: 'Symbol Mapping',
    descriptionZh: '把后缀产品或自定义产品映射到统一风控产品。',
    descriptionEn: 'Map suffix symbols or custom symbols into a canonical risk product.',
  },
  notification: {
    titleZh: '邮件 / Telegram',
    titleEn: 'Email / Telegram',
    descriptionZh: '配置 SMTP、邮件模板、Telegram 机器人提醒和通知冷却。',
    descriptionEn: 'Configure SMTP, email templates, Telegram bot alerts and notification cooldown.',
  },
  alertCondition: {
    titleZh: '告警条件',
    titleEn: 'Alert Conditions',
    descriptionZh: '配置注意/危险阈值和全局告警条件表达式。',
    descriptionEn: 'Configure warning and danger thresholds plus global alert condition expressions.',
  },
  systemUpdate: {
    titleZh: '系统更新',
    titleEn: 'System Update',
    descriptionZh: '上传生产部署包，只更新核心应用模块，不覆盖已保存数据。',
    descriptionEn: 'Upload production deployment packages and apply only application modules without touching saved data.',
  },
  security: {
    titleZh: '安全',
    titleEn: 'Security',
    descriptionZh: '管理远程登录用户和管理员密码。',
    descriptionEn: 'Manage remote login users and admin passwords.',
  },
};

interface ConfigurationProps {
  config: AppConfig | null;
  risk: RiskResult | null;
  saving: boolean;
  onSave: (config: AppConfig) => Promise<unknown>;
  onTestMt5Connection: (server: Mt5ServerConfig) => Promise<Mt5ConnectionStatus>;
}

export function Configuration({ config, risk, saving, onSave, onTestMt5Connection }: ConfigurationProps) {
  const { t } = useI18n();
  const [draft, setDraft] = useState<AppConfig | null>(config);
  const [activeTab, setActiveTab] = useState<ConfigTab>('mt5');

  useEffect(() => {
    if (config) setDraft(config);
  }, [config]);

  const handleSave = async () => {
    if (!draft) return;
    try {
      await onSave(draft);
      toast({ title: t('配置已保存', 'Configuration saved'), description: t('系统配置已成功写入。', 'System configuration has been saved.') });
    } catch (e) {
      toast({
        title: t('保存失败', 'Save failed'),
        description: e instanceof Error ? e.message : t('未知错误', 'Unknown error'),
        variant: 'destructive',
      });
    }
  };

  if (!draft) {
    return (
      <div className="flex h-full items-center justify-center bg-zinc-900 text-xs text-zinc-500">
        {t('正在加载配置...', 'Loading configuration...')}
      </div>
    );
  }

  return (
    <div className="flex h-full overflow-hidden animate-in fade-in duration-300">
      <aside className="w-56 shrink-0 border-r border-zinc-800 bg-zinc-950 p-4">
        <div className="mb-5 border-b border-zinc-800 pb-4">
          <p className="text-xs font-semibold uppercase tracking-wide text-zinc-100">{t('配置', 'Configuration')}</p>
          <p className="mt-1 text-[10px] text-zinc-500">{t('接入、产品、映射、通知、风控', 'Connection, symbols, mapping, alerts')}</p>
        </div>
        <nav className="flex flex-col gap-2">
          <SideTab
            active={activeTab === 'mt5'}
            onClick={() => setActiveTab('mt5')}
            icon={<Server className="h-4 w-4" />}
          >
            MT5
          </SideTab>
          <SideTab
            active={activeTab === 'symbolList'}
            onClick={() => setActiveTab('symbolList')}
            icon={<ListTree className="h-4 w-4" />}
          >
            {t('产品列表', 'Symbol List')}
          </SideTab>
          <SideTab
            active={activeTab === 'symbolMapping'}
            onClick={() => setActiveTab('symbolMapping')}
            icon={<GitBranch className="h-4 w-4" />}
          >
            {t('产品映射', 'Symbol Mapping')}
          </SideTab>
          <SideTab
            active={activeTab === 'notification'}
            onClick={() => setActiveTab('notification')}
            icon={<Mail className="h-4 w-4" />}
          >
            {t('邮件/Telegram', 'Email/Telegram')}
          </SideTab>
          <SideTab
            active={activeTab === 'alertCondition'}
            onClick={() => setActiveTab('alertCondition')}
            icon={<BellRing className="h-4 w-4" />}
          >
            {t('告警条件', 'Alert Conditions')}
          </SideTab>
          <SideTab
            active={activeTab === 'systemUpdate'}
            onClick={() => setActiveTab('systemUpdate')}
            icon={<UploadCloud className="h-4 w-4" />}
          >
            {t('系统更新', 'System Update')}
          </SideTab>
          <SideTab
            active={activeTab === 'security'}
            onClick={() => setActiveTab('security')}
            icon={<ShieldCheck className="h-4 w-4" />}
          >
            {t('安全', 'Security')}
          </SideTab>
        </nav>
      </aside>

      <section className="relative flex-1 overflow-y-auto bg-zinc-900 p-8 scrollbar-thin">
        <div className="mx-auto max-w-5xl pb-20">
          <div className="mb-8 flex items-end justify-between border-b border-zinc-800 pb-4">
            <div>
              <h2 className="mb-1 text-2xl font-bold text-white">
                {t(tabMeta[activeTab].titleZh, tabMeta[activeTab].titleEn)}
              </h2>
              <p className="text-xs text-zinc-400">{t(tabMeta[activeTab].descriptionZh, tabMeta[activeTab].descriptionEn)}</p>
            </div>
            <Button onClick={handleSave} disabled={saving}>
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
              {saving ? t('保存中...', 'Saving...') : t('保存配置', 'Save Changes')}
            </Button>
          </div>

          {activeTab === 'security' ? (
            <SecurityTab />
          ) : activeTab === 'systemUpdate' ? (
            <SystemUpdateTab config={draft} onChange={setDraft} />
          ) : activeTab === 'notification' ? (
            <EmailNotificationTab config={draft} onChange={setDraft} onSave={onSave} />
          ) : (
            <Mt5ConfigurationTab
              config={draft}
              section={activeTab}
              symbols={risk?.snapshot.symbols ?? []}
              onChange={setDraft}
              onTestConnection={onTestMt5Connection}
            />
          )}
        </div>
        <ConfigSaveBar saving={saving} onSave={handleSave} />
      </section>
    </div>
  );
}

function SideTab({
  active,
  onClick,
  icon,
  children,
}: {
  active: boolean;
  onClick: () => void;
  icon: ReactNode;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors',
        active ? 'bg-zinc-800 text-white' : 'text-zinc-400 hover:bg-zinc-900 hover:text-zinc-200',
      )}
    >
      {icon}
      <span className="truncate">{children}</span>
      {active && <Check className="ml-auto h-3.5 w-3.5 text-emerald-400" />}
    </button>
  );
}
