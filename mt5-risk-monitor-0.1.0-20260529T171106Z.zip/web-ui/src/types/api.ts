export interface SystemStatus {
  running: boolean;
  pollInFlight: boolean;
  pollIntervalSeconds: number;
  mt5DisconnectAfterPollMultiples?: number;
  serverTimeStaleThresholdMs?: number;
  streamingTransport?: string;
  providerType: string;
  mt5Connection?: Mt5ConnectionStatus;
  serverTime?: string | null;
  serverTimeUpdatedAt?: string | null;
  serverTimeStale?: boolean;
  serverTimeAgeMs?: number | null;
  mt5DataAgeMs?: number | null;
  monitorStartedAt?: string | null;
  serverTimeZone?: 'GMT+2' | 'GMT+3' | string;
  serverTimeOffsetMinutes?: number;
  groupMasks: string[];
  symbolMasks: string[];
  lastCheckedAt: string | null;
  lastError: string | null;
  accounts: number;
  positions: number;
  alerts: number;
}

export interface Mt5ConnectionStatus {
  status: 'unknown' | 'testing' | 'connected' | 'disconnected' | string;
  ok: boolean;
  host?: string;
  port?: number;
  login?: number | string;
  checkedAt?: string | null;
  latencyMs?: number;
  error?: string | null;
  checks?: Array<{
    key: string;
    status: 'ok' | 'warning' | 'error' | string;
    message: string;
  }>;
}

export interface Account {
  login: number | string;
  group: string;
  currency: string;
  balance: number;
  equityAdjustment?: number;
  credit: number;
  leverage: number;
  marginLeverage?: number;
  staticLeverage?: number;
  leverageSource?: string;
  equity: number;
  margin: number;
  marginFree?: number;
  marginLevel?: number;
}

export interface Quote {
  symbol: string;
  bid: number;
  ask: number;
  time: string;
}

export interface SnapshotSymbol {
  symbol: string;
  path?: string;
  description?: string;
  category?: string;
  digits?: number;
  point?: number;
  contractSize?: number;
  currencyProfit?: string;
  currencyMargin?: string;
  marginInitial?: number;
  marginMaintenance?: number;
  marginLong?: number;
  marginShort?: number;
  marginRateInitial?: number;
  calcMode?: number;
  calcModeName?: string;
  tradeCalcMode?: number;
  tradeCalcModeName?: string;
  swapMode?: number;
  swapModeName?: string;
  swapLong?: number;
  swapShort?: number;
  swap3Day?: number;
}

export interface SymbolRisk {
  symbol: string;
  direction: 'up' | 'down' | string;
  currentPrice: number;
  liquidationPrice: number;
  distancePoints: number;
  alertDistancePoints: number;
  warningDistancePoints?: number;
  dangerDistancePoints?: number;
  severity?: 'normal' | 'warning' | 'danger' | string;
  shouldAlert: boolean;
  stopOutLevel: number;
  point: number;
  quote: Quote;
  convertedPrices?: Array<{
    symbol: string;
    openPrice?: number;
    currentPrice: number;
    liquidationPrice: number;
    distancePoints: number;
    point: number;
    currency?: string;
  }>;
  averageOpenPrice?: number;
  buyAverageOpenPrice?: number;
  sellAverageOpenPrice?: number;
  buyLots?: number;
  sellLots?: number;
  grossLots?: number;
  netLots?: number;
  absNetLots?: number;
  netDirection?: string;
}

export interface PositionDetail {
  ticket: string | number;
  login: string | number;
  symbol: string;
  action: string;
  volumeLots: number;
  openPrice: number;
  currentPrice: number;
  closePrice: number;
  closePriceSide?: string;
  quoteBid?: number;
  quoteAsk?: number;
  quoteTime?: string;
  contractSize: number;
  point: number;
  pointValue: number;
  pointValueAccount: number;
  profitCurrency: string;
  profitCurrencyRateToAccount: number;
  profit: number;
  swap?: number;
  commission?: number;
  netProfit?: number;
  reportedProfit?: number;
  computedProfit?: number;
  computedNetProfit?: number;
  profitSource?: string;
  profitCheckDiff?: number;
  canonicalSymbol?: string;
  lotsToBaseMultiplier?: number;
  baseEquivalentLots?: number;
  baseContractSize?: number;
  basePoint?: number;
  baseProfitCurrency?: string;
  basePointValuePerLotAccount?: number;
  basePointValueAccount?: number;
  basePointValueCurrency?: string;
  baseOpenPrice?: number;
  openTime?: string;
  updateTime?: string;
}

export interface SymbolExposure {
  symbol: string;
  buyLots: number;
  sellLots: number;
  grossLots: number;
  netLots: number;
  absNetLots: number;
  netDirection: 'BUY' | 'SELL' | 'FLAT' | string;
  positionCount: number;
  averageOpenPrice?: number;
  buyAverageOpenPrice?: number;
  sellAverageOpenPrice?: number;
  netAverageOpenPrice?: number;
  contractSize: number;
  point: number;
  profitCurrencyRateToAccount?: number;
  pointValueCurrency?: string;
  pointValuePerLot: number;
  pointValuePerLotAccount: number;
  totalPointValue: number;
  totalPointValueAccount: number;
  netPointValue?: number;
  netPointValueAccount?: number;
  grossContractUnits: number;
  netContractUnits: number;
  profit: number;
  swap?: number;
  commission?: number;
  netProfit?: number;
  components?: Array<{
    symbol: string;
    volumeLots: number;
    baseEquivalentLots: number;
    baseOpenPrice?: number;
    action: string;
    ticket: string | number;
    profit?: number;
    swap?: number;
    commission?: number;
    netProfit?: number;
  }>;
  risk: SymbolRisk | null;
}

export interface RiskReport {
  account: Account;
  positions: PositionDetail[];
  positionDetails: PositionDetail[];
  symbolExposures: SymbolExposure[];
  dashboardExposure: SymbolExposure | null;
  equity: number;
  margin: number;
  floating: number;
  marginLevel: number;
  stopOutLevel: number;
  symbolRisks: SymbolRisk[];
}

export interface AlertItem {
  key: string;
  subject: string;
  triggeredAt?: string;
  reasons?: string;
  account: Partial<Account>;
  risk: Partial<SymbolRisk>;
}

export interface RiskResult {
  checkedAt: string;
  snapshot: {
    serverTime: string;
    accounts: Account[];
    positions: unknown[];
    symbols: SnapshotSymbol[];
    quotes: Quote[];
  };
  reports: RiskReport[];
  alerts: AlertItem[];
}

export interface RuntimeConfig {
  pollIntervalSeconds: number;
  streamingTransport?: string;
  autoStart?: boolean;
  stateDir: string;
  logLevel: string;
}

export interface WebConfig {
  host: string;
  port: number;
  authTokenEnv: string;
  auth?: {
    enabled: boolean;
    cookieName?: string;
    secureCookie?: boolean | 'auto';
    sessionTtlHours?: number;
    users?: AuthUser[];
  };
  systemUpdate?: {
    enabled: boolean;
    allowApply: boolean;
    maxUploadMb: number;
    updateDir: string;
  };
}

export interface AuthUser {
  username: string;
  role: string;
  createdAt?: string | null;
  updatedAt?: string | null;
}

export interface AuthStatus {
  enabled: boolean;
  authenticated: boolean;
  user: AuthUser | null;
}

export interface SystemUpdatePackage {
  id: string;
  fileName: string;
  path: string;
  sizeBytes: number;
  sha256: string;
  uploadedAt: string;
  appliedAt?: string | null;
  status: 'uploaded' | 'applied' | string;
  backupDir?: string;
  copied?: string[];
}

export interface SystemUpdateStatus {
  enabled: boolean;
  allowApply: boolean;
  maxUploadMb: number;
  updateDir: string;
  latest: SystemUpdatePackage | null;
}

export interface ManagerApiProviderConfig {
  command: string;
  args: string[];
  cwd: string;
  timeoutMs: number;
}

export interface Mt5WebApiProviderConfig {
  crypt: 'aes' | 'none' | string;
  agent: string;
  timeoutMs: number;
  maxPositionsPerAccount?: number;
  keepAlive?: boolean;
}

export interface ProviderConfig {
  type: 'mock' | 'managerApi' | 'mt5WebApi';
  mockSnapshotPath: string;
  managerApi?: ManagerApiProviderConfig;
  mt5WebApi?: Mt5WebApiProviderConfig;
}

export interface Mt5ServerConfig {
  name: string;
  host: string;
  port: number;
  login: number;
  password?: string;
  passwordEnv: string;
  timeoutMs: number;
  providerType?: ProviderConfig['type'];
  deepAuth?: boolean;
  authTimeoutMs?: number;
  tryAlternateCrypt?: boolean;
}

export interface Mt5Config {
  servers: Mt5ServerConfig[];
  groupMasks: string[];
  accountLogins: Array<string | number>;
  symbolMasks: string[];
  baseCurrency: string;
  serverTimeZone?: 'GMT+2' | 'GMT+3' | string;
  serverTimeOffsetMinutes?: number;
  disconnectAfterPollMultiples?: number;
  symbolSpecs?: SymbolSpecConfig[];
}

export interface SymbolSpecConfig {
  symbol: string;
  category?: string;
  contractSize?: number;
  point?: number;
  digits?: number;
  currencyProfit?: string;
  currencyMargin?: string;
}

export interface CooldownConfig {
  seconds: number;
  priceMovementPoints: number;
  mode: 'timeOnly' | 'priceOnly' | 'timeOrPrice' | 'timeAndPrice';
}

export interface RiskConfig {
  stopOutLevel: number;
  accountStopOutLevels: Record<string, number>;
  accountOverrides: Record<string, {
    stopOutLevel?: number;
    warningDistancePoints?: number;
    dangerDistancePoints?: number;
    alertConditions?: AlertConditionExpression;
    cooldown?: CooldownConfig;
  }>;
  alertConditions: AlertConditionExpression | null;
  alertDistancePointsDefault: number;
  warningDistancePointsDefault?: number;
  dangerDistancePointsDefault?: number;
  symbolDistancePoints: Record<string, number>;
  warningSymbolDistancePoints?: Record<string, number>;
  dangerSymbolDistancePoints?: Record<string, number>;
  symbolMappings: Record<string, SymbolMappingConfig>;
  defaultSixCharSymbolMapping?: boolean;
  maxSearchDistancePoints: number;
  treatReportedMarginAsFixed: boolean;
  includeCreditInEquity: boolean;
  minimumMargin: number;
}

export interface SymbolMappingConfig {
  baseSymbol: string;
  mappedLotsPerBaseLot?: number;
  lotsToBase?: number;
  baseLotsPerMappedLot?: number;
  multiplier?: number;
  fxSymbol?: string;
  quoteSymbol?: string;
  fxRate?: number;
  baseUnitGrams?: number;
  mappedUnitGrams?: number;
  baseToMappedPriceMultiplier?: number;
  currency?: string;
}

export interface AlertConditionRule {
  metric: 'distancePoints' | 'marginLevel' | 'marginLevelPercent' | 'grossLots' | 'lots' | 'netLots' | 'absNetLots' | string;
  operator: 'lt' | 'lte' | 'gt' | 'gte' | 'eq' | 'neq';
  value: number;
  enabled?: boolean;
}

export interface AlertConditionExpression {
  op?: 'and' | 'or' | 'not';
  logic?: 'and' | 'or' | 'not';
  rules?: Array<AlertConditionRule | AlertConditionExpression>;
  metric?: string;
  operator?: string;
  value?: number;
  threshold?: number;
  accountScope?: 'all' | 'clientsOnly' | 'lpOnly';
}

export interface LpAccountConfig {
  enabled: boolean;
  name: string;
  balance: number;
  equityAdjustment?: number;
  credit: number;
  leverage: number;
  currency: string;
  mode: string;
  hedgeDirection: 'same' | 'opposite';
  aggregation: string;
  explicitPositions: unknown[];
}

export interface SmtpConfig {
  host: string;
  port: number;
  secure: boolean;
  username?: string;
  password?: string;
  usernameEnv: string;
  passwordEnv: string;
  from: string;
  to: string[];
  timeoutMs: number;
}

export interface EmailConfig {
  enabled: boolean;
  transport: string;
  templatePath: string;
  templateHtml?: string;
  cooldownSeconds: number;
  subjectTemplate: string;
  alertConditions: AlertConditionExpression & {
    accountScope: 'all' | 'clientsOnly' | 'lpOnly';
    triggerMode: 'any' | 'all';
    distanceToLiquidation: boolean;
    stopOut: {
      enabled: boolean;
    };
    marginLevel: {
      enabled: boolean;
      threshold: number;
    };
  };
  smtp: SmtpConfig;
}

export interface TelegramConfig {
  enabled: boolean;
  botTokenEnv: string;
  botToken: string;
  chatIds: string[];
  proxyUrl?: string;
  parseMode: string;
  disableWebPagePreview: boolean;
  timeoutMs: number;
  messageTemplate: string;
}

export interface TelegramChat {
  id: string;
  type: string;
  title?: string;
  username?: string;
  lastText?: string;
  date?: string | null;
}

export interface NotificationConfig {
  cooldown: CooldownConfig;
}

export interface AppConfig {
  runtime: RuntimeConfig;
  web: WebConfig;
  provider: ProviderConfig;
  mt5: Mt5Config;
  risk: RiskConfig;
  lpAccount: LpAccountConfig;
  email: EmailConfig;
  telegram: TelegramConfig;
  notifications: NotificationConfig;
}

export interface ConfigSaveResponse {
  ok: boolean;
  config: AppConfig;
}

/** Flattened row for the risk table */
export interface RiskTableRow {
  id: string;
  login: number | string;
  group: string;
  equity: number;
  margin: number;
  leverage?: number;
  marginLevel: number;
  stopOutLevel: number;
  symbol: string;
  componentSymbols?: string[];
  direction: string;
  netDirection: string;
  buyLots: number;
  sellLots: number;
  grossLots: number;
  netLots: number;
  averageOpenPrice: number;
  contractSize: number;
  pointValuePerLotAccount: number;
  netPointValueAccount?: number;
  positionCount: number;
  bid: number;
  ask: number;
  liquidationPrice: number;
  distancePoints: number;
  alertDistancePoints: number;
  warningDistancePoints?: number;
  dangerDistancePoints?: number;
  shouldAlert: boolean;
  convertedPrices?: SymbolRisk['convertedPrices'];
  riskLevel: 'normal' | 'warning' | 'critical';
}
