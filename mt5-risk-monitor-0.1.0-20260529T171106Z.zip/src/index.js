#!/usr/bin/env node
'use strict';

const { run } = require('./app');

run().catch((error) => {
  console.error(error.stack || error.message);
  process.exitCode = 1;
});
