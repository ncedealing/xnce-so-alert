'use strict';

const { readFile } = require('node:fs/promises');
const { resolveFromCwd } = require('../config');

class MockProvider {
  constructor(config) {
    this.config = config;
  }

  async getSnapshot() {
    const filePath = resolveFromCwd(this.config, this.config.provider.mockSnapshotPath);
    const raw = await readFile(filePath, 'utf8');
    return JSON.parse(raw);
  }

  async getSymbols() {
    const snapshot = await this.getSnapshot();
    return snapshot.symbols || [];
  }
}

module.exports = {
  MockProvider
};
