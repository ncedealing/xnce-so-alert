import { useEffect, useState, type ReactNode } from 'react';
import { Loader2, PackageCheck, UploadCloud } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { toast } from '@/hooks/use-toast';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import type { AppConfig, SystemUpdateStatus } from '@/types/api';

interface SystemUpdateTabProps {
  config: AppConfig;
  onChange: (config: AppConfig) => void;
}

export function SystemUpdateTab({ config, onChange }: SystemUpdateTabProps) {
  const { t } = useI18n();
  const updateConfig = {
    enabled: true,
    allowApply: true,
    maxUploadMb: 200,
    updateDir: 'updates',
    ...(config.web.systemUpdate || {}),
  };
  const [status, setStatus] = useState<SystemUpdateStatus | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [applyAfterUpload, setApplyAfterUpload] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [applying, setApplying] = useState(false);

  const update = (patch: Partial<typeof updateConfig>) => {
    onChange({
      ...config,
      web: {
        ...config.web,
        systemUpdate: {
          ...updateConfig,
          ...patch,
        },
      },
    });
  };

  const refreshStatus = async () => {
    try {
      setStatus(await api.getSystemUpdateStatus());
    } catch (error) {
      toast({
        title: t('读取更新状态失败', 'Failed to read update status'),
        description: error instanceof Error ? error.message : t('未知错误', 'Unknown error'),
        variant: 'destructive',
      });
    }
  };

  useEffect(() => {
    void refreshStatus();
  }, []);

  const upload = async () => {
    if (!selectedFile) return;
    setUploading(true);
    try {
      const result = await api.uploadSystemUpdate(selectedFile, applyAfterUpload);
      toast({
        title: applyAfterUpload ? t('更新包已上传并应用', 'Update package uploaded and applied') : t('更新包已上传', 'Update package uploaded'),
        description: t(`${result.package?.fileName || selectedFile.name} 已保存。`, `${result.package?.fileName || selectedFile.name} has been saved.`),
      });
      setSelectedFile(null);
      await refreshStatus();
    } catch (error) {
      toast({
        title: t('上传更新包失败', 'Failed to upload update package'),
        description: error instanceof Error ? error.message : t('未知错误', 'Unknown error'),
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
    }
  };

  const applyLatest = async () => {
    setApplying(true);
    try {
      const result = await api.applySystemUpdate();
      toast({
        title: t('更新已应用', 'Update applied'),
        description: result.applied?.copied?.length ? t(`已更新：${result.applied.copied.join(', ')}`, `Updated: ${result.applied.copied.join(', ')}`) : t('文件已更新，请重启服务加载后端代码。', 'Files have been updated. Restart the service to load backend code.'),
      });
      await refreshStatus();
    } catch (error) {
      toast({
        title: t('应用更新失败', 'Failed to apply update'),
        description: error instanceof Error ? error.message : t('未知错误', 'Unknown error'),
        variant: 'destructive',
      });
    } finally {
      setApplying(false);
    }
  };

  return (
    <div className="space-y-3 pb-16">
      <Card>
        <CardHeader>
          <CardTitle>{t('系统更新', 'System Update')}</CardTitle>
          <CardDescription>{t('上传 zip 更新包，先暂存到服务器，再按需应用到系统文件', 'Upload a zip update package, stage it on the server, then apply it when needed.')}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <ToggleField label={t('启用上传', 'Enable Upload')} checked={updateConfig.enabled} onCheckedChange={(checked) => update({ enabled: checked })} />
            <ToggleField label={t('允许应用更新', 'Allow Apply')} checked={updateConfig.allowApply} onCheckedChange={(checked) => update({ allowApply: checked })} />
            <Field label={t('最大上传(MB)', 'Max Upload (MB)')}>
              <Input type="number" min={1} value={updateConfig.maxUploadMb} onChange={(event) => update({ maxUploadMb: Number(event.target.value) || 200 })} />
            </Field>
            <Field label={t('更新目录', 'Update Directory')}>
              <Input value={updateConfig.updateDir} onChange={(event) => update({ updateDir: event.target.value || 'updates' })} />
            </Field>
          </div>

          <div className="rounded-md border border-amber-900/40 bg-amber-950/20 p-3 text-xs leading-relaxed text-amber-100/80">
            {t('可以直接上传生产环境部署用的同一个 zip 包。系统会先解包并自动识别项目根目录，然后只更新白名单内的核心应用模块：src、public、templates、web-ui、adapters、scripts、package.json、package-lock.json。本地配置、登录用户、密码、运行状态、历史数据和上传目录不会被覆盖。应用后如果更新了后端代码，需要重启服务。', 'You can upload the same zip package used for production deployment. The system extracts it, detects the project root, and updates only whitelisted application modules: src, public, templates, web-ui, adapters, scripts, package.json, and package-lock.json. Local configuration, login users, passwords, runtime state, history, and update uploads are not overwritten. Restart the service after applying backend code updates.')}
          </div>

          <div className="grid gap-3 rounded-md border border-zinc-800 bg-zinc-950/50 p-3 lg:grid-cols-[1fr_auto]">
            <div className="space-y-2">
              <Label>{t('上传更新压缩包', 'Upload Update Package')}</Label>
              <Input
                type="file"
                accept=".zip,application/zip"
                onChange={(event) => setSelectedFile(event.target.files?.[0] || null)}
              />
              {selectedFile && (
                <p className="text-[11px] text-zinc-500">
                  {selectedFile.name} / {formatBytes(selectedFile.size)}
                </p>
              )}
              <label className="flex items-center gap-2 text-xs text-zinc-400">
                <input type="checkbox" checked={applyAfterUpload} onChange={(event) => setApplyAfterUpload(event.target.checked)} />
                {t('上传后立即应用更新', 'Apply update immediately after upload')}
              </label>
            </div>
            <div className="flex items-end gap-2">
              <Button type="button" onClick={upload} disabled={!selectedFile || uploading}>
                {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <UploadCloud className="h-3.5 w-3.5" />}
                {uploading ? t('上传中...', 'Uploading...') : t('上传更新包', 'Upload Package')}
              </Button>
              <Button type="button" variant="outline" onClick={applyLatest} disabled={!status?.latest || applying || !updateConfig.allowApply}>
                {applying ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <PackageCheck className="h-3.5 w-3.5" />}
                {applying ? t('应用中...', 'Applying...') : t('应用已上传包', 'Apply Uploaded Package')}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t('最新更新包', 'Latest Update Package')}</CardTitle>
          <CardDescription>{t('最近一次上传或应用的更新包状态', 'Status of the most recently uploaded or applied update package')}</CardDescription>
        </CardHeader>
        <CardContent>
          {!status?.latest ? (
            <div className="rounded-md border border-zinc-800 bg-zinc-950 p-6 text-center text-xs text-zinc-500">{t('暂无已上传更新包', 'No uploaded update package')}</div>
          ) : (
            <div className="grid gap-2 text-xs text-zinc-300 sm:grid-cols-2">
              <Info label={t('文件名', 'File Name')} value={status.latest.fileName} />
              <Info label={t('状态', 'Status')} value={status.latest.status} />
              <Info label={t('大小', 'Size')} value={formatBytes(status.latest.sizeBytes)} />
              <Info label={t('上传时间', 'Uploaded At')} value={formatTime(status.latest.uploadedAt)} />
              <Info label={t('应用时间', 'Applied At')} value={status.latest.appliedAt ? formatTime(status.latest.appliedAt) : t('尚未应用', 'Not Applied')} />
              <Info label="SHA256" value={status.latest.sha256} mono />
              {status.latest.copied?.length ? <Info label={t('已更新文件', 'Updated Files')} value={status.latest.copied.join(', ')} /> : null}
              {status.latest.backupDir ? <Info label={t('备份目录', 'Backup Directory')} value={status.latest.backupDir} mono /> : null}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-1">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function ToggleField({
  label,
  checked,
  onCheckedChange,
}: {
  label: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
}) {
  return (
    <div className="flex items-center gap-2 self-end pb-1">
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
      <Label>{label}</Label>
    </div>
  );
}

function Info({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="rounded-md border border-zinc-800 bg-zinc-950 p-3">
      <div className="mb-1 text-[10px] uppercase text-zinc-500">{label}</div>
      <div className={mono ? 'break-all font-mono text-[11px]' : 'break-words'}>{value}</div>
    </div>
  );
}

function formatBytes(value: number) {
  if (!Number.isFinite(value)) return '—';
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / 1024 / 1024).toFixed(2)} MB`;
}

function formatTime(value: string) {
  const time = new Date(value);
  if (!Number.isFinite(time.getTime())) return value;
  return time.toLocaleString('zh-CN', { hour12: false });
}
