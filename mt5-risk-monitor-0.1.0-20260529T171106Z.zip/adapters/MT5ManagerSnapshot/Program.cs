using MetaQuotes.MT5CommonAPI;
using MetaQuotes.MT5ManagerAPI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Script.Serialization;

namespace MT5ManagerSnapshot
{
  internal static class Program
  {
    private const string DefaultCurrency = "USD";
    private static readonly JavaScriptSerializer Json = new JavaScriptSerializer { MaxJsonLength = 50 * 1024 * 1024 };

    private static int Main()
    {
      try
      {
        string input = Console.In.ReadToEnd();
        SnapshotRequest request = Json.Deserialize<SnapshotRequest>(input);
        if (request == null || request.server == null) throw new InvalidOperationException("Missing snapshot request");

        SnapshotResponse response = new SnapshotCollector(request).Collect();
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.Write(Json.Serialize(response));
        return 0;
      }
      catch (Exception ex)
      {
        Console.Error.WriteLine(ex.Message);
        return 1;
      }
      finally
      {
        SMTManagerAPIFactory.Shutdown();
      }
    }
  }

  internal sealed class SnapshotCollector
  {
    private readonly SnapshotRequest _request;
    private CIMTManagerAPI _manager;
    private readonly Dictionary<ulong, AccountDto> _accounts = new Dictionary<ulong, AccountDto>();
    private readonly Dictionary<ulong, string> _groupsByLogin = new Dictionary<ulong, string>();
    private readonly Dictionary<string, SymbolDto> _symbols = new Dictionary<string, SymbolDto>(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, QuoteDto> _quotes = new Dictionary<string, QuoteDto>(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, string> _groupCurrencies = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

    public SnapshotCollector(SnapshotRequest request)
    {
      _request = request;
    }

    public SnapshotResponse Collect()
    {
      Connect();

      List<CIMTUser> users = LoadUsers();
      List<PositionDto> positions = LoadAccountsAndPositions(users);
      LoadSymbolsAndQuotes(positions, users);

      return new SnapshotResponse
      {
        serverTime = ReadServerTime(),
        accounts = _accounts.Values.OrderBy(account => account.login).ToList(),
        positions = positions,
        symbols = _symbols.Values.OrderBy(symbol => symbol.symbol).ToList(),
        quotes = _quotes.Values.OrderBy(quote => quote.symbol).ToList()
      };
    }

    private void Connect()
    {
      MTRetCode res = SMTManagerAPIFactory.Initialize(null);
      RequireOk(res, "SMTManagerAPIFactory.Initialize");

      _manager = SMTManagerAPIFactory.CreateManager(SMTManagerAPIFactory.ManagerAPIVersion, out res);
      if (_manager == null || res != MTRetCode.MT_RET_OK) RequireOk(res, "CreateManager");

      string server = string.Format("{0}:{1}", _request.server.host, _request.server.port);
      uint timeout = (uint)Math.Max(1000, _request.server.timeoutMs);
      res = _manager.Connect(
        server,
        ToUlong(_request.server.login),
        _request.server.password,
        null,
        CIMTManagerAPI.EnPumpModes.PUMP_MODE_FULL,
        timeout
      );
      RequireOk(res, "Connect");
    }

    private List<CIMTUser> LoadUsers()
    {
      string[] accountLogins = Clean(_request.mt5 == null ? null : _request.mt5.accountLogins);
      string[] groupMasks = Clean(_request.mt5 == null ? null : _request.mt5.groupMasks);
      List<CIMTUser> users = new List<CIMTUser>();
      HashSet<ulong> seen = new HashSet<ulong>();

      if (accountLogins.Length > 0)
      {
        foreach (string loginText in accountLogins)
        {
          ulong login = ToUlong(loginText);
          CIMTUser user = _manager.UserCreate();
          MTRetCode res = _manager.UserRequest(login, user);
          RequireOk(res, "UserRequest " + login);
          AddUser(users, seen, user);
        }
        return users;
      }

      if (groupMasks.Length == 0)
      {
        if (_request.mt5 != null && _request.mt5.symbolListOnly) return users;
        throw new InvalidOperationException("At least one group mask or account login is required");
      }

      foreach (string groupMask in groupMasks)
      {
        CIMTUserArray userArray = _manager.UserCreateArray();
        try
        {
          MTRetCode res = _manager.UserRequestArray(groupMask, userArray);
          RequireOk(res, "UserRequestArray " + groupMask);
          uint total = userArray.Total();
          for (uint index = 0; index < total; index++)
          {
            CIMTUser user = userArray.Next(index);
            AddUser(users, seen, user);
          }
        }
        finally
        {
          if (userArray != null) userArray.Dispose();
        }
      }

      return users;
    }

    private void AddUser(List<CIMTUser> users, HashSet<ulong> seen, CIMTUser user)
    {
      if (user == null) return;
      ulong login = user.Login();
      if (seen.Contains(login))
      {
        user.Dispose();
        return;
      }
      seen.Add(login);
      users.Add(user);
      _groupsByLogin[login] = user.Group();
    }

    private List<PositionDto> LoadAccountsAndPositions(List<CIMTUser> users)
    {
      List<PositionDto> positions = new List<PositionDto>();
      foreach (CIMTUser user in users)
      {
        ulong login = user.Login();
        string group = user.Group();
        string currency = GroupCurrency(group);
        CIMTAccount account = _manager.UserCreateAccount();
        try
        {
          MTRetCode accountResult = _manager.UserAccountRequest(login, account);
          RequireOk(accountResult, "UserAccountRequest " + login);
          uint marginLeverage = account.MarginLeverage();
          uint staticLeverage = user.Leverage();
          uint leverage = marginLeverage > 0 ? marginLeverage : (staticLeverage > 0 ? staticLeverage : 1);
          _accounts[login] = new AccountDto
          {
            login = login,
            group = group,
            currency = currency,
            balance = account.Balance(),
            credit = account.Credit(),
            leverage = leverage,
            marginLeverage = marginLeverage > 0 ? marginLeverage : (uint?)null,
            staticLeverage = staticLeverage > 0 ? staticLeverage : (uint?)null,
            leverageSource = marginLeverage > 0 ? "UserAccountRequest.MarginLeverage" : (staticLeverage > 0 ? "User.Leverage" : "default"),
            equity = account.Equity(),
            margin = account.Margin(),
            marginFree = account.MarginFree(),
            marginLevel = account.MarginLevel() / 100.0
          };
        }
        finally
        {
          if (account != null) account.Dispose();
        }

        CIMTPositionArray positionArray = _manager.PositionCreateArray();
        try
        {
          MTRetCode positionResult = _manager.PositionRequest(login, positionArray);
          if (positionResult != MTRetCode.MT_RET_OK && positionResult != MTRetCode.MT_RET_REPORT_NODATA)
          {
            RequireOk(positionResult, "PositionRequest " + login);
          }

          uint total = positionArray.Total();
          for (uint index = 0; index < total; index++)
          {
            CIMTPosition position = positionArray.Next(index);
            positions.Add(ToPosition(position));
          }
        }
        finally
        {
          if (positionArray != null) positionArray.Dispose();
        }
      }

      return positions;
    }

    private PositionDto ToPosition(CIMTPosition position)
    {
      uint action = Convert.ToUInt32(position.Action());
      return new PositionDto
      {
        ticket = position.Position(),
        login = position.Login(),
        symbol = position.Symbol(),
        action = action == 1 ? "SELL" : "BUY",
        volumeLots = SMTMath.VolumeToDouble(position.Volume()),
        openPrice = position.PriceOpen(),
        currentPrice = position.PriceCurrent(),
        contractSize = position.ContractSize(),
        swap = position.Storage(),
        commission = 0,
        profit = position.Profit(),
        profitCurrencyRateToAccount = position.RateProfit(),
        marginCurrencyRateToAccount = position.RateMargin()
      };
    }

    private void LoadSymbolsAndQuotes(List<PositionDto> positions, List<CIMTUser> users)
    {
      string[] symbolMasks = Clean(_request.mt5 == null ? null : _request.mt5.symbolMasks);
      HashSet<string> requestedSymbols = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
      foreach (PositionDto position in positions) requestedSymbols.Add(position.symbol);
      AddMappedSymbols(positions, requestedSymbols);

      if (requestedSymbols.Count == 0 && symbolMasks.Length > 0)
      {
        LoadSymbolMasks(symbolMasks, users.Count > 0 ? users[0].Group() : string.Empty, requestedSymbols);
      }

      bool loadQuotes = _request.mt5 == null || !_request.mt5.symbolListOnly;
      foreach (string symbol in requestedSymbols)
      {
        string group = GroupForSymbol(symbol, positions, users);
        LoadSymbol(symbol, group);
        if (loadQuotes) LoadQuote(symbol, group);
      }
    }

    private void AddMappedSymbols(List<PositionDto> positions, HashSet<string> requestedSymbols)
    {
      foreach (PositionDto position in positions)
      {
        bool explicitMappingMatched = false;
        if (_request.risk != null && _request.risk.symbolMappings != null)
        {
          foreach (KeyValuePair<string, SymbolMappingConfig> entry in _request.risk.symbolMappings)
          {
            if (!MaskMatches(position.symbol, entry.Key)) continue;
            explicitMappingMatched = true;
            SymbolMappingConfig mapping = entry.Value;
            AddIfNotEmpty(requestedSymbols, mapping.baseSymbol);
            AddIfNotEmpty(requestedSymbols, mapping.fxSymbol);
            AddIfNotEmpty(requestedSymbols, mapping.quoteSymbol);
          }
        }
        if (!explicitMappingMatched && DefaultSixCharMappingEnabled())
        {
          AddIfNotEmpty(requestedSymbols, DefaultBaseSymbol(position.symbol));
        }
      }
    }

    private bool DefaultSixCharMappingEnabled()
    {
      return _request.risk == null ||
        !_request.risk.defaultSixCharSymbolMapping.HasValue ||
        _request.risk.defaultSixCharSymbolMapping.Value;
    }

    private static string DefaultBaseSymbol(string symbol)
    {
      if (string.IsNullOrWhiteSpace(symbol)) return string.Empty;
      string normalized = symbol.Trim().ToUpperInvariant();
      int start = 0;
      while (start < normalized.Length && !char.IsLetterOrDigit(normalized[start])) start++;
      if (normalized.Length - start <= 6) return string.Empty;
      return normalized.Substring(start, 6);
    }

    private static void AddIfNotEmpty(HashSet<string> values, string value)
    {
      if (!string.IsNullOrWhiteSpace(value)) values.Add(value.Trim());
    }

    private void LoadSymbolMasks(string[] symbolMasks, string group, HashSet<string> requestedSymbols)
    {
      foreach (string mask in symbolMasks)
      {
        if (mask == "*" && string.IsNullOrEmpty(group))
        {
          LoadAllSymbols(requestedSymbols);
          continue;
        }
        CIMTConSymbolArray symbolArray = _manager.SymbolCreateArray();
        try
        {
          MTRetCode res = _manager.SymbolRequestArray(mask, group, symbolArray);
          if (res != MTRetCode.MT_RET_OK && res != MTRetCode.MT_RET_REPORT_NODATA) RequireOk(res, "SymbolRequestArray " + mask);
          uint total = symbolArray.Total();
          for (uint index = 0; index < total; index++)
          {
            CIMTConSymbol symbol = symbolArray.Next(index);
            requestedSymbols.Add(symbol.Symbol());
          }
        }
        finally
        {
          if (symbolArray != null) symbolArray.Dispose();
        }
      }
    }

    private void LoadAllSymbols(HashSet<string> requestedSymbols)
    {
      uint total = _manager.SymbolTotal();
      for (uint index = 0; index < total; index++)
      {
        CIMTConSymbol symbol = _manager.SymbolCreate();
        try
        {
          MTRetCode res = _manager.SymbolNext(index, symbol);
          if (res != MTRetCode.MT_RET_OK) continue;
          requestedSymbols.Add(symbol.Symbol());
        }
        finally
        {
          if (symbol != null) symbol.Dispose();
        }
      }
    }

    private string GroupForSymbol(string symbol, List<PositionDto> positions, List<CIMTUser> users)
    {
      PositionDto ownerPosition = positions.FirstOrDefault(position => string.Equals(position.symbol, symbol, StringComparison.OrdinalIgnoreCase));
      if (ownerPosition != null && _groupsByLogin.ContainsKey(ownerPosition.login)) return _groupsByLogin[ownerPosition.login];
      return users.Count > 0 ? users[0].Group() : string.Empty;
    }

    private void LoadSymbol(string name, string group)
    {
      if (_symbols.ContainsKey(name)) return;
      CIMTConSymbol symbol = _manager.SymbolCreate();
      try
      {
        MTRetCode res = string.IsNullOrEmpty(group)
          ? _manager.SymbolRequest(name, symbol)
          : _manager.SymbolRequest(name, group, symbol);
        if (res != MTRetCode.MT_RET_OK && !string.IsNullOrEmpty(group))
        {
          res = _manager.SymbolRequest(name, symbol);
        }
        if (res != MTRetCode.MT_RET_OK) RequireOk(res, "SymbolRequest " + name);

        double point = symbol.TickSize() > 0 ? symbol.TickSize() : Math.Pow(10, -Convert.ToInt32(symbol.Digits()));
        _symbols[name] = new SymbolDto
        {
          symbol = symbol.Symbol(),
          path = symbol.Path(),
          description = symbol.Description(),
          digits = symbol.Digits(),
          point = point,
          contractSize = symbol.ContractSize(),
          currencyProfit = symbol.CurrencyProfit(),
          currencyMargin = symbol.CurrencyMargin(),
          marginInitial = symbol.MarginInitial(),
          marginMaintenance = symbol.MarginMaintenance(),
          marginLong = symbol.MarginLong(),
          marginShort = symbol.MarginShort(),
          marginRateInitial = symbol.MarginRateInitial(0),
          calcMode = (uint)symbol.CalcMode(),
          calcModeName = symbol.CalcMode().ToString(),
          tradeCalcMode = (uint)symbol.CalcMode(),
          tradeCalcModeName = symbol.CalcMode().ToString(),
          swapMode = (uint)symbol.SwapMode(),
          swapModeName = symbol.SwapMode().ToString(),
          swapLong = symbol.SwapLong(),
          swapShort = symbol.SwapShort(),
          swap3Day = symbol.Swap3Day()
        };
      }
      finally
      {
        if (symbol != null) symbol.Dispose();
      }
    }

    private void LoadQuote(string symbol, string group)
    {
      MTTickShort tick;
      MTRetCode res = string.IsNullOrEmpty(group)
        ? _manager.TickLast(symbol, out tick)
        : _manager.TickLast(symbol, group, out tick);

      if (res != MTRetCode.MT_RET_OK)
      {
        _manager.SelectedAdd(symbol);
        res = string.IsNullOrEmpty(group)
          ? _manager.TickLast(symbol, out tick)
          : _manager.TickLast(symbol, group, out tick);
      }
      if (res != MTRetCode.MT_RET_OK && !string.IsNullOrEmpty(group))
      {
        res = _manager.TickLast(symbol, out tick);
      }
      if (res != MTRetCode.MT_RET_OK) RequireOk(res, "TickLast " + symbol);

      long milliseconds = tick.datetime_msc > 0 ? tick.datetime_msc : tick.datetime * 1000;
      _quotes[symbol] = new QuoteDto
      {
        symbol = symbol,
        bid = tick.bid,
        ask = tick.ask,
        last = tick.last,
        time = UnixMillisecondsToIso(milliseconds)
      };
    }

    private string GroupCurrency(string group)
    {
      if (string.IsNullOrEmpty(group)) return BaseCurrency();
      if (_groupCurrencies.ContainsKey(group)) return _groupCurrencies[group];

      CIMTConGroup groupConfig = _manager.GroupCreate();
      try
      {
        MTRetCode res = _manager.GroupRequest(group, groupConfig);
        string currency = res == MTRetCode.MT_RET_OK && !string.IsNullOrEmpty(groupConfig.Currency())
          ? groupConfig.Currency()
          : BaseCurrency();
        _groupCurrencies[group] = currency;
        return currency;
      }
      finally
      {
        if (groupConfig != null) groupConfig.Dispose();
      }
    }

    private string BaseCurrency()
    {
      return _request.mt5 == null || string.IsNullOrEmpty(_request.mt5.baseCurrency)
        ? DefaultCurrency
        : _request.mt5.baseCurrency;
    }

    private string ReadServerTime()
    {
      long timeMsc;
      MTRetCode res = _manager.TimeServerRequest(out timeMsc);
      if (res == MTRetCode.MT_RET_OK && timeMsc > 0) return UnixMillisecondsToIso(timeMsc);

      long seconds = _manager.TimeServer();
      if (seconds > 0) return UnixMillisecondsToIso(seconds * 1000);
      return null;
    }

    private static string UnixMillisecondsToIso(long milliseconds)
    {
      return DateTimeOffset.FromUnixTimeMilliseconds(milliseconds).UtcDateTime.ToString("yyyy-MM-dd HH:mm:ss");
    }

    private static string[] Clean(IEnumerable<string> values)
    {
      if (values == null) return new string[0];
      return values.Select(value => (value ?? string.Empty).Trim()).Where(value => value.Length > 0).ToArray();
    }

    private static ulong ToUlong(object value)
    {
      return Convert.ToUInt64(value);
    }

    private static bool MaskMatches(string value, string mask)
    {
      if (string.IsNullOrEmpty(mask) || mask == "*") return true;
      return MaskMatchesAt(value ?? string.Empty, 0, mask, 0);
    }

    private static bool MaskMatchesAt(string value, int valueIndex, string mask, int maskIndex)
    {
      while (maskIndex < mask.Length)
      {
        char token = char.ToUpperInvariant(mask[maskIndex]);
        if (token == '*')
        {
          while (maskIndex + 1 < mask.Length && mask[maskIndex + 1] == '*') maskIndex++;
          if (maskIndex + 1 == mask.Length) return true;
          for (int next = valueIndex; next <= value.Length; next++)
          {
            if (MaskMatchesAt(value, next, mask, maskIndex + 1)) return true;
          }
          return false;
        }
        if (valueIndex >= value.Length) return false;
        char current = char.ToUpperInvariant(value[valueIndex]);
        if (token != '?' && token != current) return false;
        valueIndex++;
        maskIndex++;
      }
      return valueIndex == value.Length;
    }

    private static void RequireOk(MTRetCode code, string operation)
    {
      if (code == MTRetCode.MT_RET_OK) return;
      throw new InvalidOperationException(operation + " failed: " + code);
    }
  }

  public sealed class SnapshotRequest
  {
    public ServerConfig server { get; set; }
    public Mt5Config mt5 { get; set; }
    public RiskConfig risk { get; set; }
  }

  public sealed class ServerConfig
  {
    public string name { get; set; }
    public string host { get; set; }
    public int port { get; set; }
    public object login { get; set; }
    public string password { get; set; }
    public int timeoutMs { get; set; }
  }

  public sealed class Mt5Config
  {
    public string[] groupMasks { get; set; }
    public string[] symbolMasks { get; set; }
    public string[] accountLogins { get; set; }
    public string baseCurrency { get; set; }
    public int serverTimeOffsetMinutes { get; set; }
    public bool symbolListOnly { get; set; }
  }

  public sealed class RiskConfig
  {
    public Dictionary<string, SymbolMappingConfig> symbolMappings { get; set; }
    public bool? defaultSixCharSymbolMapping { get; set; }
  }

  public sealed class SymbolMappingConfig
  {
    public string baseSymbol { get; set; }
    public string fxSymbol { get; set; }
    public string quoteSymbol { get; set; }
  }

  public sealed class SnapshotResponse
  {
    public string serverTime { get; set; }
    public List<AccountDto> accounts { get; set; }
    public List<PositionDto> positions { get; set; }
    public List<SymbolDto> symbols { get; set; }
    public List<QuoteDto> quotes { get; set; }
  }

  public sealed class AccountDto
  {
    public ulong login { get; set; }
    public string group { get; set; }
    public string currency { get; set; }
    public double balance { get; set; }
    public double credit { get; set; }
    public uint leverage { get; set; }
    public uint? marginLeverage { get; set; }
    public uint? staticLeverage { get; set; }
    public string leverageSource { get; set; }
    public double equity { get; set; }
    public double margin { get; set; }
    public double marginFree { get; set; }
    public double marginLevel { get; set; }
  }

  public sealed class PositionDto
  {
    public ulong ticket { get; set; }
    public ulong login { get; set; }
    public string symbol { get; set; }
    public string action { get; set; }
    public double volumeLots { get; set; }
    public double openPrice { get; set; }
    public double currentPrice { get; set; }
    public double contractSize { get; set; }
    public double swap { get; set; }
    public double commission { get; set; }
    public double profit { get; set; }
    public double profitCurrencyRateToAccount { get; set; }
    public double marginCurrencyRateToAccount { get; set; }
  }

  public sealed class SymbolDto
  {
    public string symbol { get; set; }
    public string path { get; set; }
    public string description { get; set; }
    public uint digits { get; set; }
    public double point { get; set; }
    public double contractSize { get; set; }
    public string currencyProfit { get; set; }
    public string currencyMargin { get; set; }
    public double marginInitial { get; set; }
    public double marginMaintenance { get; set; }
    public double marginLong { get; set; }
    public double marginShort { get; set; }
    public double marginRateInitial { get; set; }
    public uint calcMode { get; set; }
    public string calcModeName { get; set; }
    public uint tradeCalcMode { get; set; }
    public string tradeCalcModeName { get; set; }
    public uint swapMode { get; set; }
    public string swapModeName { get; set; }
    public double swapLong { get; set; }
    public double swapShort { get; set; }
    public int swap3Day { get; set; }
  }

  public sealed class QuoteDto
  {
    public string symbol { get; set; }
    public double bid { get; set; }
    public double ask { get; set; }
    public double last { get; set; }
    public string time { get; set; }
  }
}
