import { useMemo, useState, type ReactNode } from 'react';
import { Filter, List, X } from 'lucide-react';
import { AlertConditionEditor, NotificationCooldownEditor } from '@/components/ConfigEditors';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/hooks/use-toast';
import { directionLabel, useI18n } from '@/i18n';
import {
  cn,
  formatNumber,
  formatPrice,
  marginLevelPercent,
  percentToRatio,
  ratioToPercent,
} from '@/lib/utils';
import type {
  AlertConditionExpression,
  AppConfig,
  PositionDetail,
  RiskReport,
  RiskResult,
  RiskTableRow,
  SymbolExposure,
  SymbolRisk,
} from '@/types/api';

function buildRows(result: RiskResult | null): RiskTableRow[] {
  if (!result) return [];
  const rows = (result.reports || [])
    .flatMap((report) => {
      const exposures = report.symbolExposures?.length
        ? report.symbolExposures
        : report.dashboardExposure
          ? [report.dashboardExposure]
          : [];
      return exposures.map((exposure) => {
        const risk =
          exposure?.risk ||
          report.symbolRisks.find((item) => item.symbol === exposure.symbol) ||
          null;
        const quote =
          risk?.quote ||
          exposure?.risk?.quote ||
          (exposure as SymbolExposure & { quote?: SymbolRisk['quote'] }).quote;
        const componentSymbols = Array.from(
          new Set((exposure?.components || []).map((component) => component.symbol).filter(Boolean)),
        );
        const dangerDistancePoints = risk?.dangerDistancePoints ?? risk?.alertDistancePoints ?? 0;
        const warningDistancePoints = risk?.warningDistancePoints ?? (dangerDistancePoints > 0 ? dangerDistancePoints * 2 : 0);
        const alertDistancePoints = dangerDistancePoints;
        const distancePoints = risk?.distancePoints ?? Number.POSITIVE_INFINITY;
        const riskLevel = riskLevelFromBackend(risk);

        return {
          id: `${report.account?.login ?? '—'}:${exposure?.symbol || risk?.symbol || 'none'}`,
          login: report.account?.login ?? '—',
          group: report.account?.group ?? '',
          equity: report.equity,
          margin: report.margin,
          leverage: report.account?.leverage,
          marginLevel: report.marginLevel,
          stopOutLevel: report.stopOutLevel,
          symbol: exposure?.symbol || risk?.symbol || '—',
          componentSymbols,
          direction: risk?.direction || '—',
          netDirection: exposure?.netDirection || '—',
          buyLots: exposure?.buyLots || risk?.buyLots || 0,
          sellLots: exposure?.sellLots || risk?.sellLots || 0,
          grossLots: exposure?.grossLots || 0,
          netLots: exposure?.netLots || 0,
          averageOpenPrice:
            exposure?.netAverageOpenPrice ||
            exposure?.averageOpenPrice ||
            risk?.averageOpenPrice ||
            0,
          contractSize: exposure?.contractSize || 0,
          pointValuePerLotAccount: exposure?.pointValuePerLotAccount || 0,
          netPointValueAccount: exposure?.netPointValueAccount || 0,
          positionCount: exposure?.positionCount || 0,
          bid: quote?.bid ?? 0,
          ask: quote?.ask ?? 0,
          liquidationPrice: risk?.liquidationPrice ?? 0,
          distancePoints,
          alertDistancePoints,
          warningDistancePoints,
          dangerDistancePoints,
          shouldAlert: risk?.shouldAlert || false,
          convertedPrices: risk?.convertedPrices || [],
          riskLevel,
        };
      });
    })
    .sort((left, right) => left.distancePoints - right.distancePoints);
  return unifyRowsByAccountRisk(rows);
}

function unifyRowsByAccountRisk(rows: RiskTableRow[]): RiskTableRow[] {
  const riskByLogin = new Map<string, RiskTableRow['riskLevel']>();
  for (const row of rows) {
    const login = String(row.login);
    const current = riskByLogin.get(login) || 'normal';
    if (riskSeverity(row.riskLevel) > riskSeverity(current)) {
      riskByLogin.set(login, row.riskLevel);
    } else if (!riskByLogin.has(login)) {
      riskByLogin.set(login, current);
    }
  }
  return rows.map((row) => ({
    ...row,
    riskLevel: riskByLogin.get(String(row.login)) || row.riskLevel,
  }));
}

function riskSeverity(level: RiskTableRow['riskLevel']) {
  if (level === 'critical') return 2;
  if (level === 'warning') return 1;
  return 0;
}

type ProductRiskRow = RiskTableRow & {
  accountCount: number;
  sourceLogins: Array<string | number>;
};

function buildProductRows(rows: RiskTableRow[], config: AppConfig | null): ProductRiskRow[] {
  const bySymbol = new Map<string, ProductRiskRow>();
  const clientRows = rows.filter((row) => !isLpRiskRow(row, config));
  for (const row of clientRows) {
    const current = bySymbol.get(row.symbol);
    if (!current) {
      bySymbol.set(row.symbol, {
        ...row,
        accountCount: 1,
        sourceLogins: [row.login],
      });
      continue;
    }
    const sourceLogins = Array.from(new Set([...current.sourceLogins, row.login]));
    const signedNetLots =
      signedLotsByDirection(current.netDirection, current.netLots) +
      signedLotsByDirection(row.netDirection, row.netLots);
    const betterDistance = row.distancePoints < current.distancePoints;
    const riskLevel =
      riskSeverity(row.riskLevel) > riskSeverity(current.riskLevel)
        ? row.riskLevel
        : current.riskLevel;
    bySymbol.set(row.symbol, {
      ...current,
      login: betterDistance ? row.login : current.login,
      group: betterDistance ? row.group : current.group,
      componentSymbols: Array.from(new Set([...(current.componentSymbols || []), ...(row.componentSymbols || [])])),
      buyLots: current.buyLots + row.buyLots,
      sellLots: current.sellLots + row.sellLots,
      grossLots: current.grossLots + row.grossLots,
      netLots: Math.abs(signedNetLots),
      positionCount: current.positionCount + row.positionCount,
      netDirection: signedNetLots > 1e-9 ? 'BUY' : signedNetLots < -1e-9 ? 'SELL' : 'FLAT',
      liquidationPrice: betterDistance ? row.liquidationPrice : current.liquidationPrice,
      averageOpenPrice: betterDistance ? row.averageOpenPrice : current.averageOpenPrice,
      convertedPrices: betterDistance ? row.convertedPrices : current.convertedPrices,
      distancePoints: Math.min(current.distancePoints, row.distancePoints),
      warningDistancePoints: Math.max(Number(current.warningDistancePoints || 0), Number(row.warningDistancePoints || 0)),
      dangerDistancePoints: Math.max(Number(current.dangerDistancePoints || 0), Number(row.dangerDistancePoints || 0)),
      alertDistancePoints: Math.max(Number(current.alertDistancePoints || 0), Number(row.alertDistancePoints || 0)),
      shouldAlert: current.shouldAlert || row.shouldAlert,
      riskLevel,
      accountCount: sourceLogins.length,
      sourceLogins,
    });
  }
  return [...bySymbol.values()].sort((left, right) => left.distancePoints - right.distancePoints);
}

function isLpRiskRow(row: RiskTableRow, config: AppConfig | null) {
  return isLpIdentity(row.login, row.group, config);
}

function isLpReport(report: RiskReport, config: AppConfig | null) {
  return isLpIdentity(report.account?.login, report.account?.group, config);
}

function isLpIdentity(loginValue: unknown, groupValue: unknown, config: AppConfig | null) {
  const login = String(loginValue ?? '').trim().toUpperCase();
  const group = String(groupValue ?? '').trim().toUpperCase();
  const configuredName = String(config?.lpAccount?.name ?? '').trim().toUpperCase();
  if (configuredName && login === configuredName) return true;
  if (group === 'LP') return true;
  return login.startsWith('LP');
}

function signedLotsByDirection(direction: string, lots: number) {
  if (direction === 'BUY') return Math.abs(Number(lots || 0));
  if (direction === 'SELL') return -Math.abs(Number(lots || 0));
  return 0;
}

function riskLevelFromBackend(risk?: SymbolRisk | null): RiskTableRow['riskLevel'] {
  if (!risk) return 'normal';
  if (risk.severity === 'danger' || risk.shouldAlert) return 'critical';
  if (risk.severity === 'warning') return 'warning';
  return 'normal';
}

function accountRiskLevel(report: RiskReport): RiskTableRow['riskLevel'] {
  let level: RiskTableRow['riskLevel'] = 'normal';
  for (const risk of report.symbolRisks || []) {
    const next = riskLevelFromBackend(risk);
    if (riskSeverity(next) > riskSeverity(level)) level = next;
  }
  for (const exposure of report.symbolExposures || []) {
    const next = riskLevelFromBackend(exposure.risk);
    if (riskSeverity(next) > riskSeverity(level)) level = next;
  }
  return level;
}

function MarginLevelBar({ level, riskLevel }: { level: number; riskLevel?: string }) {
  const pct = marginLevelPercent(level);
  const isDanger = riskLevel === 'critical';
  const isWarning = riskLevel === 'warning' && !isDanger;
  const width = Math.min(Math.max(level * 50, 5), 100);

  return (
    <div className="flex w-24 flex-col gap-1">
      <span
        className={cn(
          'text-right text-xs font-bold tabular-nums',
          isDanger ? 'text-red-500' : isWarning ? 'text-amber-400' : 'text-zinc-300',
        )}
      >
        {Number.isFinite(pct) ? pct.toFixed(2) : 'INF'}%
      </span>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-zinc-800">
        <div
          className={cn(
            'h-full rounded-full transition-all duration-500',
            isDanger
              ? 'animate-pulse-fast bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]'
              : isWarning
                ? 'bg-amber-500'
                : 'bg-emerald-500',
          )}
          style={{ width: `${width}%` }}
        />
      </div>
    </div>
  );
}

interface RiskTableProps {
  result: RiskResult | null;
  pollInFlight?: boolean;
  config: AppConfig | null;
  saving: boolean;
  onSaveConfig: (config: AppConfig) => Promise<unknown>;
}

export function RiskTable({ result, config, saving, onSaveConfig }: RiskTableProps) {
  const { t } = useI18n();
  const rows = useMemo(() => buildRows(result), [result]);
  const productRows = useMemo(() => buildProductRows(rows, config), [rows, config]);
  const reportByLogin = useMemo(() => {
    const map = new Map<string, RiskReport>();
    for (const report of result?.reports || []) map.set(String(report.account?.login ?? ''), report);
    return map;
  }, [result]);
  const [selectedLogin, setSelectedLogin] = useState<string | null>(null);
  const [selectedProductSymbol, setSelectedProductSymbol] = useState<string | null>(null);
  const [displayMode, setDisplayMode] = useState<'account' | 'product'>('account');
  const selected = selectedLogin ? reportByLogin.get(selectedLogin) || null : null;
  const selectedProduct = selectedProductSymbol
    ? productRows.find((row) => row.symbol === selectedProductSymbol) || null
    : null;

  return (
    <>
      <section className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-md border border-zinc-800 bg-zinc-900 shadow-2xl">
        <div className="flex shrink-0 items-center justify-between border-b border-zinc-800 bg-zinc-900 px-4 py-3">
          <div>
            <h2 className="text-sm font-semibold text-zinc-200">
              {t('实时风险敞口', 'Real-time Risk Exposure')}
              <span className="ml-2 text-xs font-normal text-zinc-500">{t('(点击任意行可查看单子明细)', '(click any row to view positions)')}</span>
            </h2>
            <p className="mt-1 text-[10px] font-mono text-zinc-500">{t('最近同步', 'Last sync')} {formatSyncTime(result?.checkedAt)}</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="rounded-md border border-zinc-800 bg-zinc-950 p-0.5">
              <button
                type="button"
                onClick={() => setDisplayMode('account')}
                className={cn('rounded px-2 py-1 text-[11px]', displayMode === 'account' ? 'bg-zinc-800 text-zinc-100' : 'text-zinc-500 hover:text-zinc-300')}
              >
                {t('按账号', 'By Account')}
              </button>
              <button
                type="button"
                onClick={() => setDisplayMode('product')}
                className={cn('rounded px-2 py-1 text-[11px]', displayMode === 'product' ? 'bg-zinc-800 text-zinc-100' : 'text-zinc-500 hover:text-zinc-300')}
              >
                {t('按产品', 'By Product')}
              </button>
            </div>
            <Badge variant={rows.length ? 'success' : 'outline'}>
              {rows.length ? t(`${displayMode === 'product' ? productRows.length : rows.length} 条`, `${displayMode === 'product' ? productRows.length : rows.length} rows`) : t('无数据', 'No data')}
            </Badge>
          </div>
        </div>
        <div className="flex-1 overflow-auto scrollbar-thin">
          {!rows.length ? (
            <div className="flex h-48 items-center justify-center text-xs text-zinc-500">
              {t('启动轮询或等待自动同步以加载风险数据', 'Start monitoring or wait for auto-sync to load risk data')}
            </div>
          ) : displayMode === 'product' ? (
            <ProductModeTable rows={productRows} onSelect={(row) => setSelectedProductSymbol(row.symbol)} />
          ) : (
            <table className="w-full whitespace-nowrap text-left text-sm text-zinc-400">
              <thead className="sticky top-0 z-10 bg-zinc-950 text-xs uppercase text-zinc-500 shadow-sm">
                <tr>
                  <th className="px-4 py-3 font-medium">{t('账号', 'Login')}</th>
                  <th className="px-4 py-3 font-medium">{t('组', 'Group')}</th>
                  <th className="px-4 py-3 text-right font-medium">{t('净值/预付款', 'Equity / Margin')}</th>
                  <th className="px-4 py-3 text-right font-medium">{t('预付款比例', 'Margin Level')}</th>
                  <th className="px-4 py-3 font-medium">{t('产品', 'Symbol')}</th>
                  <th className="px-4 py-3 text-center font-medium">{t('净头寸方向', 'Net Direction')}</th>
                  <th className="px-4 py-3 text-right font-medium">{t('买单/卖单手数', 'Buy / Sell Lots')}</th>
                  <th className="px-4 py-3 text-right font-medium">{t('开仓/爆仓价格', 'Open / Liquidation Price')}</th>
                  <th className="px-4 py-3 text-right font-medium">{t('爆仓/告警(pip)', 'Liquidation / Alert (pip)')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50">
                {rows.map((row) => {
                  const report = reportByLogin.get(String(row.login)) || null;
                  const isDanger = row.riskLevel === 'critical';
                  const isWarning = row.riskLevel === 'warning';
                  const riskTextClass = isDanger
                    ? 'text-red-400'
                    : isWarning
                      ? 'text-amber-400'
                      : 'text-emerald-400';
                  return (
                    <tr
                      key={row.id}
                      onClick={() => report && setSelectedLogin(String(report.account?.login ?? row.login))}
                      className={cn(
                        'group cursor-pointer transition-colors hover:bg-zinc-800',
                        isDanger && 'bg-red-950/20',
                        isWarning && !isDanger && 'bg-amber-950/10',
                      )}
                    >
                      <td className="px-4 py-4 tabular-nums group-hover:underline">
                        <div className={cn('font-bold', riskTextClass)}>{row.login}</div>
                        <div className="mt-1 text-[10px] font-medium text-zinc-500">
                          {t('实时杠杆', 'Live leverage')} {formatLeverage(row.leverage)}
                        </div>
                      </td>
                      <td className="px-4 py-4 text-xs">{row.group}</td>
                      <td className="px-4 py-4 text-right tabular-nums">
                        <span className="text-zinc-200">${formatNumber(row.equity)}</span>
                        <span className="mx-1 text-zinc-600">/</span>
                        <span className="text-zinc-500">${formatNumber(row.margin)}</span>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex justify-end">
                          <MarginLevelBar level={row.marginLevel} riskLevel={row.riskLevel} />
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="font-medium text-zinc-300">{row.symbol}</div>
                        {row.componentSymbols && row.componentSymbols.length > 1 && (
                          <div className="mt-1 text-[10px] text-zinc-500">
                            {t('含', 'Includes')} {row.componentSymbols.join(' / ')}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-4 text-center">
                        <NetDirectionBadge direction={row.netDirection} />
                      </td>
                      <td className="px-4 py-4 text-right text-xs tabular-nums">
                        <span className="text-emerald-400">{formatNumber(row.buyLots, 2)}</span>
                        <span className="mx-1 text-zinc-600">/</span>
                        <span className="text-red-400">{formatNumber(row.sellLots, 2)}</span>
                      </td>
                      <td className="px-4 py-4 text-right tabular-nums">
                        <PriceStack
                          prices={(row as RiskTableRow & { convertedPrices?: SymbolRisk['convertedPrices'] }).convertedPrices}
                          fallbackOpen={row.averageOpenPrice}
                          fallbackLiquidation={row.liquidationPrice}
                        />
                      </td>
                      <td className="px-4 py-4 text-right">
                        <RiskDistanceBadge row={row} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </section>
      <AccountDetailDrawer
        report={selected}
        config={config}
        saving={saving}
        onSaveConfig={onSaveConfig}
        checkedAt={result?.checkedAt || null}
        onClose={() => setSelectedLogin(null)}
      />
      <ProductPositionsDrawer
        product={selectedProduct}
        result={result}
        config={config}
        checkedAt={result?.checkedAt || null}
        onClose={() => setSelectedProductSymbol(null)}
      />
    </>
  );
}

function NetDirectionBadge({ direction }: { direction: string }) {
  const { language } = useI18n();
  const variant = direction === 'BUY' ? 'success' : direction === 'SELL' ? 'destructive' : 'outline';
  return (
    <Badge variant={variant}>
      {directionLabel(direction, language)}
    </Badge>
  );
}

function ProductModeTable({
  rows,
  onSelect,
}: {
  rows: ProductRiskRow[];
  onSelect: (row: ProductRiskRow) => void;
}) {
  const { t } = useI18n();
  return (
    <table className="w-full whitespace-nowrap text-left text-sm text-zinc-400">
      <thead className="sticky top-0 z-10 bg-zinc-950 text-xs uppercase text-zinc-500 shadow-sm">
        <tr>
          <th className="px-4 py-3 font-medium">{t('产品', 'Symbol')}</th>
          <th className="px-4 py-3 text-right font-medium">{t('账号数', 'Accounts')}</th>
          <th className="px-4 py-3 text-center font-medium">{t('净头寸方向', 'Net Direction')}</th>
          <th className="px-4 py-3 text-right font-medium">{t('买单/卖单手数', 'Buy / Sell Lots')}</th>
          <th className="px-4 py-3 text-right font-medium">{t('净手数', 'Net Lots')}</th>
          <th className="px-4 py-3 text-right font-medium">{t('最近账号', 'Nearest Account')}</th>
          <th className="px-4 py-3 text-right font-medium">{t('开仓/爆仓价格', 'Open / Liquidation Price')}</th>
          <th className="px-4 py-3 text-right font-medium">{t('爆仓/告警(pip)', 'Liquidation / Alert (pip)')}</th>
        </tr>
      </thead>
      <tbody className="divide-y divide-zinc-800/50">
        {rows.map((row) => {
          const isDanger = row.riskLevel === 'critical';
          const isWarning = row.riskLevel === 'warning';
          return (
            <tr
              key={row.symbol}
              onClick={() => onSelect(row)}
              className={cn(
                'group cursor-pointer transition-colors hover:bg-zinc-800',
                isDanger && 'bg-red-950/20',
                isWarning && !isDanger && 'bg-amber-950/10',
              )}
            >
              <td className="px-4 py-4">
                <div className="font-bold text-zinc-200 group-hover:underline">{row.symbol}</div>
                {row.componentSymbols && row.componentSymbols.length > 1 && (
                  <div className="mt-1 text-[10px] text-zinc-500">{t('含', 'Includes')} {row.componentSymbols.join(' / ')}</div>
                )}
              </td>
              <td className="px-4 py-4 text-right font-mono text-zinc-300">{row.accountCount}</td>
              <td className="px-4 py-4 text-center"><NetDirectionBadge direction={row.netDirection} /></td>
              <td className="px-4 py-4 text-right text-xs tabular-nums">
                <span className="text-emerald-400">{formatNumber(row.buyLots, 2)}</span>
                <span className="mx-1 text-zinc-600">/</span>
                <span className="text-red-400">{formatNumber(row.sellLots, 2)}</span>
              </td>
              <td className="px-4 py-4 text-right font-mono text-xs text-zinc-300">{formatNumber(row.netLots, 2)}</td>
              <td className="px-4 py-4 text-right font-mono text-xs">
                <span className={cn(isDanger ? 'text-red-400' : isWarning ? 'text-amber-400' : 'text-zinc-300')}>{row.login}</span>
              </td>
              <td className="px-4 py-4 text-right tabular-nums">
                <PriceStack
                  prices={row.convertedPrices}
                  fallbackOpen={row.averageOpenPrice}
                  fallbackLiquidation={row.liquidationPrice}
                />
              </td>
              <td className="px-4 py-4 text-right"><RiskDistanceBadge row={row} /></td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}

function PriceStack({
  prices,
  fallbackOpen,
  fallbackLiquidation,
}: {
  prices?: SymbolRisk['convertedPrices'];
  fallbackOpen: number;
  fallbackLiquidation: number;
}) {
  const rows = prices && prices.length ? prices : [
    { symbol: '', openPrice: fallbackOpen, currentPrice: fallbackOpen, liquidationPrice: fallbackLiquidation, distancePoints: 0, point: 0 },
  ];
  return (
    <div className="space-y-0.5">
      {rows.slice(0, 3).map((price) => {
        const digits = digitsFromPoint(price.point);
        const openPrice = price.openPrice ?? price.currentPrice ?? fallbackOpen;
        return (
          <div key={price.symbol || 'base'} className="text-right text-[11px]">
            {price.symbol && <span className="mr-1 text-zinc-500">{price.symbol}</span>}
            <span className="text-zinc-300">{formatPrice(openPrice, digits)}</span>
            <span className="mx-1 text-zinc-600">→</span>
            <span className="text-zinc-500">
              {price.liquidationPrice ? formatPrice(price.liquidationPrice, digits) : '—'}
            </span>
          </div>
        );
      })}
    </div>
  );
}

function RiskDistanceBadge({ row }: { row: RiskTableRow }) {
  const { t } = useI18n();
  const isDanger = row.riskLevel === 'critical';
  const isWarning = row.riskLevel === 'warning';
  const distance = Number.isFinite(row.distancePoints)
    ? Math.round(row.distancePoints).toLocaleString()
    : '—';
  const warning = Number(row.warningDistancePoints || 0);
  const danger = Number(row.dangerDistancePoints || row.alertDistancePoints || 0);

  return (
    <div className="flex flex-col items-end gap-1">
      <span
        className={cn(
          'inline-flex min-w-[60px] items-center justify-center rounded-md px-2.5 py-1 text-xs font-bold tabular-nums',
          isDanger
            ? 'animate-pulse-fast bg-red-500 text-white shadow-[0_0_10px_rgba(239,68,68,0.4)]'
            : isWarning
              ? 'bg-amber-500/20 text-amber-300'
              : 'bg-zinc-800 text-zinc-300',
        )}
      >
        {distance}
      </span>
      <span className="text-[10px] tabular-nums text-zinc-600">
        <span className={cn(warning > 0 && 'text-amber-400')}>{t('注意', 'Warning')} {warning > 0 ? Math.round(warning).toLocaleString() : '—'}</span>
        <span className="mx-1">/</span>
        <span className={cn(danger > 0 && 'text-red-400')}>{t('危险', 'Danger')} {danger > 0 ? Math.round(danger).toLocaleString() : '—'}</span>
      </span>
    </div>
  );
}

function digitsFromPoint(point: unknown) {
  const value = Number(point);
  if (!Number.isFinite(value) || value <= 0) return 5;
  return Math.min(8, Math.max(0, Math.ceil(Math.abs(Math.log10(value)))));
}

function formatLeverage(leverage: unknown) {
  const value = Number(leverage);
  if (!Number.isFinite(value) || value <= 0) return '—';
  return `1:${formatNumber(value, 0)}`;
}

function formatSyncTime(value?: string | null) {
  if (!value) return '—';
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return '—';
  return date.toLocaleTimeString('zh-CN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
}

function profitSourceLabel(position: PositionDetail, t: (zh: string, en: string) => string) {
  return position.profitSource === 'MT5_POSITION_PROFIT' ? 'MT5' : t('计算', 'Calculated');
}

function formatPositionQuote(position: PositionDetail, t: (zh: string, en: string) => string) {
  const bid = Number(position.quoteBid);
  const ask = Number(position.quoteAsk);
  if (!Number.isFinite(bid) && !Number.isFinite(ask)) return '';
  return `${t('卖价', 'Bid')} ${Number.isFinite(bid) ? formatPrice(bid) : '—'} / ${t('买价', 'Ask')} ${Number.isFinite(ask) ? formatPrice(ask) : '—'}`;
}

function ProductPositionsDrawer({
  product,
  result,
  config,
  checkedAt,
  onClose,
}: {
  product: ProductRiskRow | null;
  result: RiskResult | null;
  config: AppConfig | null;
  checkedAt: string | null;
  onClose: () => void;
}) {
  const { t } = useI18n();
  const positions = useMemo(
    () => collectProductPositions(result, product, config),
    [result, product, config],
  );

  if (!product) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <button
        type="button"
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        aria-label={t('关闭产品持仓明细', 'Close product position detail')}
        onClick={onClose}
      />
      <aside className="animate-slide-in relative flex h-full w-[min(96vw,1180px)] max-w-full flex-col border-l border-zinc-800 bg-zinc-950 shadow-2xl">
        <div className="flex h-20 shrink-0 items-center justify-between border-b border-zinc-800 bg-zinc-900 px-6">
          <div className="flex items-center gap-3">
            <List className="h-5 w-5 text-emerald-400" />
            <div>
              <h2 className="text-xl font-bold tracking-wide text-white">{product.symbol}</h2>
              <p className="text-xs text-zinc-500">
                {t(`${positions.length} 笔持仓`, `${positions.length} positions`)}
                <span className="mx-2 text-zinc-700">/</span>
                {t('最近同步', 'Last Sync')} {formatSyncTime(checkedAt)}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-2 text-zinc-400 transition-colors hover:bg-zinc-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 scrollbar-thin">
          <PositionsTable positions={positions} showLogin />
        </div>
      </aside>
    </div>
  );
}

function collectProductPositions(
  result: RiskResult | null,
  product: ProductRiskRow | null,
  config: AppConfig | null,
): PositionDetail[] {
  if (!result || !product) return [];
  const targetSymbol = normalizeSymbolForMatch(product.symbol);
  const matchedSymbols = new Set(
    [product.symbol, ...(product.componentSymbols || [])]
      .map(normalizeSymbolForMatch)
      .filter(Boolean),
  );

  return (result.reports || []).flatMap((report) => {
    if (isLpReport(report, config)) return [];
    return normalizePositions(report).filter((position) => {
      const symbol = normalizeSymbolForMatch(position.symbol);
      const canonical = normalizeSymbolForMatch(position.canonicalSymbol);
      return (
        symbol === targetSymbol ||
        canonical === targetSymbol ||
        matchedSymbols.has(symbol) ||
        matchedSymbols.has(canonical)
      );
    });
  });
}

function normalizeSymbolForMatch(value: unknown) {
  return String(value ?? '').trim().toUpperCase();
}

function AccountDetailDrawer({
  report,
  config,
  saving,
  onSaveConfig,
  checkedAt,
  onClose,
}: {
  report: RiskReport | null;
  config: AppConfig | null;
  saving: boolean;
  onSaveConfig: (config: AppConfig) => Promise<unknown>;
  checkedAt: string | null;
  onClose: () => void;
}) {
  const { t } = useI18n();
  const [activeTab, setActiveTab] = useState<'positions' | 'exposure' | 'config'>('positions');
  if (!report) return null;
  const account = report.account;
  const positions = normalizePositions(report);
  const detailRiskLevel = accountRiskLevel(report);

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <button
        type="button"
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        aria-label={t('关闭账号详情', 'Close account detail')}
        onClick={onClose}
      />
      <aside className="animate-slide-in relative flex h-full w-[min(96vw,1180px)] max-w-full flex-col border-l border-zinc-800 bg-zinc-950 shadow-2xl">
        <div className="flex h-20 shrink-0 items-center justify-between border-b border-zinc-800 bg-zinc-900 px-6">
          <div className="flex items-center gap-6">
            <div>
              <h2 className="text-xl font-bold tabular-nums tracking-wide text-white">{account?.login ?? '—'}</h2>
              <p className="text-xs font-medium uppercase text-zinc-500">{account?.group ?? ''}</p>
            </div>
            <div className="h-8 w-px bg-zinc-800" />
            <HeaderMetric label={t('净值', 'Equity')} value={`$${formatNumber(report.equity)}`} />
            <HeaderMetric label={t('预付款', 'Margin')} value={`$${formatNumber(report.margin)}`} />
            <HeaderMetric label={t('实时杠杆', 'Live Leverage')} value={formatLeverage(account?.leverage)} />
            <HeaderMetric label={t('最近同步', 'Last Sync')} value={formatSyncTime(checkedAt)} />
            <HeaderMetric
              label={t('爆仓比例', 'Stop-out Ratio')}
              value={`${formatNumber(report.stopOutLevel * 100, 2)}%`}
              danger={detailRiskLevel === 'critical'}
            />
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-2 text-zinc-400 transition-colors hover:bg-zinc-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex shrink-0 gap-4 border-b border-zinc-800 bg-zinc-900/50 px-6">
          <DrawerTab
            active={activeTab === 'positions'}
            onClick={() => setActiveTab('positions')}
            icon={<List className="h-4 w-4" />}
          >
            {t('持仓明细', 'Positions')}
          </DrawerTab>
          <DrawerTab
            active={activeTab === 'exposure'}
            onClick={() => setActiveTab('exposure')}
            icon={<Filter className="h-4 w-4" />}
          >
            {t('敞口测算', 'Exposure')}
          </DrawerTab>
          <DrawerTab
            active={activeTab === 'config'}
            onClick={() => setActiveTab('config')}
            icon={<Filter className="h-4 w-4" />}
          >
            {t('账号配置', 'Account Settings')}
          </DrawerTab>
        </div>

        <div className="flex-1 overflow-y-auto p-6 scrollbar-thin">
          {activeTab === 'positions' ? (
            <PositionsTable positions={positions} />
          ) : activeTab === 'exposure' ? (
            <ExposureTable exposures={report.symbolExposures || []} />
          ) : (
            <AccountRiskConfig report={report} config={config} saving={saving} onSaveConfig={onSaveConfig} />
          )}
        </div>
      </aside>
    </div>
  );
}

function AccountRiskConfig({
  report,
  config,
  saving,
  onSaveConfig,
}: {
  report: RiskReport;
  config: AppConfig | null;
  saving: boolean;
  onSaveConfig: (config: AppConfig) => Promise<unknown>;
}) {
  const { t } = useI18n();
  const login = String(report.account?.login ?? '');
  const override = config?.risk?.accountOverrides?.[login] || {};
  const [stopOutPercent, setStopOutPercent] = useState(
    String(ratioToPercent(override.stopOutLevel ?? report.stopOutLevel ?? 0.5)),
  );
  const [warningDistancePoints, setWarningDistancePoints] = useState(
    String(override.warningDistancePoints ?? config?.risk?.warningDistancePointsDefault ?? ''),
  );
  const [dangerDistancePoints, setDangerDistancePoints] = useState(
    String(override.dangerDistancePoints ?? config?.risk?.dangerDistancePointsDefault ?? config?.risk?.alertDistancePointsDefault ?? ''),
  );
  const [conditions, setConditions] = useState<AlertConditionExpression>(
    override.alertConditions || defaultAccountConditions(),
  );
  const [cooldown, setCooldown] = useState(
    override.cooldown || config?.notifications?.cooldown || defaultCooldown(),
  );

  if (!config) {
    return <div className="rounded-md border border-zinc-800 bg-zinc-900 p-8 text-sm text-zinc-500">{t('配置尚未加载', 'Configuration is not loaded')}</div>;
  }

  const save = async () => {
    const next = {
      ...config,
      risk: {
        ...config.risk,
        accountOverrides: {
          ...(config.risk.accountOverrides || {}),
          [login]: {
            ...override,
            stopOutLevel: percentToRatio(stopOutPercent, report.stopOutLevel * 100),
            warningDistancePoints: Number(warningDistancePoints) || undefined,
            dangerDistancePoints: Number(dangerDistancePoints) || undefined,
            alertConditions: conditions,
            cooldown,
          },
        },
      },
    };
    try {
      await onSaveConfig(next);
      toast({ title: t('账号配置已保存', 'Account settings saved'), description: t(`账号 ${login} 的风险规则已更新。`, `Risk rules for account ${login} have been updated.`) });
    } catch (error) {
      toast({
        title: t('账号配置保存失败', 'Failed to save account settings'),
        description: error instanceof Error ? error.message : t('未知错误', 'Unknown error'),
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="max-w-3xl space-y-4">
      <div className="rounded-md border border-blue-900/30 bg-blue-950/20 p-4 text-sm text-blue-200/80">
        {t('当前配置只覆盖账号', 'These settings only override account')} <strong>{login}</strong>{t('。未配置的字段继续使用全局规则。', '. Unset fields continue to use global rules.')}
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-1">
          <Label>{t('账号爆仓比例(%)', 'Account Stop-out Ratio (%)')}</Label>
          <Input
            value={stopOutPercent}
            inputMode="decimal"
            onChange={(event) => setStopOutPercent(event.target.value)}
            placeholder="50"
          />
        </div>
        <div className="space-y-1">
          <Label>{t('注意告警点数', 'Warning Distance')}</Label>
          <Input
            value={warningDistancePoints}
            inputMode="decimal"
            onChange={(event) => setWarningDistancePoints(event.target.value)}
            placeholder="1000"
          />
        </div>
        <div className="space-y-1">
          <Label>{t('危险告警点数', 'Danger Distance')}</Label>
          <Input
            value={dangerDistancePoints}
            inputMode="decimal"
            onChange={(event) => setDangerDistancePoints(event.target.value)}
            placeholder="500"
          />
        </div>
      </div>
      <div className="space-y-1">
        <Label>{t('账号预警条件', 'Account Alert Conditions')}</Label>
        <AlertConditionEditor value={conditions} onChange={setConditions} />
      </div>
      <div className="space-y-1">
        <Label>{t('账号提醒冷却', 'Account Notification Cooldown')}</Label>
        <NotificationCooldownEditor value={cooldown} onChange={setCooldown} />
      </div>
      <Button onClick={save} disabled={saving}>
        {saving ? t('保存中...', 'Saving...') : t('保存账号配置', 'Save Account Settings')}
      </Button>
    </div>
  );
}

function defaultCooldown() {
  return {
    seconds: 0,
    priceMovementPoints: 30,
    mode: 'priceOnly' as const,
  };
}

function defaultAccountConditions() {
  return {
    accountScope: 'all' as const,
    op: 'or' as const,
    rules: [
      { metric: 'distancePoints', operator: 'lte' as const, value: 500 },
      { metric: 'marginLevelPercent', operator: 'lte' as const, value: 80 },
      { metric: 'grossLots', operator: 'gte' as const, value: 5 },
    ],
  };
}

function normalizePositions(report: RiskReport): PositionDetail[] {
  const details = report.positionDetails || report.positions || [];
  return details.map((position) => {
    const raw = position as Partial<PositionDetail> & { volume?: number };
    return {
      ticket: raw.ticket ?? '—',
      login: raw.login ?? report.account?.login ?? '—',
      symbol: raw.symbol ?? '—',
      action: raw.action ?? '—',
      volumeLots: Number(raw.volumeLots ?? raw.volume ?? 0),
      openPrice: Number(raw.openPrice ?? 0),
      currentPrice: Number(raw.currentPrice ?? raw.closePrice ?? raw.openPrice ?? 0),
      closePrice: Number(raw.closePrice ?? raw.currentPrice ?? raw.openPrice ?? 0),
      closePriceSide: raw.closePriceSide,
      quoteBid: raw.quoteBid,
      quoteAsk: raw.quoteAsk,
      quoteTime: raw.quoteTime,
      contractSize: Number(raw.contractSize ?? 0),
      point: Number(raw.point ?? 0),
      pointValue: Number(raw.pointValue ?? 0),
      pointValueAccount: Number(raw.pointValueAccount ?? 0),
      profitCurrency: raw.profitCurrency ?? '',
      profitCurrencyRateToAccount: Number(raw.profitCurrencyRateToAccount ?? 1),
      profit: Number(raw.profit ?? 0),
      swap: Number(raw.swap ?? 0),
      commission: Number(raw.commission ?? 0),
      netProfit: Number(raw.netProfit ?? Number(raw.profit ?? 0) + Number(raw.swap ?? 0) + Number(raw.commission ?? 0)),
      reportedProfit: raw.reportedProfit,
      computedProfit: raw.computedProfit,
      computedNetProfit: raw.computedNetProfit,
      profitSource: raw.profitSource,
      profitCheckDiff: raw.profitCheckDiff,
      canonicalSymbol: raw.canonicalSymbol,
      lotsToBaseMultiplier: Number(raw.lotsToBaseMultiplier ?? 1),
      baseEquivalentLots: Number(raw.baseEquivalentLots ?? raw.volumeLots ?? raw.volume ?? 0),
      baseContractSize: raw.baseContractSize,
      basePoint: raw.basePoint,
      baseProfitCurrency: raw.baseProfitCurrency,
      basePointValuePerLotAccount: raw.basePointValuePerLotAccount,
      basePointValueAccount: raw.basePointValueAccount,
      basePointValueCurrency: raw.basePointValueCurrency,
      baseOpenPrice: Number(raw.baseOpenPrice ?? raw.openPrice ?? 0),
      openTime: raw.openTime,
      updateTime: raw.updateTime,
    };
  });
}

function HeaderMetric({ label, value, danger }: { label: string; value: string; danger?: boolean }) {
  return (
    <div className="flex flex-col">
      <span className="text-[10px] uppercase text-zinc-500">{label}</span>
      <span className={cn('text-sm font-bold tabular-nums', danger ? 'text-red-500' : 'text-zinc-200')}>
        {value}
      </span>
    </div>
  );
}

function DrawerTab({
  active,
  onClick,
  icon,
  children,
}: {
  active: boolean;
  onClick: () => void;
  icon: ReactNode;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex items-center gap-2 border-b-2 py-3 text-sm font-medium transition-colors',
        active ? 'border-emerald-500 text-emerald-400' : 'border-transparent text-zinc-400 hover:text-zinc-200',
      )}
    >
      {icon}
      {children}
    </button>
  );
}

function PositionsTable({
  positions,
  showLogin = false,
}: {
  positions: PositionDetail[];
  showLogin?: boolean;
}) {
  const { language, t } = useI18n();
  if (!positions.length) {
    return <div className="rounded-md border border-zinc-800 bg-zinc-900 p-8 text-center text-sm text-zinc-500">{t('无持仓', 'No positions')}</div>;
  }

  return (
    <table className="block w-full rounded-md border border-zinc-800 text-left text-sm text-zinc-400">
      <thead className="table w-full table-fixed border-b border-zinc-800 bg-zinc-900 text-xs uppercase text-zinc-500">
        <tr>
          {showLogin && <th className="w-28 px-4 py-3 font-medium">{t('账号', 'Login')}</th>}
          <th className="w-28 px-4 py-3 font-medium">{t('订单号', 'Ticket')}</th>
          <th className="w-28 px-4 py-3 font-medium">{t('产品', 'Symbol')}</th>
          <th className="w-20 px-4 py-3 text-center font-medium">{t('方向', 'Side')}</th>
          <th className="w-24 px-4 py-3 text-right font-medium">{t('手数', 'Lots')}</th>
          <th className="w-36 px-4 py-3 text-right font-medium">{t('折算美元黄金手数', 'XAUUSD Equivalent Lots')}</th>
          <th className="px-4 py-3 text-right font-medium">{t('开仓/现价', 'Open / Current')}</th>
          <th className="w-32 px-4 py-3 text-right font-medium">{t('报价/同步', 'Quote / Sync')}</th>
          <th className="w-32 px-4 py-3 text-right font-medium">{t('合约量', 'Contract Size')}</th>
          <th className="w-32 px-4 py-3 text-right font-medium">{t('点值(USD)', 'Point Value (USD)')}</th>
          <th className="w-28 px-4 py-3 text-right font-medium">{t('库存费', 'Swap')}</th>
          <th className="w-28 px-4 py-3 text-right font-medium">{t('盈亏', 'P/L')}</th>
        </tr>
      </thead>
      <tbody className="table w-full table-fixed divide-y divide-zinc-800/50">
        {positions.map((position) => (
          <tr key={`${showLogin ? `${position.login}-` : ''}${String(position.ticket)}`} className="transition-colors hover:bg-zinc-900">
            {showLogin && <td className="w-28 px-4 py-3 font-mono text-xs text-emerald-400">{position.login}</td>}
            <td className="w-28 px-4 py-3 font-mono text-xs text-zinc-300">{position.ticket}</td>
            <td className="w-28 px-4 py-3 font-bold text-zinc-200">{position.symbol}</td>
            <td className="w-20 px-4 py-3 text-center">
              <Badge variant={position.action === 'BUY' ? 'success' : 'destructive'}>{directionLabel(position.action, language)}</Badge>
            </td>
            <td className="w-24 px-4 py-3 text-right font-mono text-zinc-300">
              {formatNumber(position.volumeLots, 2)}
            </td>
            <td className="w-36 px-4 py-3 text-right font-mono text-xs text-zinc-300">
              {position.baseEquivalentLots !== undefined ? (
                <>
                  <span>{formatNumber(position.baseEquivalentLots, 4)}</span>
                  <span className="ml-1 text-zinc-500">{position.canonicalSymbol || position.symbol}</span>
                </>
              ) : (
                '—'
              )}
            </td>
            <td className="px-4 py-3 text-right font-mono text-xs">
              <span className="text-zinc-500">{formatPrice(Number(position.openPrice || 0))}</span>
              <span className="mx-2 text-zinc-600">→</span>
              <span className="text-zinc-300">{formatPrice(Number(position.currentPrice || position.closePrice || 0))}</span>
              <span className="ml-1 text-[10px] text-zinc-600">{position.closePriceSide || ''}</span>
            </td>
            <td className="w-32 px-4 py-3 text-right font-mono text-[10px] text-zinc-500">
              <div>{formatPositionQuote(position, t) || '—'}</div>
              <div>{formatSyncTime(position.updateTime || position.quoteTime)}</div>
            </td>
            <td className="w-32 px-4 py-3 text-right font-mono text-xs text-zinc-300">
              {formatNumber(Number(position.baseContractSize ?? position.contractSize), 0)}
              {position.canonicalSymbol && position.canonicalSymbol !== position.symbol ? (
                <div className="mt-1 text-[10px] text-zinc-500">{position.canonicalSymbol}</div>
              ) : null}
            </td>
            <td className="w-32 px-4 py-3 text-right font-mono text-xs text-zinc-300">
              {formatNumber(Number(position.basePointValueAccount ?? position.pointValueAccount), 4)}
              <span className="ml-1 text-zinc-500">{position.basePointValueCurrency || 'USD'}</span>
              {position.canonicalSymbol && position.canonicalSymbol !== position.symbol ? (
                <div className="mt-1 text-[10px] text-zinc-500">{t('按', 'By')} {position.canonicalSymbol}</div>
              ) : null}
            </td>
            <td className={cn('w-28 px-4 py-3 text-right font-mono text-xs', Number(position.swap || 0) >= 0 ? 'text-zinc-300' : 'text-red-300')}>
              {Number(position.swap || 0) > 0 ? '+' : ''}
              {formatNumber(Number(position.swap || 0), 2)}
            </td>
            <td
              className={cn(
                'w-28 px-4 py-3 text-right font-bold tabular-nums',
                position.profit >= 0 ? 'text-emerald-500' : 'text-red-500',
              )}
            >
              {position.profit > 0 ? '+' : ''}
              {formatNumber(position.profit)}
              <div className="mt-1 text-[10px] font-normal text-zinc-500">
                {profitSourceLabel(position, t)}
                {Number(position.netProfit) !== Number(position.profit)
                  ? ` / ${t('净', 'Net')} ${formatNumber(Number(position.netProfit), 2)}`
                  : ''}
                {Number.isFinite(Number(position.profitCheckDiff)) && Math.abs(Number(position.profitCheckDiff)) > 0.01
                  ? ` / ${t('差', 'Diff')} ${formatNumber(position.profitCheckDiff, 2)}`
                  : ''}
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function ExposureTable({ exposures }: { exposures: SymbolExposure[] }) {
  const { t } = useI18n();
  if (!exposures.length) {
    return <div className="rounded-md border border-zinc-800 bg-zinc-900 p-8 text-center text-sm text-zinc-500">{t('无敞口', 'No exposure')}</div>;
  }

  return (
    <table className="block w-full rounded-md border border-zinc-800 text-left text-sm text-zinc-400">
      <thead className="table w-full table-fixed border-b border-zinc-800 bg-zinc-900 text-xs uppercase text-zinc-500">
        <tr>
          <th className="px-4 py-3 font-medium">{t('产品', 'Symbol')}</th>
          <th className="px-4 py-3 text-center font-medium">{t('净头寸方向', 'Net Direction')}</th>
          <th className="px-4 py-3 text-right font-medium">{t('买单/卖单手数', 'Buy / Sell Lots')}</th>
          <th className="px-4 py-3 text-right font-medium">{t('净手数', 'Net Lots')}</th>
          <th className="px-4 py-3 text-right font-medium">{t('合约量', 'Contract Size')}</th>
          <th className="px-4 py-3 text-right font-medium">{t('点值(USD)', 'Point Value (USD)')}</th>
          <th className="px-4 py-3 text-right font-medium">{t('开仓/爆仓价格', 'Open / Liquidation Price')}</th>
        </tr>
      </thead>
      <tbody className="table w-full table-fixed divide-y divide-zinc-800/50">
        {exposures.map((exposure) => (
          <tr key={exposure.symbol} className="transition-colors hover:bg-zinc-900">
            <td className="px-4 py-3 font-bold text-zinc-200">{exposure.symbol}</td>
            <td className="px-4 py-3 text-center">
              <NetDirectionBadge direction={exposure.netDirection} />
            </td>
            <td className="px-4 py-3 text-right font-mono text-xs text-zinc-300">
              {formatNumber(exposure.buyLots, 2)} / {formatNumber(exposure.sellLots, 2)}
            </td>
            <td className="px-4 py-3 text-right font-mono text-xs text-zinc-300">
              {formatNumber(exposure.netLots, 2)}
            </td>
            <td className="px-4 py-3 text-right font-mono text-xs text-zinc-300">
              {formatNumber(exposure.contractSize, 0)}
            </td>
            <td className="px-4 py-3 text-right font-mono text-xs text-zinc-300">
              {formatNumber(displayExposurePointValueUsd(exposure), 2)}
            </td>
            <td className="px-4 py-3 text-right font-mono text-xs text-zinc-300">
              {exposure.risk ? (
                <PriceStack
                  prices={exposure.risk.convertedPrices}
                  fallbackOpen={exposure.netAverageOpenPrice || exposure.averageOpenPrice || exposure.risk.averageOpenPrice || 0}
                  fallbackLiquidation={exposure.risk.liquidationPrice}
                />
              ) : (
                '—'
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function displayExposurePointValueUsd(exposure: SymbolExposure) {
  const symbol = String(exposure.symbol || '').toUpperCase();
  const netLots = Math.abs(Number(exposure.netLots || 0));
  const contractSize = Number(exposure.contractSize || 0);
  const point = Number(exposure.point || 0);
  if (symbol === 'XAUUSD' && netLots > 0 && contractSize > 0 && point > 0) {
    return netLots * contractSize * point;
  }
  const perLotUsd = Number(exposure.pointValuePerLotAccount);
  if (netLots > 0 && Number.isFinite(perLotUsd) && perLotUsd > 0) return netLots * perLotUsd;
  const reported = Number(exposure.netPointValueAccount);
  if (Number.isFinite(reported)) return reported;
  return 0;
}
