import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

export type Language = 'zh' | 'en';

type I18nContextValue = {
  language: Language;
  setLanguage: (language: Language) => void;
  toggleLanguage: () => void;
  t: (zh: string, en: string) => string;
};

const STORAGE_KEY = 'mt5-risk-monitor-language';

const I18nContext = createContext<I18nContextValue | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    if (typeof window === 'undefined') return 'zh';
    const saved = window.localStorage.getItem(STORAGE_KEY);
    return saved === 'en' ? 'en' : 'zh';
  });

  useEffect(() => {
    document.documentElement.lang = language === 'zh' ? 'zh-CN' : 'en';
    window.localStorage.setItem(STORAGE_KEY, language);
  }, [language]);

  const value = useMemo<I18nContextValue>(() => {
    const setLanguage = (next: Language) => setLanguageState(next);
    return {
      language,
      setLanguage,
      toggleLanguage: () => setLanguageState((current) => (current === 'zh' ? 'en' : 'zh')),
      t: (zh: string, en: string) => (language === 'zh' ? zh : en),
    };
  }, [language]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const value = useContext(I18nContext);
  if (!value) throw new Error('useI18n must be used inside I18nProvider');
  return value;
}

export function directionLabel(direction: unknown, language: Language) {
  const value = String(direction || '').toUpperCase();
  if (language === 'zh') {
    if (value === 'BUY') return '买';
    if (value === 'SELL') return '卖';
    if (value === 'FLAT') return '净平';
  } else {
    if (value === 'BUY') return 'Buy';
    if (value === 'SELL') return 'Sell';
    if (value === 'FLAT') return 'Flat';
  }
  return value || '—';
}
