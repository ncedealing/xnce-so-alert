'use strict';

const { spawn } = require('node:child_process');
const path = require('node:path');
const { resolveFromCwd } = require('../config');
const { resolveSecret } = require('../domain/secrets');

class ManagerApiProvider {
  constructor(config) {
    this.config = config;
    this.options = (config.provider && config.provider.managerApi) || {};
  }

  async getSnapshot({ groupMasks, symbolMasks, accountLogins, symbolListOnly = false } = {}) {
    const server = ((this.config.mt5.servers || [])[0]) || {};
    const secret = resolveSecret(server, 'password', 'passwordEnv');
    const password = secret.value;
    if (!password) {
      const envName = secret.envName || server.passwordEnv || 'MT5_MANAGER_PASSWORD';
      throw new Error(`MT5 manager password is missing: set ${envName} or configure a saved password`);
    }

    const request = {
      server: {
        name: server.name,
        host: server.host,
        port: Number(server.port || 443),
        login: server.login,
        password,
        timeoutMs: server.timeoutMs || 30000
      },
      mt5: {
        groupMasks: groupMasks || [],
        symbolMasks: symbolMasks || ['*'],
        accountLogins: accountLogins || [],
        baseCurrency: this.config.mt5.baseCurrency || 'USD',
        serverTimeOffsetMinutes: this.config.mt5.serverTimeOffsetMinutes ?? 180,
        symbolListOnly
      },
      risk: {
        symbolMappings: (this.config.risk && this.config.risk.symbolMappings) || {},
        defaultSixCharSymbolMapping:
          this.config.risk && this.config.risk.defaultSixCharSymbolMapping === false ? false : true
      }
    };

    const command = this.resolveCommand();
    const args = Array.isArray(this.options.args) ? this.options.args : [];
    const cwd = this.options.cwd ? resolveFromCwd(this.config, this.options.cwd) : this.config.__cwd;
    const timeoutMs = Number(this.options.timeoutMs || server.timeoutMs || 30000);
    const result = await runSnapshotCommand({ command, args, cwd, timeoutMs, request, secrets: [password] });
    return result;
  }

  async getSymbols({ symbolMasks } = {}) {
    const snapshot = await this.getSnapshot({
      groupMasks: [],
      symbolMasks: symbolMasks || ['*'],
      accountLogins: [],
      symbolListOnly: true
    });
    return snapshot.symbols || [];
  }

  resolveCommand() {
    const command = this.options.command;
    if (!command) {
      throw new Error('provider.managerApi.command is required');
    }
    return path.isAbsolute(command) ? command : resolveFromCwd(this.config, command);
  }
}

function runSnapshotCommand({ command, args, cwd, timeoutMs, request, secrets = [] }) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd,
      windowsHide: true,
      stdio: ['pipe', 'pipe', 'pipe']
    });
    let stdout = '';
    let stderr = '';
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      child.kill();
      reject(new Error(`MT5 Manager API snapshot command timed out after ${timeoutMs}ms`));
    }, timeoutMs);

    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    child.stdout.on('data', (chunk) => {
      stdout += chunk;
    });
    child.stderr.on('data', (chunk) => {
      stderr += chunk;
    });
    child.on('error', (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      reject(error);
    });
    child.on('close', (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (code !== 0) {
        const details = redactText(stderr.trim() || stdout.trim(), secrets);
        reject(new Error(`MT5 Manager API snapshot command exited ${code}: ${details}`));
        return;
      }
      try {
        resolve(JSON.parse(stdout));
      } catch (error) {
        reject(new Error(`MT5 Manager API snapshot command returned invalid JSON: ${error.message}`));
      }
    });

    child.stdin.end(`${JSON.stringify(request)}\n`);
  });
}

function redactText(text, secrets = []) {
  let safe = String(text || '');
  for (const secret of secrets) {
    if (!secret) continue;
    safe = safe.split(String(secret)).join('[redacted]');
  }
  return safe;
}

module.exports = {
  ManagerApiProvider,
  runSnapshotCommand,
  redactText
};
