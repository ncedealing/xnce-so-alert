'use strict';

const { toNumber, pointFromSymbol } = require('./margin');
const { matchesGroupMask } = require('./groupMask');

function normalizeSymbolName(symbol) {
  return String(symbol || '').toUpperCase();
}

function mappingEntries(riskConfig = {}) {
  const mappings = riskConfig.symbolMappings || {};
  return Object.entries(mappings).map(([symbol, mapping]) => ({
    symbol,
    normalizedSymbol: normalizeSymbolName(symbol),
    mapping: mapping || {}
  }));
}

function defaultBaseSymbol(symbol, riskConfig = {}) {
  if (riskConfig.defaultSixCharSymbolMapping === false) return '';
  const normalized = normalizeSymbolName(symbol).replace(/^[^A-Z0-9]+/, '');
  if (normalized.length <= 6) return '';
  return normalized.slice(0, 6);
}

function defaultMappingForSymbol(symbol, riskConfig = {}) {
  const baseSymbol = defaultBaseSymbol(symbol, riskConfig);
  if (!baseSymbol || baseSymbol === normalizeSymbolName(symbol)) return null;
  return {
    symbol: `${baseSymbol}*`,
    normalizedSymbol: `${baseSymbol}*`,
    mapping: {
      baseSymbol,
      mappedLotsPerBaseLot: 1,
      auto: true
    }
  };
}

function mappingForSymbol(symbol, riskConfig = {}) {
  const normalized = normalizeSymbolName(symbol);
  const entries = mappingEntries(riskConfig);
  return (
    entries.find((entry) => entry.normalizedSymbol === normalized) ||
    entries.find((entry) => matchesGroupMask(normalized, [entry.symbol])) ||
    defaultMappingForSymbol(symbol, riskConfig) ||
    null
  );
}

function mappingsForBaseSymbol(baseSymbol, riskConfig = {}) {
  const normalized = normalizeSymbolName(baseSymbol);
  return mappingEntries(riskConfig).filter(
    (entry) => normalizeSymbolName(entry.mapping.baseSymbol) === normalized
  );
}

function canonicalSymbol(symbol, riskConfig = {}) {
  const entry = mappingForSymbol(symbol, riskConfig);
  return entry && entry.mapping.baseSymbol ? entry.mapping.baseSymbol : symbol;
}

function lotsToBaseMultiplier(symbol, riskConfig = {}) {
  const entry = mappingForSymbol(symbol, riskConfig);
  if (!entry) return 1;
  const mapping = entry.mapping;
  if (toNumber(mapping.lotsToBase, 0) > 0) return toNumber(mapping.lotsToBase);
  if (toNumber(mapping.baseLotsPerMappedLot, 0) > 0) return toNumber(mapping.baseLotsPerMappedLot);
  if (toNumber(mapping.mappedLotsPerBaseLot, 0) > 0) return 1 / toNumber(mapping.mappedLotsPerBaseLot);
  if (toNumber(mapping.multiplier, 0) > 0) return toNumber(mapping.multiplier);
  return 1;
}

function quoteMid(quote) {
  if (!quote) return NaN;
  const bid = toNumber(quote.bid, NaN);
  const ask = toNumber(quote.ask, NaN);
  if (Number.isFinite(bid) && Number.isFinite(ask) && bid > 0 && ask > 0) return (bid + ask) / 2;
  if (Number.isFinite(bid) && bid > 0) return bid;
  if (Number.isFinite(ask) && ask > 0) return ask;
  return NaN;
}

function fxRate(mapping, quotesBySymbol) {
  const fxSymbol = mapping.fxSymbol || mapping.quoteSymbol;
  if (!fxSymbol) return toNumber(mapping.fxRate, 1);
  return toNumber(mapping.fxRate, quoteMid(quotesBySymbol.get(fxSymbol)));
}

function baseToMappedPriceMultiplier(mapping, quotesBySymbol) {
  const fx = fxRate(mapping, quotesBySymbol);
  const configured = toNumber(mapping.baseToMappedPriceMultiplier, 0);
  if (configured > 0) return configured * fx;
  const baseUnit = toNumber(mapping.baseUnitGrams ?? mapping.baseUnitWeight, 0);
  const mappedUnit = toNumber(mapping.mappedUnitGrams ?? mapping.mappedUnitWeight, 0);
  if (baseUnit > 0 && mappedUnit > 0) return (mappedUnit / baseUnit) * fx;
  return fx;
}

function baseToMappedPrice(basePrice, mapping, quotesBySymbol) {
  return toNumber(basePrice) * baseToMappedPriceMultiplier(mapping, quotesBySymbol);
}

function mappedToBasePrice(mappedPrice, mapping, quotesBySymbol) {
  const multiplier = baseToMappedPriceMultiplier(mapping, quotesBySymbol);
  return multiplier > 0 ? toNumber(mappedPrice) / multiplier : toNumber(mappedPrice);
}

function quoteFromBaseQuote(mappedSymbol, baseQuote, mapping, quotesBySymbol) {
  const existing = quotesBySymbol.get(mappedSymbol) || {};
  return {
    ...existing,
    symbol: mappedSymbol,
    bid: Math.max(0.00000001, baseToMappedPrice(baseQuote.bid, mapping, quotesBySymbol)),
    ask: Math.max(0.00000001, baseToMappedPrice(baseQuote.ask, mapping, quotesBySymbol)),
    time: baseQuote.time || existing.time
  };
}

function convertedPricesForBase({
  baseSymbol,
  direction,
  openBasePrice,
  currentBasePrice,
  liquidationBasePrice,
  symbolsByName,
  quotesBySymbol,
  riskConfig = {}
}) {
  const result = [];
  const baseSpec = symbolsByName.get(baseSymbol) || {};
  const baseQuote = quotesBySymbol.get(baseSymbol);
  const baseOpenPrice = toNumber(openBasePrice, NaN);
  result.push({
    symbol: baseSymbol,
    openPrice: Number.isFinite(baseOpenPrice) ? baseOpenPrice : currentBasePrice,
    currentPrice: currentBasePrice,
    liquidationPrice: liquidationBasePrice,
    point: pointFromSymbol(baseSpec),
    distancePoints: Math.abs(liquidationBasePrice - currentBasePrice) / pointFromSymbol(baseSpec),
    quote: baseQuote || null,
    currency: baseSpec.currencyProfit || baseSpec.currencyBase || 'USD'
  });

  for (const [mappedSymbol, mappedQuote] of quotesBySymbol.entries()) {
    if (normalizeSymbolName(mappedSymbol) === normalizeSymbolName(baseSymbol)) continue;
    const entry = mappingForSymbol(mappedSymbol, riskConfig);
    if (!entry || normalizeSymbolName(entry.mapping.baseSymbol) !== normalizeSymbolName(baseSymbol)) continue;
    const mappedSpec = symbolsByName.get(mappedSymbol) || {};
    const point = pointFromSymbol(mappedSpec);
    const currentPrice = mappedQuote
      ? direction === 'down'
        ? toNumber(mappedQuote.bid)
        : toNumber(mappedQuote.ask)
      : baseToMappedPrice(currentBasePrice, entry.mapping, quotesBySymbol);
    const openPrice = Number.isFinite(baseOpenPrice)
      ? baseToMappedPrice(baseOpenPrice, entry.mapping, quotesBySymbol)
      : currentPrice;
    const liquidationPrice = baseToMappedPrice(liquidationBasePrice, entry.mapping, quotesBySymbol);
    result.push({
      symbol: mappedSymbol,
      openPrice,
      currentPrice,
      liquidationPrice,
      point,
      distancePoints: point > 0 ? Math.abs(liquidationPrice - currentPrice) / point : 0,
      quote: mappedQuote || null,
      currency: mappedSpec.currencyProfit || entry.mapping.currency || ''
    });
  }
  return result;
}

module.exports = {
  normalizeSymbolName,
  defaultBaseSymbol,
  defaultMappingForSymbol,
  mappingForSymbol,
  mappingsForBaseSymbol,
  canonicalSymbol,
  lotsToBaseMultiplier,
  baseToMappedPrice,
  mappedToBasePrice,
  quoteFromBaseQuote,
  convertedPricesForBase
};
