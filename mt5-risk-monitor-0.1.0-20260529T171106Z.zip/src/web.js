#!/usr/bin/env node
'use strict';

const { MonitorState } = require('./webState');
const { createWebServer } = require('./web/server');

async function main() {
  const state = await new MonitorState(process.argv).init();
  const server = createWebServer(state);
  const host = state.config.web.host || '127.0.0.1';
  const port = Number(state.config.web.port || 4173);

  server.on('error', (error) => {
    state.services.logger.error(`web server failed: ${error.message}`);
    process.exit(1);
  });

  server.listen(port, host, () => {
    state.services.logger.info(`web system listening on http://${host}:${port}`);
    state.autoTestMt5Connection();
    if (state.config.runtime.autoStart !== false) {
      state.startMonitor();
      state.services.logger.info(`price sync started every ${state.config.runtime.pollIntervalSeconds}s`);
    }
  });
}

main().catch((error) => {
  console.error(error.stack || error.message);
  process.exitCode = 1;
});
