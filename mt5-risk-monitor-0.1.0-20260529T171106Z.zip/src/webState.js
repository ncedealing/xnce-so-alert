'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');
const { EventEmitter } = require('node:events');
const { loadConfig } = require('./config');
const { closeServices, createServices, monitorIntervalMs, runOnce } = require('./app');
const { diagnoseMt5Connection } = require('./domain/mt5Connection');
const {
  DEFAULT_SERVER_OFFSET_MINUTES,
  DEFAULT_SERVER_TIME_ZONE,
  offsetMinutesFromServerTimeZone,
  normalizeServerTime
} = require('./domain/serverTime');
const { mergeRedactedSecrets, redactSecrets } = require('./domain/secrets');

function publicConfig(config) {
  const clone = JSON.parse(JSON.stringify(config));
  delete clone.__cwd;
  delete clone.__configPath;
  delete clone.__runOnce;
  return redactSecrets(clone);
}

class MonitorState {
  constructor(argv) {
    this.argv = argv;
    this.config = null;
    this.services = null;
    this.lastResult = null;
    this.lastError = null;
    this.monitorTimer = null;
    this.monitorRunning = false;
    this.monitorStartedAt = null;
    this.pollInFlight = false;
    this.mt5Connection = {
      status: 'unknown',
      ok: false,
      checkedAt: null,
      latencyMs: 0,
      error: null
    };
    this.serverTime = null;
    this.serverTimeUpdatedAt = null;
    this.events = new EventEmitter();
    this.events.setMaxListeners(1000);
  }

  async init() {
    this.config = await loadConfig(this.argv);
    this.services = await createServices(this.config);
    return this;
  }

  status() {
    const disconnectAfterPollMultiples = normalizeDisconnectAfterPollMultiples(this.config);
    const staleThresholdMs =
      Math.max(0.1, Number(this.config.runtime.pollIntervalSeconds || 1)) *
      1000 *
      disconnectAfterPollMultiples;
    const lastFreshAt =
      this.serverTimeUpdatedAt ||
      (this.lastResult ? this.lastResult.checkedAt : null) ||
      (this.monitorRunning ? this.monitorStartedAt : null);
    const serverTimeAgeMs = this.serverTimeUpdatedAt
      ? Date.now() - new Date(this.serverTimeUpdatedAt).getTime()
      : Number.POSITIVE_INFINITY;
    const dataAgeMs = lastFreshAt
      ? Date.now() - new Date(lastFreshAt).getTime()
      : Number.POSITIVE_INFINITY;
    const serverTimeStale = Boolean(
      this.monitorRunning &&
      lastFreshAt &&
      Number.isFinite(dataAgeMs) &&
      dataAgeMs > staleThresholdMs
    );
    const mt5Connection = serverTimeStale
      ? {
          ...this.mt5Connection,
          ok: false,
          status: 'disconnected',
          error: `超过 ${disconnectAfterPollMultiples} 倍刷新时间未获取到 MT5 数据`
        }
      : this.mt5Connection;
    return {
      running: this.monitorRunning,
      pollInFlight: this.pollInFlight,
      pollIntervalSeconds: this.config.runtime.pollIntervalSeconds,
      mt5DisconnectAfterPollMultiples: disconnectAfterPollMultiples,
      serverTimeStaleThresholdMs: staleThresholdMs,
      streamingTransport: this.config.runtime.streamingTransport || 'sse',
      providerType: this.config.provider.type,
      mt5Connection,
      serverTime: this.serverTime,
      serverTimeUpdatedAt: this.serverTimeUpdatedAt,
      serverTimeStale,
      serverTimeAgeMs: Number.isFinite(serverTimeAgeMs) ? serverTimeAgeMs : null,
      mt5DataAgeMs: Number.isFinite(dataAgeMs) ? dataAgeMs : null,
      monitorStartedAt: this.monitorStartedAt,
      serverTimeZone: this.config.mt5.serverTimeZone || DEFAULT_SERVER_TIME_ZONE,
      serverTimeOffsetMinutes:
        this.config.mt5.serverTimeOffsetMinutes ??
        offsetMinutesFromServerTimeZone(this.config.mt5.serverTimeZone, DEFAULT_SERVER_OFFSET_MINUTES),
      groupMasks: this.config.mt5.groupMasks || [],
      symbolMasks: this.config.mt5.symbolMasks || [],
      lastCheckedAt: this.lastResult ? this.lastResult.checkedAt : null,
      lastError: this.lastError,
      accounts: this.lastResult ? this.lastResult.snapshot.accounts.length : 0,
      positions: this.lastResult ? this.lastResult.snapshot.positions.length : 0,
      alerts: this.lastResult ? this.lastResult.alerts.length : 0
    };
  }

  async reloadConfig() {
    const previousServices = this.services;
    this.config = await loadConfig(this.argv);
    this.services = await createServices(this.config);
    await closeServices(previousServices);
    if (this.monitorRunning) {
      this.stopMonitor();
      this.startMonitor();
    }
    this.publish('config', publicConfig(this.config));
    this.publish('status', this.status());
    this.autoTestMt5Connection();
  }

  async saveConfig(nextConfig) {
    const configPath = this.config.__configPath;
    const serializable = mergeRedactedSecrets(
      JSON.parse(JSON.stringify(nextConfig)),
      this.config
    );
    delete serializable.__cwd;
    delete serializable.__configPath;
    delete serializable.__runOnce;
    await fs.mkdir(path.dirname(configPath), { recursive: true });
    await fs.writeFile(configPath, `${JSON.stringify(serializable, null, 2)}\n`);
    await this.reloadConfig();
  }

  async checkNow() {
    if (this.pollInFlight) throw new Error('A check is already running');
    this.pollInFlight = true;
    try {
      const result = await runOnce(this.config, this.services);
      this.lastResult = {
        checkedAt: new Date().toISOString(),
        ...result
      };
      const serverTime = normalizeServerTime(
        result && result.snapshot ? result.snapshot.serverTime : null,
        this.config.mt5.serverTimeZone || this.config.mt5.serverTimeOffsetMinutes
      );
      if (serverTime) {
        this.serverTime = serverTime;
        this.serverTimeUpdatedAt = this.lastResult.checkedAt;
      }
      this.lastError = null;
      if (this.config.provider.type !== 'mock') {
        this.mt5Connection = {
          ...this.mt5Connection,
          status: 'connected',
          ok: true,
          checkedAt: this.lastResult.checkedAt,
          error: null
        };
      }
      this.publish('risk', this.lastResult);
      this.publish('status', this.status());
      return this.lastResult;
    } catch (error) {
      this.lastError = error.stack || error.message;
      if (this.config.provider.type !== 'mock') {
        this.mt5Connection = {
          ...this.mt5Connection,
          status: 'disconnected',
          ok: false,
          checkedAt: new Date().toISOString(),
          error: error.message
        };
      }
      this.publish('error', { message: this.lastError });
      this.publish('status', this.status());
      throw error;
    } finally {
      this.pollInFlight = false;
    }
  }

  async testMt5Connection(serverOverride) {
    const started = Date.now();
    this.mt5Connection = {
      ...this.mt5Connection,
      status: 'testing',
      ok: false,
      checkedAt: new Date().toISOString(),
      error: null
    };
    this.publish('status', this.status());
    let result;
    try {
      result = await withTimeout(
        diagnoseMt5Connection(this.config, serverOverride),
        Number((serverOverride && serverOverride.routeTimeoutMs) || 6500),
        'MT5 connection test timed out'
      );
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      result = {
        status: 'disconnected',
        ok: false,
        checkedAt: new Date().toISOString(),
        latencyMs: Date.now() - started,
        error: message,
        checks: [{ key: 'timeout', status: 'error', message }]
      };
    }
    this.mt5Connection = result;
    this.publish('status', this.status());
    return result;
  }

  autoTestMt5Connection() {
    const providerType = this.config && this.config.provider ? this.config.provider.type : 'mock';
    if (!['mt5WebApi', 'managerApi'].includes(providerType)) return;
    this.testMt5Connection({
      providerType,
      deepAuth: false,
      tcpTimeoutMs: 3000,
      routeTimeoutMs: 6500
    }).catch((error) => {
      this.services.logger.warn(`auto MT5 connection test failed: ${error.message}`);
    });
  }

  async getSymbols() {
    if (!this.services || !this.services.provider || typeof this.services.provider.getSymbols !== 'function') {
      return this.lastResult ? this.lastResult.snapshot.symbols || [] : [];
    }
    return this.services.provider.getSymbols({
      groupMasks: this.config.mt5.groupMasks || [],
      symbolMasks: ['*'],
      accountLogins: this.config.mt5.accountLogins || []
    });
  }

  startMonitor() {
    if (this.monitorRunning) return;
    this.monitorRunning = true;
    this.monitorStartedAt = new Date().toISOString();
    const intervalMs = monitorIntervalMs(this.config);
    this.publish('status', this.status());
    this.checkNow().catch((error) => {
      this.services.logger.error(error.stack || error.message);
    });
    this.monitorTimer = setInterval(() => {
      this.checkNow().catch((error) => {
        this.services.logger.error(error.stack || error.message);
      });
    }, intervalMs);
  }

  stopMonitor() {
    if (this.monitorTimer) clearInterval(this.monitorTimer);
    this.monitorTimer = null;
    this.monitorRunning = false;
    this.monitorStartedAt = null;
    this.publish('status', this.status());
  }

  publish(event, payload) {
    this.events.emit('message', { event, payload, emittedAt: new Date().toISOString() });
  }

  subscribe(listener) {
    this.events.on('message', listener);
    return () => this.events.off('message', listener);
  }
}

function normalizeDisconnectAfterPollMultiples(config = {}) {
  const value = Number(config.mt5 && config.mt5.disconnectAfterPollMultiples);
  return Number.isFinite(value) && value > 0 ? value : 5;
}

function withTimeout(promise, timeoutMs, message) {
  let timer;
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${message} after ${timeoutMs}ms`)), timeoutMs);
    })
  ]).finally(() => clearTimeout(timer));
}

module.exports = {
  MonitorState,
  publicConfig,
  mergeRedactedSecrets
};
